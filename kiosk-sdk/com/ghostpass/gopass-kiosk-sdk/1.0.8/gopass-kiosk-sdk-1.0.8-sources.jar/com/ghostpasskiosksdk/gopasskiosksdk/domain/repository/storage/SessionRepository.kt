package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.InitiatedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionResultPayload

internal interface SessionRepository {
    suspend fun submitResult(sessionId: String, success: Boolean): ApiResult<SessionResultPayload>
    suspend fun requestSession(deviceId: String): ApiResult<InitiatedSessionPayload>
    suspend fun notifyAuthProgress(sessionIds: List<String>): ApiResult<String>
}