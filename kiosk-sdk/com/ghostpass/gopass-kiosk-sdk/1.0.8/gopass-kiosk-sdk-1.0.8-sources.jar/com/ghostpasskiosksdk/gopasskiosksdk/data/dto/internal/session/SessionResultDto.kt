package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session

import kotlinx.serialization.Serializable

@Serializable
internal data class SessionResultDto(
    val sessionId: String,
    val status: String,
    val terminatedAt: String? = null,
    val failCount: Int = 0
)