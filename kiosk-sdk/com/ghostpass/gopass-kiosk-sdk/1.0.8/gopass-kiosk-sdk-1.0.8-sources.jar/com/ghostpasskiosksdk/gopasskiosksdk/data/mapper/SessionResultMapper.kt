package com.ghostpasskiosksdk.gopasskiosksdk.data.mapper

import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.SessionResultDto
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionResultPayload

internal fun SessionResultDto.toDomain(): SessionResultPayload {
    return SessionResultPayload(
        sessionId = sessionId,
        status = status,
        terminatedAt = terminatedAt
    )
}
