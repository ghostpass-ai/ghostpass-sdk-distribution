package com.ghostpasskiosksdk.gopasskiosksdk.data.repository

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.data.api.FirebaseApi
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.auth.AuthPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.CustomTokenSignInRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.FirebaseSseWrapperDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.KioskToUserPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.toDomain
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.AuthPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemoteStateChannelRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.useAndWipe
import com.ghostpasskiosksdk.gopasskiosksdk.utils.verboseLog
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.transform
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json.Default.decodeFromString
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import java.security.Key
import java.util.concurrent.TimeUnit

internal class RemoteStateChannelRepositoryImpl(
    private val firebaseApi: FirebaseApi,
    private val okHttpClient: OkHttpClient,
    private val cryptoEngine: CryptoEngine

) : RemoteStateChannelRepository {

    companion object {
        val TAG = "RemoteStateChannelRepo ${BuildConfig.SIGNATURE}"
        const val KIOSK_TO_USER = "kiosk_to_user"
        const val USER_TO_KIOSK = "user_to_kiosk"
    }

    private sealed class DecodeResult {
        data class Success(val sessionId: String, val deviceId: String) : DecodeResult()
        data class Error(val sessionId: String, val reason: FaceAuthFailReason) : DecodeResult()
    }

    override suspend fun observeSessionId(
        sessionIds: Set<SessionData>,
        tokenMap: Map<String, AuthToken>,
        timeoutMs: Long
    ): SessionIdEvent {
        debugLog(TAG, "observeSessionId 호출: ${sessionIds.size}개 세션 동시 관찰 시작")
        if (sessionIds.isEmpty()) return SessionIdEvent.Failed(FaceAuthFailReason.EMPTY_SESSION_IDS)

        val flowList = sessionIds.map { session ->
            flow {
                val idToken = tokenMap[session.sessionId]?.idToken
                    ?: throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = InternalErrorCode.FB_AUTH_NULL
                    )
                observeSingleSessionSse(session, idToken).collect { emit(it) }
            }.catch { e ->
                errorLog(TAG, "세션 [${session.sessionId}] 옵저빙 실패: ${e.message}")
                emit(DecodeResult.Error(session.sessionId, FaceAuthFailReason.UNKNOWN))
            }
        }

        val result = withTimeoutOrNull(timeoutMs) {
            var errorCount = 0
            val totalSessions = sessionIds.size

            flowList.merge().transform { res ->
                if (res is DecodeResult.Success) {
                    emit(res) // 🚨 1명이라도 성공하면 즉시 방출 후 종료 (나머지 세션 소켓 자동 파기)
                } else {
                    errorCount++
                    if (errorCount >= totalSessions) {
                        emit(res) // 🚨 전원 실패 시, 타임아웃까지 기다리지 않고 즉시 에러 방출 후 종료
                    }
                }
            }.firstOrNull()
        }

        return when (result) {
            is DecodeResult.Success -> SessionIdEvent.Success(result.sessionId, result.deviceId)
            is DecodeResult.Error -> SessionIdEvent.Failed(FaceAuthFailReason.ALL_FAILED)
            null -> SessionIdEvent.Failed(FaceAuthFailReason.TIMEOUT)
        }
    }

    private suspend fun authenticate(customToken: String): AuthToken {
        val request = CustomTokenSignInRequest(token = customToken, returnSecureToken = true)
        val response = firebaseApi.signInWithCustomToken(BuildConfig.FB_API_KEY, request)
        if (response.isSuccessful) {
            val body = response.body() ?: throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.FB_AUTH_NULL
            )
            return AuthToken(idToken = body.idToken)
        } else {
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.FIREBASE_AUTH_SIGNIN_FAILED
            )
        }
    }

    private fun observeSingleSessionSse(session: SessionData, idToken: String): Flow<DecodeResult> = callbackFlow {
        // 🚨 키오스크는 유저가 보낸 데이터를 관찰해야 하므로 USER_TO_KIOSK 경로 구독
        val sseUrl = "${BuildConfig.FB_DB_URL}${session.rtdbPath.trimEnd('/')}/$USER_TO_KIOSK.json?auth=$idToken"

        val request = Request.Builder()
            .url(sseUrl)
            .header("Accept", "text/event-stream")
            .build()

        val sseClient = okHttpClient.newBuilder().readTimeout(0, TimeUnit.MILLISECONDS).build()
        val factory = EventSources.createFactory(sseClient)

        val eventSource = factory.newEventSource(request, object : EventSourceListener() {
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                if (data == "null") return

                if (type == "put" || type == "patch") {
                    try {
                        // Firebase REST API의 Sse 이벤트 래퍼 파싱
                        val wrapper = decodeFromString<FirebaseSseWrapperDto>(data)
                        wrapper.data?.let { payloadMap ->
                            val result = decodeAuthEvent(payloadMap.payload, session.sessionId, payloadMap.seq, session.dkKiosk)
                            trySend(result)
                        }
                    } catch (e: Exception) {
                        errorLog(TAG, "SSE 데이터 파싱 실패 [${session.sessionId}]: ${e.message}")
                    }
                }
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                errorLog(TAG, "SSE 연결 에러 [${session.sessionId}]: ${t?.message}")
                close(GoPassSdkException.from(error = ErrorCode.NETWORK_ERROR, cause = InternalErrorCode.SSE_STREAM_UNKNOWN_ERROR))
            }
        })

        awaitClose {
            debugLog(TAG, "🛑 세션 [${session.sessionId}] SSE 구독 해제")
            eventSource.cancel()
        }
    }

    private fun decodeAuthEvent(payload: String, sid: String, seq: Int, key: Key): DecodeResult {
        if (seq < 1) {
            errorLog(TAG, "비정상적인 메시지 순서 (Replay 공격 의심): seq=$seq")
            return DecodeResult.Error(sid, FaceAuthFailReason.UNKNOWN)
        }
        val decryptedJson = try {
            val aadString = "${sid}:${seq}:u2k"

            cryptoEngine.decryptData(
                key = key,
                encryptedBase64 = payload,
                aad = aadString.toByteArray(Charsets.UTF_8)
            ).useAndWipe { safeBytes ->
                String(safeBytes, Charsets.UTF_8)
            }

        } catch (e: Exception) {
            errorLog(TAG, "decryptedJson error : $e")
            return DecodeResult.Error(sid, FaceAuthFailReason.DECRYPTION_ERROR)
        }

        verboseLog(TAG, " decryptedJson : $decryptedJson")

        return try {
            val dto = decodeFromString<AuthPayloadDto>(decryptedJson)
            infoLog(TAG, "AuthPayload : $dto")
            val domain = dto.toDomain()

            if (domain is AuthPayload.Success) {
                DecodeResult.Success(sid, domain.deviceId)
            } else {
                DecodeResult.Error(sid, FaceAuthFailReason.UNKNOWN)
            }
        } catch (e: Exception) {
            errorLog(TAG, "AuthPayloadDto error : $e")
            DecodeResult.Error(sid, FaceAuthFailReason.PARSE_ERROR)
        }
    }

    override suspend fun clearUserToKioskData(
        sessions: Set<SessionData>,
        tokenMap: Map<String, AuthToken>
    ): Unit = coroutineScope {
        sessions.map { session ->
            async {
                runCatching {
                    val idToken = tokenMap[session.sessionId]?.idToken ?: return@async
                    val path = "${session.rtdbPath.trimEnd('/')}/$USER_TO_KIOSK.json"
                    firebaseApi.deleteSessionData("${BuildConfig.FB_DB_URL}$path", idToken)
                }.onFailure { e ->
                    errorLog(TAG, "user_to_kiosk 삭제 실패 [${session.sessionId}]: ${e.message}")
                }
            }
        }.awaitAll()
    }

    override suspend fun authenticateSessions(
        sessions: Set<SessionData>
    ): Map<SessionData, Result<AuthToken>> = coroutineScope {
        debugLog(TAG, "authenticateSessions 병렬 인증 시작: ${sessions.size}개 세션")

        sessions.map { session ->
            async {
                val result = runCatching { authenticate(session.firebaseToken) }
                session to result
            }
        }.awaitAll().toMap()
    }

    override suspend fun updateKioskSecureData(
        sessionPayloads: Map<SessionData, EncryptedSessionPayload>,
        tokenMap: Map<SessionData, AuthToken>
    ): Map<SessionData, Result<Unit>> = coroutineScope {
        debugLog(TAG, "updateKioskSecureData 일괄 업데이트 진행: ${sessionPayloads.size}개 세션")

        sessionPayloads.map { (session, payload) ->
            async {
                val result = runCatching {
                    val authToken = tokenMap[session] ?: throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = InternalErrorCode.FB_AUTH_NULL
                    )

                    // 🚨 키오스크가 유저에게 전송하므로 KIOSK_TO_USER 경로 업데이트
                    val path = "${session.rtdbPath.trimEnd('/')}/$KIOSK_TO_USER.json"

                    val dataToPush = KioskToUserPayloadDto(
                        payload = payload.encryptedData,
                        seq = payload.seq
                    )

                    val response = firebaseApi.updateSessionState("${BuildConfig.FB_DB_URL}$path", authToken.idToken, dataToPush)
                    if (!response.isSuccessful) throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = when (response.code()) {
                            401 -> InternalErrorCode.CHANNEL_UPDATE_UNAUTHORIZED
                            403 -> InternalErrorCode.CHANNEL_UPDATE_FORBIDDEN
                            in 500..599 -> InternalErrorCode.CHANNEL_UPDATE_SERVER_ERROR
                            else -> InternalErrorCode.UNKNOWN
                        }
                    )
                }
                session to result
            }
        }.awaitAll().toMap()
    }
}