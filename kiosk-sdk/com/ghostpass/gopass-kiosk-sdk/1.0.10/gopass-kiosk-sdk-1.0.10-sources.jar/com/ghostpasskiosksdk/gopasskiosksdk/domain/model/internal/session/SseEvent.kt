package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session

internal sealed class SseEvent {
    data object Connected : SseEvent()
    data object Heartbeat : SseEvent()
    data class SessionCreated(val payload: SessionInfoPayload) : SseEvent()
    data class SessionTerminated(val sessionId: String) : SseEvent()
    data class SessionSync(val sessionIds: Set<String>) : SseEvent()
}
