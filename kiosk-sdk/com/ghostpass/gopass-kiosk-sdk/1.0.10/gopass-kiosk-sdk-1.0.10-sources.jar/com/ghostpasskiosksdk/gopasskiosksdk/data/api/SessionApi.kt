package com.ghostpasskiosksdk.gopasskiosksdk.data.api

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResponse
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.AuthProgressRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.InitiatedSessionDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.InitiatedSessionRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.SessionInfoDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

internal interface SessionApi {
    companion object {
        const val PREFIX = "api/v1/sessions"
    }
    @POST("$PREFIX/kiosk-initiated")
    suspend fun requestSession(
        @Body request: InitiatedSessionRequest
    ) : Response<ApiResponse<InitiatedSessionDto>>

    @POST("$PREFIX/auth-progress")
    suspend fun notifyAuthProgress(
        @Body request: AuthProgressRequest
    ) : Response<ApiResponse<String>>

    @GET("$PREFIX/{sessionId}/kiosk-info")
    suspend fun fetchKioskInfo(
        @Path("sessionId") sessionId: String
    ) : Response<ApiResponse<SessionInfoDto>>
}
