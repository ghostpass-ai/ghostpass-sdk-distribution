package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external

enum class FailReason(val message: String = "") {
    INVALID_POSE_ROLL("고개를 삐딱하지 않게\n똑바로 세워주세요"),
    INVALID_POSE_PITCH("고개를 숙이거나 들지 말고\n정면을 봐주세요"),
    INVALID_POSE_YAW("옆을 보지 말고\n카메라 렌즈를 봐주세요"),

    INVALID_POSITION("얼굴을 화면 중앙에 위치시켜주세요"),
    INVALID_SIZE_MAX("화면에서 한 걸음 뒤로 물러나주세요"),
    INVALID_SIZE_MIN("카메라 쪽으로 한 걸음만 다가와주세요"),

    LOW_FACE_QUALITY("얼굴이 선명하지 않습니다\n잠시 멈춰주세요"),
    LOW_LANDMARK_CONFIDENCE("조금만 더 또렷하게 보여주세요"),
    NO_FACE("얼굴이 인식되지 않았어요.\n카메라를 바라봐주세요"),

    OOM("메모리가 부족합니다. 다시 시도해주세요."),
    NO_SESSION("인증 대기자가 존재하지 않습니다."),
    UNKNOWN("일시적인 오류입니다. 잠시 후 다시 시도해주세요."),
    ALREADY_IN_PROGRESS("인증을 진행하고 있습니다..."),
    LIVENESS_NOT_CONFIRMED("실제 사람인지 확인 중입니다.\n잠시 멈춰주세요."),
    LIVENESS_TX_FAILED("인증에 실패하였습니다.\n다시 시도해주세요.")
}