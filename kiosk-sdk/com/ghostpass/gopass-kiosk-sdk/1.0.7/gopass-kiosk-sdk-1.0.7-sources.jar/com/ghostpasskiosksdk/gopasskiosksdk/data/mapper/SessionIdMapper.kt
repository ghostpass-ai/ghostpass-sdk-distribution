package com.ghostpasskiosksdk.gopasskiosksdk.data.mapper

import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.SseSessionCreatedDto
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SseSessionPayload

internal fun SseSessionCreatedDto.toDomain(): SseSessionPayload {
    return SseSessionPayload(
        sessionId = sessionId,
        rtdbPath = rtdbPath,
        encryptedKioskDk = encryptedKioskDk,
        firebaseToken = firebaseToken,
        expiresAtMillis = parseExpiresAtMillis(expiresAt),
        deviceId = deviceId
    )
}