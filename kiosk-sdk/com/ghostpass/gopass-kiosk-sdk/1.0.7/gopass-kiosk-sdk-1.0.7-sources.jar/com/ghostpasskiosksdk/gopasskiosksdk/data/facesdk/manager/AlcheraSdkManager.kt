package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.manager

import android.content.Context
import com.alcherainc.facesdk.AntispoofingExtension
import com.alcherainc.facesdk.FaceSDK
import com.alcherainc.facesdk.FeatureExtension
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.mapper.toInternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceEngineManager
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.IOException

internal class AlcheraSdkManager(
    private val context: Context
) : FaceEngineManager {
    companion object {
        val TAG = "AlcheraSdkManager ${BuildConfig.SIGNATURE}"
    }

    private val initMutex = Mutex()
    @Volatile
    private var initialized = false

    val faceSdk: FaceSDK = FaceSDK()

    lateinit var featureExtension: FeatureExtension
        private set // 외부에서 값을 바꿀 수 없도록 방어

    lateinit var antispoofingExtension: AntispoofingExtension
        private set

    override suspend fun initialize() {
        initMutex.withLock {
            if (initialized) return

            try {
                // 1. 모델 파일 경로 설정 및 복사
                val modelDir = File(context.filesDir, "facesdk/bin").absolutePath
                copyModelsIfNeeded(context, "bin", modelDir)

                val initResult = faceSdk.Initialize(modelDir)
                if (!initResult.result) {
                    throw GoPassSdkException.from(
                        error = ErrorCode.INIT_FAILED,
                        cause = initResult.last_error.toInternalErrorCode()
                    )
                }

                // 3. 익스텐션 활성화
                featureExtension = faceSdk.GetFeatureExtension().apply {
                    val enableResult = Enable()
                    if (!enableResult.result) throw GoPassSdkException.from(
                        error = ErrorCode.INIT_FAILED,
                        cause = enableResult.last_error.toInternalErrorCode()
                    )
                }

                antispoofingExtension = faceSdk.GetAntispoofingExtension().apply {
                    val enableResult = Enable()
                    if (!enableResult.result) throw GoPassSdkException.from(
                        error = ErrorCode.INIT_FAILED,
                        cause = enableResult.last_error.toInternalErrorCode()
                    )
                }

                initialized = true
                debugLog(TAG, "FaceSDK 초기화 성공")

            } catch (e: GoPassSdkException) {
                errorLog(TAG, "초기화 중 예외 발생: ${e.message}")
                throw e
            } catch (e: IOException) {
                errorLog(TAG, "모델 파일 복사 실패: ${e.message}")
                throw GoPassSdkException.from(
                    error = ErrorCode.INIT_FAILED,
                    cause = InternalErrorCode.FACESDK_CAN_NOT_READ_MODEL
                )
            } catch (e: Exception) {
                errorLog(TAG, "초기화 중 알 수 없는 예외 발생: ${e.message}")
                throw GoPassSdkException.from(
                    error = ErrorCode.INIT_FAILED,
                    cause = InternalErrorCode.UNKNOWN
                )
            }
        }
    }

    private fun copyModelsIfNeeded(ctx: Context, assetFolder: String, targetDir: String) {
        val target = File(targetDir)
        if (target.exists() && target.listFiles()?.isNotEmpty() == true) return

        val tmp = File(target.parentFile, "${target.name}.tmp")
        if (tmp.exists()) tmp.deleteRecursively()
        if (!tmp.mkdirs()) throw IOException("임시 디렉토리 생성 실패: ${tmp.absolutePath}")

        try {
            copyAssets(ctx, assetFolder, tmp.absolutePath)
            if (tmp.listFiles()?.isEmpty() == true) {
                throw IOException("Asset 폴더가 비어있거나 복사되지 않았습니다.")
            }
            if (target.exists()) target.deleteRecursively()
            if (!tmp.renameTo(target)) {
                throw IOException("임시 폴더를 대상 폴더로 변경하는 데 실패했습니다.")
            }
        } catch (e: Exception) {
            tmp.deleteRecursively()
            throw e
        }
    }

    private fun copyAssets(context: Context, src: String, dst: String) {
        // ... 기존 코드와 완벽히 동일 ...
        val assetManager = context.assets
        val files = assetManager.list(src) ?: throw IOException("Asset 리스트를 가져올 수 없음: $src")

        for (filename in files) {
            val assetPath = if (src.isEmpty()) filename else "$src/$filename"
            val subFiles = assetManager.list(assetPath)
            if (subFiles?.isNotEmpty() == true) {
                val nextDst = File(dst, filename).apply { mkdirs() }
                copyAssets(context, assetPath, nextDst.absolutePath)
            } else {
                assetManager.open(assetPath).use { input ->
                    File(dst, filename).outputStream().use { out ->
                        input.copyTo(out)
                    }
                }
            }
        }
    }
}
