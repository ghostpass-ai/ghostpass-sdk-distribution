package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session

internal data class InitiatedSessionPayload(
    val sessionId: String,
    val rtdbPath: String,
    val encryptedDk: String,
    val firebaseToken: String,
    val expiresAtMillis: Long
)
