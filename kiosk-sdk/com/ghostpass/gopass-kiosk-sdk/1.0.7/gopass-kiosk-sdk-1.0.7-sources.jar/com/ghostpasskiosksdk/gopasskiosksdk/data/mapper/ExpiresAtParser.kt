package com.ghostpasskiosksdk.gopasskiosksdk.data.mapper

import android.os.Build
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

private val TAG = "ExpiresAtParser ${BuildConfig.SIGNATURE}"

/**
 * 서버가 전달하는 expiresAt(ISO 8601 UTC) 문자열을 epoch millis로 변환한다.
 * 파싱 실패 시 GoPassSdkException(INTERNAL_ERROR / IN-1401)을 throw한다.
 */
internal fun parseExpiresAtMillis(expiresAt: String): Long {
    expiresAt.toLongOrNull()?.let { return it }
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            java.time.Instant.parse(expiresAt).toEpochMilli()
        } else {
            val cleaned = expiresAt.substringBefore(".").removeSuffix("Z")
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }.parse(cleaned)?.time
                ?: throw IllegalArgumentException("Unparseable expiresAt: $cleaned")
        }
    } catch (e: Exception) {
        errorLog(TAG, "expiresAt 파싱 실패: $expiresAt, ${e.message}")
        throw GoPassSdkException.from(
            error = ErrorCode.INTERNAL_ERROR,
            cause = InternalErrorCode.SESSION_EXPIRES_AT_PARSE_FAILED
        )
    }
}
