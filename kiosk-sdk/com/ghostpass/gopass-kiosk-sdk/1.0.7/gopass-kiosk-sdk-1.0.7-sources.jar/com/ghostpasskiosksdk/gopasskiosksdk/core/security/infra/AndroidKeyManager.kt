package com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.security.keystore.KeyProtection
import android.util.Base64
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager.Companion.HMAC_ALIAS
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager.Companion.MASTER_KEY_ALIAS
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.spec.ECGenParameterSpec
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec

internal class AndroidKeyManager (
    private val context: Context
) : KeyManager {

    companion object {
        val TAG = "KeyStoreProvider ${BuildConfig.SIGNATURE}"
        private const val PROVIDER = "AndroidKeyStore"
        private const val ECDH_ALIAS = "GP_ECDH_KEY"
    }

    private val keyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    // API 31 미만 기기에서 ECDH 키쌍을 메모리에 임시 보관
    private var tempEcdhPrivateKey: PrivateKey? = null

    // Secret 키 가져오기
    override fun getSecretKey(alias: String): SecretKey {
        return (keyStore.getKey(alias, null) as? SecretKey)
            ?: if (alias == MASTER_KEY_ALIAS) {
                generateMasterKey()
            } else {
                throw GoPassSdkException.from(
                    error = ErrorCode.INTERNAL_ERROR,
                    cause = InternalErrorCode.SECRET_KEY_NOT_FOUND
                )
            }
    }

    // 기기 내부 전용 AES-256-GCM 키 생성 (StrongBox 보호)
    private fun generateMasterKey(): SecretKey {
        return try {
            KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER).apply {
                init(
                    KeyGenParameterSpec.Builder(
                    MASTER_KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .apply { setStrongBoxIfPossible() } // 공통 보안 설정 적용
                    .build())
            }.generateKey()
        } catch (e: Exception) {
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.MASTER_KEY_GENERATION_FAILED
            )
        }
    }

    // 외부 유도 키(HMAC)를 StrongBox에 주입
    override fun importSecretKey(alias: String, keyBytes: ByteArray) {
        try {
            val secretKey = SecretKeySpec(
                keyBytes,
                if (alias == HMAC_ALIAS) KeyProperties.KEY_ALGORITHM_HMAC_SHA256
                else KeyProperties.KEY_ALGORITHM_AES
            )

            val purpose = if (alias == HMAC_ALIAS) KeyProperties.PURPOSE_SIGN
            else KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT

            val builder = KeyProtection.Builder(purpose)
                .apply { setStrongBoxIfPossible() }
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            keyStore.setEntry(alias, KeyStore.SecretKeyEntry(secretKey), builder.build())
        } catch (e: Exception) {
            errorLog(TAG, "외부 유도 키 주입 실패 : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.IMPORT_ENROLLMENT_KEY_FAILED
            )
        }
    }

    // ECDH 키쌍 생성
    // API 31(S)+: AndroidKeyStore에 저장 (PURPOSE_AGREE_KEY 지원)
    // API 23-30: JCA 메모리 키 생성 후 tempEcdhPrivateKey에 임시 보관
    override fun generateEcdhKeyPair(): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, PROVIDER)
                val spec = KeyGenParameterSpec.Builder(ECDH_ALIAS, KeyProperties.PURPOSE_AGREE_KEY)
                    .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                    .build()
                kpg.initialize(spec)
                val publicKey = kpg.generateKeyPair().public
                Base64.encodeToString(publicKey.encoded, Base64.NO_WRAP)
            } else {
                val kpg = KeyPairGenerator.getInstance("EC")
                kpg.initialize(ECGenParameterSpec("secp256r1"))
                val keyPair = kpg.generateKeyPair()
                tempEcdhPrivateKey = keyPair.private
                Base64.encodeToString(keyPair.public.encoded, Base64.NO_WRAP)
            }
        } catch (e: Exception) {
            errorLog(TAG, "ECDH 키 쌍 생성 실패: $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.ECDH_KEY_GENERATION_FAILED
            )
        }
    }

    override fun hasSecretKey(alias: String): Boolean {
        return keyStore.containsAlias(alias) && keyStore.isKeyEntry(alias)
    }

    // 공통 strongbox 옵션
    @SuppressLint("NewApi")
    private fun <T> T.setStrongBoxIfPossible(): T {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {

            val hasStrongBox = context.packageManager.hasSystemFeature(
                PackageManager.FEATURE_STRONGBOX_KEYSTORE
            )

            if (hasStrongBox) {
                when (this) {
                    is KeyGenParameterSpec.Builder -> {
                        this.setIsStrongBoxBacked(true)
                    }

                    is KeyProtection.Builder -> {
                        this.setIsStrongBoxBacked(true)
                    }
                }
            }
        }

        return this
    }

    // 내부 개인키 가져오기 (Shared Key 생성용)
    // API 23-30: 메모리에서 꺼낸 후 즉시 null 처리하여 사용 후 제거
    override fun getPrivateKey(): PrivateKey {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            val key = tempEcdhPrivateKey ?: throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.PRIVATE_KEY_NOT_FOUND
            )
            tempEcdhPrivateKey = null
            return key
        }
        return try {
            keyStore.getKey(ECDH_ALIAS, null) as PrivateKey
        } catch (e: Exception) {
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.PRIVATE_KEY_NOT_FOUND
            )
        }
    }

    override fun deleteKey(alias: String) {
        if (keyStore.containsAlias(alias)) {
            keyStore.deleteEntry(alias)
        }
    }
}