package com.ghostpasskiosksdk.gopasskiosksdk.core.network.infra

import android.os.Build
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.RequestSigner
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.PreferenceStorage
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.verboseLog
import kotlinx.serialization.json.Json
import okhttp3.ConnectionSpec
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.TlsVersion
import okio.Buffer
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

internal class ApiClient(
    private val requestSigner: RequestSigner,
    private val preferenceStorage: PreferenceStorage
) {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        explicitNulls = false
        encodeDefaults = true
    }

    companion object {
        private val TAG = "ApiClient ${BuildConfig.SIGNATURE}"
        internal const val HEADER_SKIP_SIGNATURE = "X-Skip-Signature"
        private const val SKIP_SIGNATURE_VALUE = "true"
    }

    fun getSecureClientBuilder(): OkHttpClient.Builder = OkHttpClient.Builder()
        .connectionSpecs(
            listOf(
                ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                    .tlsVersions(TlsVersion.TLS_1_3, TlsVersion.TLS_1_2)
                    .build()
            )
        )
        .addInterceptor { chain ->
            val request = chain.request()

            val skipSignature = request.header(HEADER_SKIP_SIGNATURE) == SKIP_SIGNATURE_VALUE

            val currentApiKey = preferenceStorage.getApiKey()

            val requestBuilder = request.newBuilder().apply {
                removeHeader(HEADER_SKIP_SIGNATURE)
                currentApiKey?.let {header("X-API-Key", it) }
            }

            if (!skipSignature && requestSigner.isAvailable()) {
                val (ts, nonce) = buildMeta()

                val kioskId = preferenceStorage.getKioskId()

                kioskId?.let { requestBuilder.header("X-Kiosk-Id", it) }
                requestBuilder.header("X-Timestamp", ts)
                requestBuilder.header("X-Nonce", nonce)

                val bodyString = request.body?.let { body ->
                    val buffer = Buffer()
                    body.writeTo(buffer)
                    buffer.readUtf8()
                } ?: ""
                infoLog(TAG, "✅ request url : ${request.url}")
                verboseLog(TAG, "✅ request bodyString : $bodyString")

                val bodyHash = requestSigner.hashBody(bodyString)
                val stringToSign = "${request.method}\n${request.url.encodedPath}\n$ts\n$nonce\n$bodyHash"
                debugLog(TAG, "stringToSign : $stringToSign")

                val signature = requestSigner.sign(stringToSign)
                requestBuilder.header("X-Signature", signature)
            }

            chain.proceed(requestBuilder.build())
        }

    private fun buildMeta(): Pair<String, String> {
        val timestamp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Instant.now().toString()
        } else {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            sdf.format(Date())
        }
        val nonce = UUID.randomUUID().toString()
        return timestamp to nonce
    }

    fun buildRetrofit(baseUrl: String, okHttpClient: OkHttpClient): Retrofit {
        val contentType = "application/json".toMediaType()
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
    }
}