package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine.FaceEngineTypes
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthPrecheckResult
internal interface FaceDetectionEngine {
    fun checkMemory(width: Int, height: Int): FaceAuthPrecheckResult.Failed?

    fun createInputImage(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotation: Int
    ): FaceEngineTypes.FaceImageFrame

    fun detectFirstFace(inputImage: FaceEngineTypes.FaceImageFrame): FaceEngineTypes.DetectedFace?

    fun validatePose(face: FaceEngineTypes.DetectedFace): FaceAuthPrecheckResult.Failed?

    fun validatePosition(inputImage: FaceEngineTypes.FaceImageFrame, face: FaceEngineTypes.DetectedFace)
            : FaceAuthPrecheckResult.Failed?

    fun validateSizeMin(inputImage: FaceEngineTypes.FaceImageFrame, face:  FaceEngineTypes.DetectedFace)
            : FaceAuthPrecheckResult.Failed?

    fun validateSizeMax(inputImage: FaceEngineTypes.FaceImageFrame, face:  FaceEngineTypes.DetectedFace)
            : FaceAuthPrecheckResult.Failed?

    fun validateLandmarkConfidence(inputImage: FaceEngineTypes.FaceImageFrame, face:  FaceEngineTypes.DetectedFace)
            : FaceAuthPrecheckResult.Failed?

    fun validateFaceQuality(inputImage: FaceEngineTypes.FaceImageFrame, face: FaceEngineTypes.DetectedFace)
            : FaceAuthPrecheckResult.Failed?
}