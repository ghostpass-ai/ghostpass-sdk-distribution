package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.adapter

import com.alcherainc.facesdk.FaceSDK
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.manager.AlcheraSdkManager
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.policy.AlcheraDetectionPolicy
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.policy.AlcheraLivenessPolicy
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper.AlcheraDetectedFace
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper.AlcheraImageFrame
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine.FaceEngineTypes
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthChecks
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthPrecheckResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.FailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceDetectionEngine
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog

internal class AlcheraDetectionAdapter (
    private val sdkManager: AlcheraSdkManager
) : FaceDetectionEngine {
    companion object{
        val TAG = "AlcheraDetectionAdapter ${BuildConfig.SIGNATURE}"
    }

    override fun checkMemory(width: Int, height: Int): FaceAuthPrecheckResult.Failed? {
        val runtime = Runtime.getRuntime()
        val maxMemory = runtime.maxMemory()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val availableMemory = maxMemory - usedMemory
        val expectedImageSize = (width * height * 1.5).toLong()

        if (availableMemory < expectedImageSize * 2) {
            System.gc()
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(),
                reasons = listOf(FailReason.OOM)
            )
        }
        return null
    }

    override fun createInputImage(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotation: Int
    ): FaceEngineTypes.FaceImageFrame {
        val inputImage = FaceSDK.GetInputImageFromNV21Buffer(
            faceImage, width, height, rotation, true
        )
        return AlcheraImageFrame(inputImage)
    }

    override fun detectFirstFace(inputImage: FaceEngineTypes.FaceImageFrame): FaceEngineTypes.DetectedFace? {
        return try {
            val alcheraImage = (inputImage as AlcheraImageFrame).originImage

            val facesResult = sdkManager.faceSdk.DetectFaceInContinuousImage(alcheraImage)

            val firstFace = facesResult?.faces?.firstOrNull()

            firstFace?.let { AlcheraDetectedFace(it) }
        } catch (e: Exception) {
            errorLog(TAG, "detect first face error : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.DETECT_FIRST_FACE_FAILED
            )
        }
    }

    override fun validatePose(face: FaceEngineTypes.DetectedFace): FaceAuthPrecheckResult.Failed? {
        val pose = (face as AlcheraDetectedFace).originFace.pose

        val failReasons = AlcheraDetectionPolicy.poseFailures(
            rollDegree = pose.roll_degree,
            pitchDegree = pose.pitch_degree,
            yawDegree = pose.yaw_degree,
        )
        return if (failReasons.isNotEmpty()) {
            FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(),
                reasons = failReasons
            )
        } else {
            null
        }
    }

    override fun validatePosition(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        return if (
            !AlcheraDetectionPolicy.isCentered(
                imageWidth = nativeImage.width,
                imageHeight = nativeImage.height,
                faceX = nativeFace.box.x,
                faceY = nativeFace.box.y,
                faceWidth = nativeFace.box.width,
                faceHeight = nativeFace.box.height,
            )
        ) {
            FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(isValidPose = true),
                reasons = listOf(FailReason.INVALID_POSITION)
            )
        } else {
            null
        }
    }

    override fun validateSizeMin(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        if (!AlcheraDetectionPolicy.isValidMinFaceSize(nativeImage.width, nativeFace.box.width)) {
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(
                    isValidPose = true,
                    isValidPosition = true
                ),
                reasons = listOf(FailReason.INVALID_SIZE_MIN)
            )
        }
        return null
    }

    override fun validateSizeMax(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        if (!AlcheraDetectionPolicy.isValidMaxFaceSize(nativeImage.width, nativeFace.box.width)) {
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(
                    isValidPose = true,
                    isValidPosition = true,
                    isValidSizeMin = true),
                reasons = listOf(FailReason.INVALID_SIZE_MAX)
            )
        }
        return null
    }

    override fun validateLandmarkConfidence(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        val confidence = sdkManager.faceSdk.ComputeLandmarkConfidence(nativeImage, nativeFace)
        if (!AlcheraDetectionPolicy.isValidLandmarkConfidence(confidence.confidence)) {
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks.ALL_PASSED,
                reasons = listOf(FailReason.LOW_LANDMARK_CONFIDENCE)
            )
        }
        return null
    }

    override fun validateFaceQuality(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceAuthPrecheckResult.Failed? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        val quality = sdkManager.featureExtension.EstimateFaceQuality(nativeImage, nativeFace, false)
        debugLog(TAG, "faceQuality : ${quality.quality}")
        if (!AlcheraLivenessPolicy.shouldCollectFrame(quality.quality)) {
            return FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks.ALL_PASSED,
                reasons = listOf(FailReason.LOW_FACE_QUALITY)
            )
        }
        return null
    }
}
