package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken

internal interface RemoteStateChannelRepository {
    suspend fun observeSessionId(
        sessionIds: Set<SessionData>,
        tokenMap: Map<String, AuthToken>,
        expectedSeqMap: Map<String, Int>,
        timeoutMs: Long = 5000L
    ): SessionIdEvent
    suspend fun authenticateSessions(
        sessions: Set<SessionData>
    ): Map<SessionData, Result<AuthToken>>
    suspend fun updateKioskSecureData(
        sessionPayloads: Map<SessionData, EncryptedSessionPayload>,
        tokenMap: Map<SessionData, AuthToken>
    ): Map<SessionData, Result<Unit>>
    suspend fun clearUserToKioskData(
        sessions: Set<SessionData>,
        tokenMap: Map<String, AuthToken>
    )
    suspend fun clearKioskToUserData(
        sessions: Set<SessionData>,
        tokenMap: Map<String, AuthToken>
    )
}
