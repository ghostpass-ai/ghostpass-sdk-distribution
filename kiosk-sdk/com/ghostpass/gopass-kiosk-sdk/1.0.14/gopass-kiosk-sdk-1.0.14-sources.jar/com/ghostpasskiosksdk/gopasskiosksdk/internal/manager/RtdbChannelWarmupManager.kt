package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase.ExecuteRemoteAuthUseCase
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.cancellation.CancellationException

/**
 * 인증 크리티컬 경로(kiosk_to_user PATCH → user_to_kiosk SSE)가 커넥션 수립
 * 비용(DNS+TCP+TLS, 실측 ~100–140ms) 없이 시작되도록 RTDB 호스트 커넥션을 미리 데워둔다.
 *
 * 동작 규칙:
 * - 활성 세션 집합이 변경되면 즉시 warm-up, 이후 활성 세션이 있는 동안 [rewarmIntervalMs] 주기로 re-warm
 * - re-warm은 NAT 등 중간 장비의 idle 소켓 무음 절단(stale socket)을 막는 keep-alive 역할.
 *   주기는 반드시 커넥션 풀 keep-alive(5분)보다 짧아야 한다
 * - RTDB는 http/1.1이라 커넥션 1개 = 동시 요청 1개이므로, 활성 세션 수만큼 병렬로 데운다
 * - 요청은 기존 kiosk_to_user seq 조회(GET)를 재사용하고 결과는 버린다
 * - best-effort: 모든 실패는 로그만 남기고 무시하며 인증 플로우를 절대 막지 않는다
 */
internal class RtdbChannelWarmupManager(
    private val remoteAuthUseCase: ExecuteRemoteAuthUseCase,
    private val sessions: StateFlow<Set<SessionData>>,
    private val authTokenProvider: (sessionId: String) -> AuthToken?,
    private val rewarmIntervalMs: Long = REWARM_INTERVAL_MS,
    private val tokenWaitIntervalMs: Long = TOKEN_WAIT_INTERVAL_MS,
    dispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    companion object {
        private val TAG = "RtdbChannelWarmup ${BuildConfig.SIGNATURE}"

        // 미들박스 idle 절단 대역(수십 초~수 분)보다 짧고 풀 keep-alive(5분)보다 짧게 유지
        private const val REWARM_INTERVAL_MS = 60_000L

        // 동시에 데울 커넥션 상한 = firebaseOkHttp 풀의 idle 보관 상한과 동일
        private const val MAX_PARALLEL_WARMUPS = 8

        // 세션 도착 직후 사전 인증(signIn, 실측 ~500ms) 완료 대기: 250ms × 8 = 최대 2s
        private const val TOKEN_WAIT_INTERVAL_MS = 250L
        private const val TOKEN_WAIT_MAX_ATTEMPTS = 8
    }

    private val managerScope = CoroutineScope(SupervisorJob() + dispatcher)
    private val isStarted = AtomicBoolean(false)

    @Volatile
    private var isDestroyed = false

    fun start() {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 warm-up 시작 요청은 무시됩니다.")
            return
        }
        if (!isStarted.compareAndSet(false, true)) return

        managerScope.launch {
            // collectLatest: 세션 집합이 바뀌면 진행 중인 re-warm 루프를 취소하고
            // 새 집합 기준으로 즉시 warm-up부터 다시 시작한다
            sessions.collectLatest { activeSessions ->
                if (activeSessions.isEmpty()) return@collectLatest
                while (true) {
                    warmUpAll(activeSessions)
                    delay(rewarmIntervalMs)
                }
            }
        }
        debugLog(TAG, "[WARM_UP] RTDB 커넥션 warm-up 시작 (주기 ${rewarmIntervalMs}ms)")
    }

    private suspend fun warmUpAll(activeSessions: Set<SessionData>) = coroutineScope {
        if (activeSessions.size > MAX_PARALLEL_WARMUPS) {
            warnLog(TAG, "[WARM_UP] 활성 세션 ${activeSessions.size}개 중 ${MAX_PARALLEL_WARMUPS}개만 warm-up (풀 idle 상한)")
        }
        val targets = activeSessions.take(MAX_PARALLEL_WARMUPS)

        // 1단계: 전 세션 토큰 확보(병렬 대기) 후 배리어.
        // 토큰 준비 시차로 GET이 순차 실행되면 http/1.1 특성상 같은 idle 커넥션을 돌려쓰게 되어
        // 세션 수보다 적은 커넥션만 데워진다 → 다음 k2u PATCH 일부가 NEW로 시작하는 결함
        val readySessions = targets
            .map { session -> async { awaitAuthToken(session.sessionId)?.let { session to it } } }
            .awaitAll()
            .filterNotNull()

        targets.filter { target -> readySessions.none { it.first.sessionId == target.sessionId } }
            .forEach { warnLog(TAG, "[WARM_UP] 사전 인증 토큰 미준비로 skip [${it.sessionId}] (다음 주기에 재시도)") }

        // 2단계: GET 동시 발사 — 동시 요청은 서로 다른 커넥션을 강제하므로 세션 수만큼 데워진다
        readySessions
            .map { (session, idToken) -> async { warmUpSession(session, idToken) } }
            .awaitAll()
    }

    private suspend fun warmUpSession(session: SessionData, idToken: String) {
        try {
            // 초경량 인증 GET — 응답값은 버리고, DNS+TCP+TLS 수립 후 풀에 idle 반납되는 것이 목적
            remoteAuthUseCase.fetchKioskToUserSeq(session.rtdbPath, idToken)
            debugLog(TAG, "[WARM_UP] RTDB 커넥션 warm-up 완료 [${session.sessionId}]")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            warnLog(TAG, "[WARM_UP] 실패 무시 [${session.sessionId}]: ${e.message}")
        }
    }

    /**
     * 세션 도착 직후에는 사전 인증이 아직 진행 중일 수 있으므로 토큰 캐싱을 잠시 대기한다.
     * 상한 초과 시 null을 반환하고 다음 re-warm 주기에서 재시도된다.
     */
    private suspend fun awaitAuthToken(sessionId: String): String? {
        repeat(TOKEN_WAIT_MAX_ATTEMPTS) {
            authTokenProvider(sessionId)?.let { return it.idToken }
            delay(tokenWaitIntervalMs)
        }
        return null
    }

    /**
     * 모든 자원을 정리합니다. 이 메서드 호출 후 인스턴스는 더 이상 사용할 수 없습니다.
     */
    fun destroy() {
        if (isDestroyed) {
            warnLog(TAG, "RtdbChannelWarmupManager destroy 중복 호출은 무시됩니다.")
            return
        }
        isDestroyed = true
        managerScope.coroutineContext[Job]?.cancel()
        warnLog(TAG, "RtdbChannelWarmupManager 전체 자원 정리 완료")
    }
}
