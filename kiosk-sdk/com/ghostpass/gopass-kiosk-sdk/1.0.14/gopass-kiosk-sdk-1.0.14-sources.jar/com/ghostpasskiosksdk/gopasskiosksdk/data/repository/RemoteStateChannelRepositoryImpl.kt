package com.ghostpasskiosksdk.gopasskiosksdk.data.repository

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.data.api.FirebaseApi
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.auth.AuthPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.CustomTokenSignInRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.FirebaseSseWrapperDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.KioskToUserPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.toDomain
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.SdkDiagnosticEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.AuthPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemoteStateChannelRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.DiagnosticEventBus
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.useAndWipe
import com.ghostpasskiosksdk.gopasskiosksdk.utils.verboseLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.retryWhen
import kotlinx.coroutines.flow.transform
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json.Default.decodeFromString
import kotlinx.serialization.json.Json.Default.parseToJsonElement
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import java.security.Key
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

internal class RemoteStateChannelRepositoryImpl(
    private val firebaseApi: FirebaseApi,
    private val okHttpClient: OkHttpClient,
    private val cryptoEngine: CryptoEngine,
    private val firebaseDbUrl: String = BuildConfig.FB_DB_URL,
    private val sseReconnectBaseDelayMs: Long = SSE_RECONNECT_BASE_DELAY_MS
) : RemoteStateChannelRepository {

    companion object {
        val TAG = "RemoteStateChannelRepo ${BuildConfig.SIGNATURE}"
        const val KIOSK_TO_USER = "kiosk_to_user"
        const val USER_TO_KIOSK = "user_to_kiosk"

        // observe 타임아웃(7s) 창 이내에서만 재연결: 500ms → 1s → 2s (지연 합계 3.5s)
        private const val MAX_SSE_RECONNECT_ATTEMPTS = 3L
        private const val SSE_RECONNECT_BASE_DELAY_MS = 500L
    }

    private sealed class DecodeResult {
        data class Success(val sessionId: String, val deviceId: String) : DecodeResult()
        data class Error(val sessionId: String, val reason: FaceAuthFailReason) : DecodeResult()
    }

    override suspend fun observeSessionId(
        sessionIds: Set<SessionData>,
        tokenMap: Map<String, AuthToken>,
        expectedSeqMap: Map<String, Int>,
        timeoutMs: Long
    ): SessionIdEvent {
        debugLog(TAG, "[OBSERVE] 세션 관찰 시작: ${sessionIds.size}개, expectedSeqMap=$expectedSeqMap")
        if (sessionIds.isEmpty()) return SessionIdEvent.Failed(FaceAuthFailReason.EMPTY_SESSION_IDS)

        val flowList = sessionIds.map { session ->
            flow {
                val idToken = tokenMap[session.sessionId]?.idToken
                    ?: throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = InternalErrorCode.FB_AUTH_NULL
                    )
                val expectedSeq = expectedSeqMap[session.sessionId]
                    ?: throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = InternalErrorCode.OBSERVE_SEQ_MAP_MISSING
                    )
                observeSingleSessionSseWithRetry(session, idToken, expectedSeq).collect { emit(it) }
            }.catch { e ->
                errorLog(TAG, "세션 [${session.sessionId}] 옵저빙 실패: ${e.message}")
                emit(DecodeResult.Error(session.sessionId, FaceAuthFailReason.UNKNOWN))
            }
        }

        val result = withTimeoutOrNull(timeoutMs) {
            val failedSessionIds = mutableSetOf<String>()
            val totalSessions = sessionIds.size

            flowList.merge().transform { res ->
                when (res) {
                    is DecodeResult.Success -> {
                        emit(res) // 🚨 1명이라도 성공하면 즉시 방출 후 종료 (나머지 세션 소켓 자동 파기)
                    }
                    is DecodeResult.Error -> {
                        val isNew = failedSessionIds.add(res.sessionId)
                        if (!isNew) {
                            debugLog(TAG, "[OBSERVE] 중복 FAIL 무시 [${res.sessionId}], 현재 실패 세션: ${failedSessionIds.size}/$totalSessions")
                        }
                        if (isNew && failedSessionIds.size >= totalSessions) {
                            debugLog(TAG, "[OBSERVE] 전원 실패 확정: failedSessionIds=$failedSessionIds")
                            emit(res) // 🚨 전원 실패 시, 타임아웃까지 기다리지 않고 즉시 에러 방출 후 종료
                        }
                    }
                }
            }.firstOrNull()
        }

        return when (result) {
            is DecodeResult.Success -> SessionIdEvent.Success(result.sessionId, result.deviceId)
            is DecodeResult.Error -> SessionIdEvent.Failed(FaceAuthFailReason.ALL_FAILED)
            null -> SessionIdEvent.Failed(FaceAuthFailReason.TIMEOUT)
        }
    }

    private suspend fun authenticate(customToken: String): AuthToken {
        val request = CustomTokenSignInRequest(token = customToken, returnSecureToken = true)
        val response = firebaseApi.signInWithCustomToken(BuildConfig.FB_API_KEY, request)
        if (response.isSuccessful) {
            val body = response.body() ?: throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.FB_AUTH_NULL
            )
            return AuthToken(idToken = body.idToken)
        } else {
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.FIREBASE_AUTH_SIGNIN_FAILED
            )
        }
    }

    /**
     * SSE 연결 실패/단절 시 지수 백오프로 최대 [MAX_SSE_RECONNECT_ATTEMPTS]회 재연결한다.
     * 소진 시 rethrow → observeSessionId의 catch가 DecodeResult.Error로 변환한다.
     */
    private fun observeSingleSessionSseWithRetry(
        session: SessionData,
        idToken: String,
        expectedSeq: Int
    ): Flow<DecodeResult> = observeSingleSessionSse(session, idToken, expectedSeq)
        .retryWhen { cause, attempt ->
            if (attempt >= MAX_SSE_RECONNECT_ATTEMPTS) {
                errorLog(
                    TAG,
                    "[OBSERVE] SSE 재연결 ${MAX_SSE_RECONNECT_ATTEMPTS}회 소진, 세션 FAIL [${session.sessionId}]: ${cause.message}"
                )
                false
            } else {
                val delayMs = sseReconnectBaseDelayMs shl attempt.toInt()
                warnLog(
                    TAG,
                    "[OBSERVE] SSE 재연결 예약 [${session.sessionId}]: attempt=${attempt + 1}/$MAX_SSE_RECONNECT_ATTEMPTS, ${delayMs}ms 후"
                )
                delay(delayMs)
                true
            }
        }

    private fun observeSingleSessionSse(
        session: SessionData,
        idToken: String,
        expectedSeq: Int
    ): Flow<DecodeResult> = callbackFlow {
        // 🚨 키오스크는 유저가 보낸 데이터를 관찰해야 하므로 USER_TO_KIOSK 경로 구독
        val sseUrl = "$firebaseDbUrl${session.rtdbPath.trimEnd('/')}/$USER_TO_KIOSK.json?auth=$idToken"
        val cancelledByUs = AtomicBoolean(false)
        var lastLoggedSeq: Int? = null

        debugLog(TAG, "[OBSERVE] user_to_kiosk SSE 구독 시작 [${session.sessionId}], expectedSeq=$expectedSeq")

        val request = Request.Builder()
            .url(sseUrl)
            .header("Accept", "text/event-stream")
            .build()

        val sseClient = okHttpClient.newBuilder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .apply {
                // okhttp-sse(RealEventSource.connect)가 EventListener를 강제 제거(NONE)하므로
                // SSE 커넥션 진단(ConnDiag의 conn= 값과 대조)은 interceptor로 수행. 디버그 빌드 전용
                if (BuildConfig.DEBUG) {
                    addNetworkInterceptor { chain ->
                        // 주의: query에 auth 토큰이 있으므로 encodedPath만 로깅
                        warnLog(
                            TAG,
                            "[SSE_CONN] conn=${System.identityHashCode(chain.connection())} " +
                                "${chain.request().method} ${chain.request().url.encodedPath}"
                        )
                        chain.proceed(chain.request())
                    }
                }
            }
            .build()
        val factory = EventSources.createFactory(sseClient)

        val eventSource = factory.newEventSource(request, object : EventSourceListener() {
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                if (data == "null") return
                if (type != "put" && type != "patch") {
                    // keep-alive 등은 무시, 스트림 취소/토큰 만료는 재연결 경로로
                    if (type == "cancel" || type == "auth_revoked") {
                        warnLog(TAG, "[OBSERVE] SSE $type 이벤트 수신 [${session.sessionId}], 재연결 대상")
                        close(GoPassSdkException.from(error = ErrorCode.NETWORK_ERROR, cause = InternalErrorCode.SSE_STREAM_UNKNOWN_ERROR))
                    }
                    return
                }

                val wrapper = try {
                    // Firebase REST API의 SSE 이벤트 래퍼 파싱
                    decodeFromString<FirebaseSseWrapperDto>(data)
                } catch (e: Exception) {
                    val path = data.extractSsePathForLog()
                    errorLog(TAG, "SSE 데이터 파싱 실패 [${session.sessionId}]: type=$type, path=$path, ${e.message}")
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.ObserveError(
                            sessionId = session.sessionId,
                            reason = "sse_parse_error",
                            errorDetail = "type=$type, path=$path, $e"
                        )
                    }
                    return
                }

                // 노드 미존재 initial put: {"path":"/","data":null}
                val payloadMap = wrapper.data ?: return

                if (payloadMap.seq != expectedSeq) {
                    if (lastLoggedSeq != payloadMap.seq) {
                        warnLog(
                            TAG,
                            "[OBSERVE] stale AUTH_RESULT 무시 [${session.sessionId}]: expectedSeq=$expectedSeq, actualSeq=${payloadMap.seq}"
                        )
                        lastLoggedSeq = payloadMap.seq
                    }
                    return
                }

                debugLog(TAG, "[OBSERVE] expected AUTH_RESULT 수신 [${session.sessionId}]: seq=${payloadMap.seq}")
                trySend(decodeAuthEvent(payloadMap.payload, session.sessionId, payloadMap.seq, session.dkKiosk))
            }

            override fun onClosed(eventSource: EventSource) {
                if (cancelledByUs.get()) return
                warnLog(TAG, "[OBSERVE] SSE 스트림 서버측 종료 [${session.sessionId}], 재연결 대상")
                close(GoPassSdkException.from(error = ErrorCode.NETWORK_ERROR, cause = InternalErrorCode.SSE_STREAM_UNKNOWN_ERROR))
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                if (cancelledByUs.get()) {
                    debugLog(TAG, "세션 [${session.sessionId}] SSE 정상 종료 (cancel)")
                    return
                }
                errorLog(TAG, "SSE 연결 에러 [${session.sessionId}]: httpCode=${response?.code}, ${t?.message}")
                DiagnosticEventBus.emit {
                    SdkDiagnosticEvent.ObserveError(
                        sessionId = session.sessionId,
                        reason = "sse_connection_failure",
                        errorDetail = "httpCode=${response?.code}, ${t?.toString()}"
                    )
                }
                close(GoPassSdkException.from(error = ErrorCode.NETWORK_ERROR, cause = InternalErrorCode.SSE_STREAM_UNKNOWN_ERROR))
            }
        })

        awaitClose {
            cancelledByUs.set(true)
            debugLog(TAG, "🛑 세션 [${session.sessionId}] SSE 구독 해제")
            eventSource.cancel()
        }
    }

    private fun decodeAuthEvent(payload: String, sid: String, seq: Int, key: Key): DecodeResult {
        if (seq < 1) {
            errorLog(TAG, "비정상적인 메시지 순서 (Replay 공격 의심): seq=$seq")
            return DecodeResult.Error(sid, FaceAuthFailReason.UNKNOWN)
        }
        val decryptedJson = try {
            val aadString = "${sid}:${seq}:u2k"

            cryptoEngine.decryptData(
                key = key,
                encryptedBase64 = payload,
                aad = aadString.toByteArray(Charsets.UTF_8)
            ).useAndWipe { safeBytes ->
                String(safeBytes, Charsets.UTF_8)
            }

        } catch (e: Exception) {
            errorLog(TAG, "decryptedJson error : $e")
            DiagnosticEventBus.emit {
                SdkDiagnosticEvent.ObserveError(
                    sessionId = sid,
                    reason = "decryption_error",
                    errorDetail = "seq=$seq, ${e.toString()}"
                )
            }
            return DecodeResult.Error(sid, FaceAuthFailReason.DECRYPTION_ERROR)
        }

        verboseLog(TAG, " decryptedJson : $decryptedJson")

        return try {
            val dto = decodeFromString<AuthPayloadDto>(decryptedJson)
            infoLog(TAG, "AuthPayload : $dto")
            val domain = dto.toDomain()

            if (domain is AuthPayload.Success) {
                DecodeResult.Success(sid, domain.deviceId)
            } else {
                DecodeResult.Error(sid, FaceAuthFailReason.UNKNOWN)
            }
        } catch (e: Exception) {
            errorLog(TAG, "AuthPayloadDto error : $e")
            DiagnosticEventBus.emit {
                SdkDiagnosticEvent.ObserveError(
                    sessionId = sid,
                    reason = "auth_payload_parse_error",
                    errorDetail = "seq=$seq, ${e.toString()}"
                )
            }
            DecodeResult.Error(sid, FaceAuthFailReason.PARSE_ERROR)
        }
    }

    override suspend fun authenticateSessions(
        sessions: Set<SessionData>
    ): Map<SessionData, Result<AuthToken>> = coroutineScope {
        debugLog(TAG, "authenticateSessions 병렬 인증 시작: ${sessions.size}개 세션")

        sessions.map { session ->
            async {
                val result = runCatching { authenticate(session.firebaseToken) }
                session to result
            }
        }.awaitAll().toMap()
    }

    override suspend fun updateKioskSecureData(
        sessionPayloads: Map<SessionData, EncryptedSessionPayload>,
        tokenMap: Map<SessionData, AuthToken>
    ): Map<SessionData, Result<Unit>> = coroutineScope {
        debugLog(TAG, "updateKioskSecureData 일괄 업데이트 진행: ${sessionPayloads.size}개 세션")

        sessionPayloads.map { (session, payload) ->
            async {
                val result = runCatching {
                    val authToken = tokenMap[session] ?: throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = InternalErrorCode.FB_AUTH_NULL
                    )

                    // 🚨 키오스크가 유저에게 전송하므로 KIOSK_TO_USER 경로 업데이트
                    val path = "${session.rtdbPath.trimEnd('/')}/$KIOSK_TO_USER.json"

                    val dataToPush = KioskToUserPayloadDto(
                        payload = payload.encryptedData,
                        seq = payload.seq
                    )

                    val response = firebaseApi.updateSessionState("${BuildConfig.FB_DB_URL}$path", authToken.idToken, dataToPush)
                    if (!response.isSuccessful) {
                        val httpCode = response.code()
                        throw GoPassSdkException.from(
                            error = ErrorCode.INTERNAL_ERROR,
                            customMessage = "RTDB PATCH failed: HTTP $httpCode",
                            cause = when (httpCode) {
                                401 -> InternalErrorCode.CHANNEL_UPDATE_UNAUTHORIZED
                                403 -> InternalErrorCode.CHANNEL_UPDATE_FORBIDDEN
                                in 500..599 -> InternalErrorCode.CHANNEL_UPDATE_SERVER_ERROR
                                else -> InternalErrorCode.CHANNEL_UPDATE_UNEXPECTED_HTTP
                            }
                        )
                    }
                }
                result.onFailure { e ->
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.RtdbWriteResult(
                            sessionId = session.sessionId,
                            seq = payload.seq,
                            success = false,
                            errorDetail = e.toString()
                        )
                    }
                }
                session to result
            }
        }.awaitAll().toMap()
    }

    override suspend fun authenticateWithToken(firebaseToken: String): AuthToken {
        return authenticate(firebaseToken)
    }

    override suspend fun fetchKioskToUserSeq(rtdbPath: String, idToken: String): Int? {
        val url = "${BuildConfig.FB_DB_URL}${rtdbPath.trimEnd('/')}/$KIOSK_TO_USER.json"
        val response = try {
            firebaseApi.getKioskToUserSeq(url, idToken)
        } catch (e: SerializationException) {
            return null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            warnLog(TAG, "kiosk_to_user seq 조회 실패: ${e.message}")
            return null
        }
        if (!response.isSuccessful) {
            warnLog(TAG, "kiosk_to_user seq 조회 HTTP 실패: ${response.code()}")
            return null
        }
        return response.body()?.seq
    }

    private fun String.extractSsePathForLog(): String =
        runCatching {
            parseToJsonElement(this)
                .jsonObject["path"]
                ?.jsonPrimitive
                ?.contentOrNull
                ?: "unknown"
        }.getOrDefault("unknown")
}
