package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase

import kotlinx.serialization.Serializable

@Serializable
internal data class RtdbSeqDto(
    val seq: Int
)
