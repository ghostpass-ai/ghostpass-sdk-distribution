package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error

internal enum class InternalErrorCode(val code : String) {
    // -------------- Firebase --------------
    FIREBASE_INIT_FAILED("IN-1000"),
    FIREBASE_AUTH_SIGNIN_FAILED("IN-1001"),
    FB_AUTH_NULL("IN-1002"),


    // --------------  Google Play Integrity Token 실패 --------------
    INTEGRITY_PROVIDER_FAILED("IN-1100"), // Cloud Project Number, 구글 서비스 미설치 등의 문제
    INTEGRITY_TOKEN_FAILED("IN-1101"), // 할당량 초과, 기기 무결성 불일치


    // -------------- 서버 통신 중 error --------------
    PROVISION_ECDH_FAILED("IN-1200"),
    PROVISION_ATTESTATION_CHALLENGE_INVALID("IN-1201"),
    PROVISION_PROCESS_FAILED("IN-1202"),  // processProvisionResult 예상 외 예외

    // -------------- KEY 관련 --------------
    PRIVATE_KEY_NOT_FOUND("IN-1300"),
    SECRET_KEY_NOT_FOUND("IN-1301"),

    SHARED_KEY_GENERATION_FAILED("IN-1302"),
    ECDH_KEY_GENERATION_FAILED("IN-1303"),
    MASTER_KEY_GENERATION_FAILED("IN-1304"),

    IMPORT_ENROLLMENT_KEY_FAILED("IN-1305"),

    AES_KEY_DERIVATION_FAILED("IN-1306"),
    HMAC_KEY_DERIVATION_FAILED("IN-1307"),
    KIOSK_SECRET_DECRYPTION_FAILED("IN-1308"),

    PUBLIC_KEY_DECODE_FAILED("IN-1309"),
    TRANSPORT_KEY_DERIVATION_FAILED("IN-1310"),

    // -------------- API response 형식 error --------------
    INVALID_FORM("IN-1400"),
    SESSION_EXPIRES_AT_PARSE_FAILED("IN-1401"),


    // -------------- Detection 관련 --------------
    DETECT_FIRST_FACE_FAILED("IN-2000"),
    CONTAINER_IS_NULL("IN-2001"),

    // -------------- SSE 관련 --------------
    SSE_NETWORK_TIMEOUT("IN-3000"),
    SSE_INVALID_FORM("IN-3001"),
    SSE_STREAM_UNKNOWN_ERROR("IN-3002"),
    SSE_AUTH_TOKEN_INVALID("IN-3003"),
    SSE_FLOW_LAUNCH_FAILED("IN-3004"),  // SSE Flow 시작 전 치명적 예외

    // -------------- Face SDK (Alchera) --------------
    FACESDK_NO_ERROR("IN-4000"),
    FACESDK_NOT_INITIALIZED("IN-4001"),
    FACESDK_CAN_NOT_READ_MODEL("IN-4002"),
    FACESDK_INVALID_LICENSE("IN-4003"),
    FACESDK_LICENSE_EXPIRED("IN-4004"),
    FACESDK_UNKNOWN_LICENSE_ERROR("IN-4005"),
    FACESDK_CAN_NOT_OPEN_EXTENSION_FILE("IN-4006"),
    FACESDK_INVALID_EXTENSION("IN-4007"),
    FACESDK_DISABLED_EXTENSION("IN-4008"),
    FACESDK_NOT_PERMITTED_IN_THIS_LICENSE("IN-4009"),
    FACESDK_NOTHING_AT_INPUT("IN-4010"),
    FACESDK_MODEL_IS_NOT_INITIALIZED("IN-4011"),
    FACESDK_CAN_NOT_SET_GPUID_AFTER_INITIALIZATION("IN-4012"),
    FACESDK_CAN_NOT_SET_GPUID_WITHOUT_GPU("IN-4013"),
    FACESDK_CAN_NOT_READ_LICENSE("IN-4014"),
    FACESDK_SYSTEM_TIME_TAMPERED("IN-4015"),
    FACESDK_LICENSE_NOT_STARTED("IN-4016"),
    FACESDK_SYSTEM_FUNCTION_ERROR("IN-4017"),
    FACESDK_UNKNOWN_ERROR("IN-4018"),
    FACESDK_INIT_UNEXPECTED("IN-4019"),  // Face SDK 초기화 중 예상 외 예외

    CHANNEL_UPDATE_UNAUTHORIZED("IN-5000"),  // 401 - 토큰 만료/무효
    CHANNEL_UPDATE_FORBIDDEN("IN-5001"),     // 403 - 보안 규칙 위반
    CHANNEL_UPDATE_SERVER_ERROR("IN-5002"),  // 5xx - Firebase 서버 오류
    CHANNEL_UPDATE_UNEXPECTED_HTTP("IN-5003"), // 401/403/5xx 외 예상 외 HTTP 응답

    // -------------- Observe 관련 --------------
    OBSERVE_SEQ_MAP_MISSING("IN-5100"),  // observe 시 expectedSeqMap에 sessionId 누락

    // -------------- PreferenceStorage 복호화 실패 --------------
    PREF_API_KEY_DECRYPTION_FAILED("IN-6000"),
    PREF_KIOSK_ID_DECRYPTION_FAILED("IN-6001"),
    PREF_BEACON_CONFIG_DECRYPTION_FAILED("IN-6002"),

    UNKNOWN("IN-9999");

    companion object {
        fun fromCode(code: String): InternalErrorCode? = entries.find { it.code == code }
    }
}