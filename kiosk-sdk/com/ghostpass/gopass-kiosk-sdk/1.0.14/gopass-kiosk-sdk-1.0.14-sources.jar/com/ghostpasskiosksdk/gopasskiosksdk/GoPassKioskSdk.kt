package com.ghostpasskiosksdk.gopasskiosksdk

import android.content.Context
import androidx.annotation.Keep
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.KioskId
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.GoPassAuthResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.SdkDiagnosticEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.internal.di.SdkContainer
import com.ghostpasskiosksdk.gopasskiosksdk.utils.DiagnosticEventBus
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.jvm.Throws

@Keep
object GoPassKioskSdk {

    /**
     * 라이브니스(위조 방지) 검사 활성화 여부.
     * 기본값은 `false`(비활성)이며, `true`로 설정하면 얼굴 인증 시 라이브니스 검사를 수행합니다.
     */
    var livenessEnabled: Boolean = false

    val connectedDeviceIds: StateFlow<List<String>>
        get() = SdkContainer.requireInstance().authOrchestrator.connectedDeviceIds

    /**
     * 내부 진단 이벤트 스트림. 디버그 빌드에서만 이벤트가 발행됩니다.
     * 릴리즈 빌드에서는 이벤트가 발행되지 않습니다.
     */
    val diagnosticEvents: SharedFlow<SdkDiagnosticEvent>
        get() = DiagnosticEventBus.events

    @Throws(GoPassSdkException::class)
    suspend fun initialize(
        context: Context,
        apiKey: String,
        kioskId: KioskId,
        beaconConfig: BeaconConfig
    ): Boolean {
        val container = SdkContainer.getOrCreate(context)
        return try {
            container.infraManager.initialize(apiKey, kioskId, beaconConfig)
        } catch (t: Throwable) {
            SdkContainer.destroyInstance()
            throw t
        }
    }

    @Throws(GoPassSdkException::class)
    suspend fun detection(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotationDegrees: Int
    ): GoPassAuthResult {
        return SdkContainer.requireInstance().authOrchestrator.execute(
            faceImage = faceImage,
            width = width,
            height = height,
            rotation = rotationDegrees
        )
    }

    @Throws(GoPassSdkException::class)
    suspend fun preparePhoneAuth(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotationDegrees: Int
    ): GoPassAuthResult {
        return SdkContainer.requireInstance().authOrchestrator
            .prepareLandmarkForPhoneAuth(
                faceImage = faceImage,
                width = width,
                height = height,
                rotation = rotationDegrees
            )
    }

    @Throws(GoPassSdkException::class)
    suspend fun submitPhoneAuth(deviceId: String): GoPassAuthResult {
        return SdkContainer.requireInstance().authOrchestrator
            .executePhoneAuth(deviceId = deviceId)
    }

    @Throws(GoPassSdkException::class)
    suspend fun reset(): Boolean {
        try {
            return SdkContainer.requireInstance().infraManager.reset()
        } finally {
            SdkContainer.destroyInstance()
        }
    }
}
