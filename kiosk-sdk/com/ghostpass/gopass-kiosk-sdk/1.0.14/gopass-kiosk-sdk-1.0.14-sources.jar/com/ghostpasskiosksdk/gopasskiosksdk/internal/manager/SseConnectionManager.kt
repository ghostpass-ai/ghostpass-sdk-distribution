package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionInfoPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SseConnectionState
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SseEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemotePathRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.UnknownHostException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.pow

/**
 * SSE 연결의 생명주기(연결/재연결/해제)를 전담 관리한다.
 * AuthOrchestrator에서 SSE 연결 관련 책임을 분리하여 단일 책임 원칙을 준수한다.
 *
 * SSE 이벤트 수신 시 [EventListener]를 통해 상위 계층(AuthOrchestrator)에 위임한다.
 */
internal class SseConnectionManager(
    private val remotePathRepository: RemotePathRepository
) {

    companion object {
        private val TAG = "SseConnectionManager ${BuildConfig.SIGNATURE}"
        private const val MAX_EXPONENTIAL_BACKOFF_MS = 30_000L
        private const val AUTH_ERROR_DELAY_MS = 60_000L
    }

    /**
     * SSE 이벤트 수신 시 상위 계층에 위임하기 위한 리스너 인터페이스.
     */
    internal interface EventListener {
        suspend fun onSessionCreated(payload: SessionInfoPayload)
        fun onSessionTerminated(sessionId: String)
        fun onSessionSync(sessionIds: Set<String>)
    }

    var eventListener: EventListener? = null

    // ── SSE 연결 상태 ──────────────────────────────────────────────

    private val connectionScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _sseConnectionState =
        MutableStateFlow<SseConnectionState>(SseConnectionState.Disconnected)
    val sseConnectionState: StateFlow<SseConnectionState> = _sseConnectionState.asStateFlow()

    private var collectionJob: Job? = null

    // @Synchronized: collectionJob의 읽기-취소-재할당 복합 연산을 원자적으로 보호
    // AtomicBoolean: handleStreamCompletion()이 @Synchronized 블록 밖(onCompletion 콜백)에서
    //               isSseCollecting 상태를 안전하게 전이하기 위해 lock-free 원자성 사용
    private val isSseCollecting = AtomicBoolean(false)

    @Volatile
    private var hasEstablishedSseConnection = false

    @Volatile
    private var isDestroyed = false

    // ── Public API ─────────────────────────────────────────────────

    /**
     * SSE 연결을 중단합니다.
     */
    @Synchronized
    fun stopSessionCollection() {
        isSseCollecting.set(false)
        collectionJob?.cancel()
        collectionJob = null
        _sseConnectionState.value = SseConnectionState.Disconnected
        debugLog(TAG, "SSE 세션 수집 중단됨")
    }

    /**
     * SSE 연결을 시작합니다. (Public Entry Point)
     */
    @Synchronized
    fun startSessionCollection(force: Boolean = false): Boolean {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 SSE 수집 시작 요청은 무시됩니다.")
            return false
        }
        debugLog(
            TAG,
            "startSessionCollection 호출됨! connectionScope isActive: ${connectionScope.isActive}, force=$force"
        )

        val hasActiveCollection = isSseCollecting.get() && collectionJob?.isActive == true
        if (hasActiveCollection && !force) {
            debugLog(TAG, "이미 SSE 수집이 진행 중입니다.")
            return true
        }

        // force: 강제 재연결 요청 시 기존 연결을 파기하고 재시작
        // isSseCollecting == true && collectionJob 비활성: 좀비 상태 복구 (플래그는 true인데 실제 Job이 죽은 경우)
        // collectionJob?.isActive != true: Job이 없거나 이미 완료된 경우 정리
        if (force || isSseCollecting.get() || collectionJob?.isActive != true) {
            collectionJob?.cancel()
            collectionJob = null
            isSseCollecting.set(false)
        }

        if (!isSseCollecting.compareAndSet(false, true)) {
            debugLog(TAG, "SSE 수집 상태 전환에 실패했습니다.")
            return collectionJob?.isActive == true
        }

        return try {
            collectionJob = observeSseFlow()
            true
        } catch (e: Exception) {
            isSseCollecting.set(false)
            handleFatalError(e)
            false
        }
    }

    /**
     * SSE 강제 재연결을 수행합니다.
     */
    fun forceReconnect(reason: String): Boolean {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 SSE 강제 재연결 요청은 무시됩니다. ($reason)")
            return false
        }
        if (!connectionScope.isActive) {
            warnLog(TAG, "SSE 강제 재연결 실패: scope가 이미 종료됨 ($reason)")
            return false
        }

        warnLog(TAG, "SSE 강제 재연결 수행: $reason")
        return startSessionCollection(force = true)
    }

    /**
     * SSE 연결 상태를 기반으로 인증이 차단되어야 하는지 판단한다.
     *
     * - Error 상태: 항상 차단
     * - Connected: 차단하지 않음
     * - Connecting/Disconnected: 이전에 한 번이라도 SSE 연결에 성공했다면 차단
     *   (최초 연결 전 Connecting 상태에서는 인증을 허용)
     */
    fun isAuthBlockedBySseState(): Boolean {
        return when (_sseConnectionState.value) {
            is SseConnectionState.Error -> true
            SseConnectionState.Connected -> false
            SseConnectionState.Connecting,
            SseConnectionState.Disconnected -> hasEstablishedSseConnection
        }
    }

    /**
     * 모든 자원을 정리합니다.
     * 이 메서드 호출 후 인스턴스는 더 이상 사용할 수 없습니다.
     */
    fun destroy() {
        if (isDestroyed) {
            warnLog(TAG, "SseConnectionManager destroy 중복 호출은 무시됩니다.")
            return
        }

        isDestroyed = true
        stopSessionCollection()
        hasEstablishedSseConnection = false
        connectionScope.coroutineContext[Job]?.cancel()
        warnLog(TAG, "SseConnectionManager 전체 자원 정리 완료")
    }

    // ── Private ────────────────────────────────────────────────────

    /**
     * SSE Flow 파이프라인 조립 및 실행
     */
    private fun observeSseFlow(): Job {
        return connectionScope.launch {
            var reconnectAttempt = 0L
            val runningJob = currentCoroutineContext()[Job]

            while (currentCoroutineContext().isActive && !isDestroyed && isSseCollecting.get()) {
                _sseConnectionState.value = SseConnectionState.Connecting
                debugLog(TAG, "SSE Flow 수집 시작")

                try {
                    remotePathRepository.observePaths()
                        .flowOn(Dispatchers.IO)
                        .collect { event ->
                            when (event) {
                                is SseEvent.Connected -> {
                                    _sseConnectionState.value = SseConnectionState.Connected
                                    hasEstablishedSseConnection = true
                                    reconnectAttempt = 0L
                                    debugLog(TAG, "SSE 연결 확인됨")
                                }

                                is SseEvent.Heartbeat -> {
                                    debugLog(TAG, "SSE Heartbeat 수신")
                                }

                                is SseEvent.SessionCreated -> {
                                    if (_sseConnectionState.value != SseConnectionState.Connected) {
                                        _sseConnectionState.value = SseConnectionState.Connected
                                        hasEstablishedSseConnection = true
                                        reconnectAttempt = 0L
                                    }
                                    eventListener?.onSessionCreated(event.payload)
                                }

                                is SseEvent.SessionTerminated -> {
                                    eventListener?.onSessionTerminated(event.sessionId)
                                }

                                is SseEvent.SessionSync -> {
                                    eventListener?.onSessionSync(event.sessionIds)
                                }
                            }
                        }

                    if (!isSseCollecting.get()) {
                        break
                    }

                    _sseConnectionState.value = SseConnectionState.Disconnected
                    val delayTime = nextReconnectDelay(null, reconnectAttempt++)
                    warnLog(TAG, "SSE 재연결 예약됨 (${delayTime}ms 후)")
                    delay(delayTime)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    handleStreamError(e)
                    if (!isSseCollecting.get() || isDestroyed) {
                        break
                    }

                    val delayTime = nextReconnectDelay(e, reconnectAttempt++)
                    warnLog(TAG, "SSE 재연결 예약됨 (${delayTime}ms 후)")
                    delay(delayTime)
                }
            }

            if (collectionJob === runningJob) {
                isSseCollecting.set(false)
                if (!isDestroyed && _sseConnectionState.value !is SseConnectionState.Error) {
                    _sseConnectionState.value = SseConnectionState.Disconnected
                }
            }
        }
    }

    /**
     * SSE 스트림 에러 핸들링
     */
    private fun handleStreamError(e: Throwable) {
        val sdkException = when (e) {
            is GoPassSdkException -> e
            is UnknownHostException,
            is IOException -> GoPassSdkException.from(
                error = ErrorCode.NETWORK_ERROR,
                cause = InternalErrorCode.SSE_NETWORK_TIMEOUT
            )

            else -> GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.SSE_STREAM_UNKNOWN_ERROR
            )
        }

        errorLog(TAG, "SSE Stream Error 잡힘: ${sdkException.message}")
        _sseConnectionState.value = SseConnectionState.Error(sdkException)
    }

    /**
     * 재연결 지연 시간을 계산한다.
     * 인증 토큰 오류인 경우 고정 딜레이, 그 외에는 지수 백오프를 적용한다.
     */
    private fun nextReconnectDelay(cause: Throwable?, attempt: Long): Long {
        val cappedAttempt = if (attempt > 20) 20 else attempt.toInt()
        val isAuthError = cause is GoPassSdkException &&
            cause.causeCode == InternalErrorCode.SSE_AUTH_TOKEN_INVALID.code

        return when {
            isAuthError -> AUTH_ERROR_DELAY_MS
            else -> minOf(
                1000L * (2.0.pow((cappedAttempt + 1).toDouble())).toLong(),
                MAX_EXPONENTIAL_BACKOFF_MS
            )
        }
    }

    /**
     * Flow 실행 전 발생한 치명적 예외 핸들링
     */
    private fun handleFatalError(e: Exception) {
        errorLog(TAG, "Failed to start SSE: ${e.message}")
        val sdkException = e as? GoPassSdkException
            ?: GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.SSE_FLOW_LAUNCH_FAILED
            )
        _sseConnectionState.value = SseConnectionState.Error(sdkException)
    }
}
