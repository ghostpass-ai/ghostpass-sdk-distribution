package com.ghostpasskiosksdk.gopasskiosksdk.internal.di

import android.content.Context
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.infra.AndroidBluetoothProvider
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.infra.AndroidNetworkProvider
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.infra.ApiClient
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.infra.ConnDiagEventListenerFactory
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.JcaCryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.AndroidKeyManager
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.LocalDataEncryptor
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.RequestSigner
import com.ghostpasskiosksdk.gopasskiosksdk.data.api.FirebaseApi
import com.ghostpasskiosksdk.gopasskiosksdk.data.api.ProvisionApi
import com.ghostpasskiosksdk.gopasskiosksdk.data.api.SessionApi
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.adapter.AlcheraDetectionAdapter
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.adapter.AlcheraExtractAdapter
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.adapter.AlcheraLivenessAdapter
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.manager.AlcheraSdkManager
import com.ghostpasskiosksdk.gopasskiosksdk.data.gateway.BeaconBroadcasterImpl
import com.ghostpasskiosksdk.gopasskiosksdk.data.repository.AuthRepositoryImpl
import com.ghostpasskiosksdk.gopasskiosksdk.data.repository.PreferenceStorageImpl
import com.ghostpasskiosksdk.gopasskiosksdk.data.repository.RemotePathRepositoryImpl
import com.ghostpasskiosksdk.gopasskiosksdk.data.repository.RemoteStateChannelRepositoryImpl
import com.ghostpasskiosksdk.gopasskiosksdk.data.repository.SessionRepositoryImpl
import com.ghostpasskiosksdk.gopasskiosksdk.GoPassKioskSdk
import com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase.ExecuteRemoteAuthUseCase
import com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase.PrepareFaceAuthUseCase
import com.ghostpasskiosksdk.gopasskiosksdk.data.repository.ProvisionRepositoryImpl
import com.ghostpasskiosksdk.gopasskiosksdk.internal.manager.AuthOrchestrator
import com.ghostpasskiosksdk.gopasskiosksdk.internal.manager.InfrastructureManager
import com.ghostpasskiosksdk.gopasskiosksdk.internal.manager.RtdbChannelWarmupManager
import com.ghostpasskiosksdk.gopasskiosksdk.internal.manager.SessionManager
import com.ghostpasskiosksdk.gopasskiosksdk.internal.manager.SseConnectionManager
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.infra.ScreenStateMonitor
import com.ghostpasskiosksdk.gopasskiosksdk.internal.manager.SystemStateCoordinator
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

internal class SdkContainer private constructor(private val context: Context) {
    // 1. 기초 보안 및 네트워크 설정
    private val keyManager: KeyManager by lazy { AndroidKeyManager(context = context) }
    private val cryptoEngine: CryptoEngine by lazy { JcaCryptoEngine() }

    private val localDataEncryptor by lazy {
        LocalDataEncryptor(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    private val requestSigner by lazy {
        RequestSigner(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    private val apiClient by lazy {
        ApiClient(
            preferenceStorage = preferenceStorage,
            requestSigner = requestSigner
        )
    }

    private val concurrentDispatcher = okhttp3.Dispatcher().apply { maxRequestsPerHost = 50 }
    private val okHttpLazy = lazy {
        apiClient.getSecureClientBuilder()
            .dispatcher(concurrentDispatcher)
            .build()
    }
    private val okHttp by okHttpLazy

    // 인증 크리티컬 경로(k2u PATCH / u2k SSE / warm-up) 전용 디스패처 —
    // 메인 API 트래픽 급증이 Firebase 요청을 큐잉시키지 않도록 격리 (GoPassSDK CRITICAL 스펙과 동일)
    private val firebaseCriticalDispatcher = okhttp3.Dispatcher().apply {
        maxRequests = FIREBASE_MAX_REQUESTS
        maxRequestsPerHost = FIREBASE_MAX_REQUESTS_PER_HOST
    }
    private val firebaseOkHttpLazy = lazy {
        OkHttpClient.Builder()
            .dispatcher(firebaseCriticalDispatcher)
            // warm-up된 RTDB 커넥션(세션 수만큼)을 인증 시점까지 idle로 보관하기 위한 풀 스펙.
            // keep-alive(5분)는 re-warm 주기(60초)보다 반드시 길어야 한다
            .connectionPool(
                ConnectionPool(
                    FIREBASE_CRITICAL_MAX_IDLE_CONNECTIONS,
                    FIREBASE_KEEP_ALIVE_MINUTES,
                    TimeUnit.MINUTES
                )
            )
            .apply {
                // 커넥션 진단(NEW/REUSED, DNS/TLS 소요)은 디버그 빌드에서만 부착
                if (BuildConfig.DEBUG) {
                    eventListenerFactory(ConnDiagEventListenerFactory("FIREBASE"))
                }
            }
            .build()
    }
    private val firebaseOkHttp by firebaseOkHttpLazy
    private val retrofit by lazy { apiClient.buildRetrofit(BuildConfig.BASE_URL, okHttp) }
    private val firebaseRetrofit by lazy { apiClient.buildRetrofit(BuildConfig.FB_DB_URL, firebaseOkHttp) }
    private val provisionApi by lazy { retrofit.create(ProvisionApi::class.java) }
    private val sessionApi by lazy { retrofit.create(SessionApi::class.java) }
    private val firebaseApi by lazy { firebaseRetrofit.create(FirebaseApi::class.java) }

    // 2. 데이터 소스 및 저장소
    private val preferenceStorage by lazy {
        PreferenceStorageImpl(
            context = context,
            localDataEncryptor = localDataEncryptor
        )
    }
    private val authRepository by lazy { AuthRepositoryImpl(enrollmentApi = provisionApi) }
    private val remotePathRepository by lazy { RemotePathRepositoryImpl(okHttpClient = okHttp) }
    private val remoteStateChannelRepository by lazy {
        RemoteStateChannelRepositoryImpl(
            cryptoEngine = cryptoEngine,
            firebaseApi = firebaseApi,
            okHttpClient = firebaseOkHttp
        )
    }

    private val sessionRepository by lazy { SessionRepositoryImpl(sessionApi = sessionApi) }

    // 3. 얼굴 인식 엔진 (Alchera 구현체)
    // 인프라 매니저가 엔진을 초기화할 수 있도록 매니저 등록
    private val faceEngineManager by lazy { AlcheraSdkManager(context = context) }

    // UseCase에서 사용할 개별 엔진 어댑터
    private val faceDetectionEngine by lazy { AlcheraDetectionAdapter(sdkManager = faceEngineManager) }
    private val faceLivenessEngine by lazy { AlcheraLivenessAdapter(sdkManager = faceEngineManager) }
    private val faceExtractEngine by lazy { AlcheraExtractAdapter(sdkManager = faceEngineManager) }

    // 4. 비즈니스 로직 (UseCase)
    private val executeRemoteAuthUseCase by lazy {
        ExecuteRemoteAuthUseCase(
            remoteChannelRepository = remoteStateChannelRepository
        )
    }

    // GoPassKioskSdk.detection()에서 사용할 UseCase
    private val prepareFaceAuthUseCase by lazy {
        PrepareFaceAuthUseCase(
            detectionEngine = faceDetectionEngine,
            livenessEngine = faceLivenessEngine,
            extractEngine = faceExtractEngine,
            livenessEnabled = { GoPassKioskSdk.livenessEnabled }
        )
    }

    private val bluetoothStateProvider by lazy { AndroidBluetoothProvider(context) }
    private val networkStateProvider by lazy { AndroidNetworkProvider(context) }

    private val screenStateMonitor by lazy { ScreenStateMonitor(context) }

    // 5. 관리 객체 (Manager / Orchestrator)
    internal val beaconBroadcaster by lazy {
        BeaconBroadcasterImpl(
            context = context,
            bluetoothStateProvider = bluetoothStateProvider
        )
    }

    private val provisionRepository by lazy {
        ProvisionRepositoryImpl(
            context = context,
            keyManager = keyManager,
            authRepository = authRepository,
            cryptoEngine = cryptoEngine,
            preferenceStorage = preferenceStorage
        )
    }

    private val systemStateCoordinator by lazy {
        SystemStateCoordinator(
            bluetoothStateProvider = bluetoothStateProvider,
            networkStateProvider = networkStateProvider,
            screenStateMonitor = screenStateMonitor,
            beaconBroadcaster = beaconBroadcaster,
            authOrchestrator = authOrchestrator
        )
    }

    internal val infraManager by lazy {
        InfrastructureManager(
            provisionRepository = provisionRepository,
            beaconBroadcaster = beaconBroadcaster,
            faceEngineManager = faceEngineManager,
            systemStateCoordinator = systemStateCoordinator
        )
    }

    private val sessionManager by lazy {
        SessionManager(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager,
            sessionRepository = sessionRepository,
            remoteAuthUseCase = executeRemoteAuthUseCase
        )
    }

    private val sseConnectionManager by lazy {
        SseConnectionManager(
            remotePathRepository = remotePathRepository
        )
    }

    private val rtdbChannelWarmupManager by lazy {
        RtdbChannelWarmupManager(
            remoteAuthUseCase = executeRemoteAuthUseCase,
            sessions = sessionManager.sessions,
            authTokenProvider = sessionManager::getCachedAuthToken
        )
    }

    internal val authOrchestrator by lazy {
        AuthOrchestrator(
            remoteAuthUseCase = executeRemoteAuthUseCase,
            cryptoEngine = cryptoEngine,
            prepareFaceAuthUseCase = prepareFaceAuthUseCase,
            networkStateProvider = networkStateProvider,
            sessionManager = sessionManager,
            sseConnectionManager = sseConnectionManager,
            rtdbChannelWarmupManager = rtdbChannelWarmupManager
        )
    }


    /**
     * 초기화된 OkHttp 클라이언트의 커넥션 풀과 디스패처를 정리합니다.
     * lazy 미초기화 상태에서는 불필요한 객체 생성을 방지합니다.
     */
    private fun release() {
        if (okHttpLazy.isInitialized()) {
            okHttp.connectionPool.evictAll()
            okHttp.dispatcher.executorService.shutdown()
        }
        if (firebaseOkHttpLazy.isInitialized()) {
            firebaseOkHttp.connectionPool.evictAll()
            firebaseOkHttp.dispatcher.executorService.shutdown()
        }
    }

    companion object {
        // Firebase 크리티컬 클라이언트 스펙 — GoPassSDK(유저 앱)의 KIOSK_CRITICAL 구성과 동일 값 유지
        private const val FIREBASE_MAX_REQUESTS = 64
        private const val FIREBASE_MAX_REQUESTS_PER_HOST = 50
        private const val FIREBASE_CRITICAL_MAX_IDLE_CONNECTIONS = 8
        private const val FIREBASE_KEEP_ALIVE_MINUTES = 5L

        @Volatile
        private var instance: SdkContainer? = null

        fun getOrCreate(context: Context): SdkContainer {
            val applicationContext = context.applicationContext
            return instance ?: synchronized(this) {
                instance ?: SdkContainer(applicationContext).also { instance = it }
            }
        }

        fun requireInstance(): SdkContainer {
            return instance ?: throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.CONTAINER_IS_NULL
            )
        }

        fun destroyInstance() {
            synchronized(this) {
                instance?.release()
                instance = null
            }
        }
    }
}
