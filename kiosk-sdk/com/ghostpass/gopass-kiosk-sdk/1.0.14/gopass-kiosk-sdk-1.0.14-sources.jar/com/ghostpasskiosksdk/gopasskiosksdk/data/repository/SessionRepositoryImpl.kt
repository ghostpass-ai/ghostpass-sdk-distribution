package com.ghostpasskiosksdk.gopasskiosksdk.data.repository

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.data.api.SessionApi
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.SessionRepository
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.utils.safeApiCall
import com.ghostpasskiosksdk.gopasskiosksdk.core.network.utils.safeApiCallUnit
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.AuthProgressRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session.InitiatedSessionRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.map
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.toDomain
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.InitiatedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionInfoPayload

internal class SessionRepositoryImpl(
    private val sessionApi: SessionApi
) : SessionRepository {
    override suspend fun requestSession(deviceId: String): ApiResult<InitiatedSessionPayload> {
        return safeApiCall {
            sessionApi.requestSession(
                request = InitiatedSessionRequest(deviceId)
            )
        }.map { it.toDomain() }
    }

    override suspend fun notifyAuthProgress(sessionIds: List<String>): ApiResult<Unit> {
        return safeApiCallUnit {
            sessionApi.notifyAuthProgress(AuthProgressRequest(sessionIds))
        }
    }

    override suspend fun fetchKioskInfo(sessionId: String): ApiResult<SessionInfoPayload> {
        return safeApiCall {
            sessionApi.fetchKioskInfo(sessionId)
        }.map { it.toDomain() }
    }
}
