package com.ghostpasskiosksdk.gopasskiosksdk.utils

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.SdkDiagnosticEvent
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

internal object DiagnosticEventBus {
    private val _events = MutableSharedFlow<SdkDiagnosticEvent>(
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val events: SharedFlow<SdkDiagnosticEvent> = _events.asSharedFlow()

    inline fun emit(block: () -> SdkDiagnosticEvent) {
        if (BuildConfig.DEBUG) {
            _events.tryEmit(block())
        }
    }
}
