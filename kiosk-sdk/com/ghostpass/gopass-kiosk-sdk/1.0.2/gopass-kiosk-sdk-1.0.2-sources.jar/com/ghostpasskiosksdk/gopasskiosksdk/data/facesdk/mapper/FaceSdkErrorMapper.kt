package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.mapper

import com.alcherainc.facesdk.error.Error
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode

internal fun Error.toInternalErrorCode(): InternalErrorCode {
    return when (this) {
        Error.NotInitialized -> InternalErrorCode.FACESDK_NOT_INITIALIZED
        Error.CanNotReadModel -> InternalErrorCode.FACESDK_CAN_NOT_READ_MODEL
        Error.InvalidLicense -> InternalErrorCode.FACESDK_INVALID_LICENSE
        Error.LicenseExpired -> InternalErrorCode.FACESDK_LICENSE_EXPIRED
        Error.UnknownLicenseError -> InternalErrorCode.FACESDK_UNKNOWN_LICENSE_ERROR
        Error.CanNotOpenExtensionFile -> InternalErrorCode.FACESDK_CAN_NOT_OPEN_EXTENSION_FILE
        Error.InvalidExtension -> InternalErrorCode.FACESDK_INVALID_EXTENSION
        Error.DisabledExtension -> InternalErrorCode.FACESDK_DISABLED_EXTENSION
        Error.NotPermittedInThisLicense -> InternalErrorCode.FACESDK_NOT_PERMITTED_IN_THIS_LICENSE
        Error.NothingAtInput -> InternalErrorCode.FACESDK_NOTHING_AT_INPUT
        Error.ModelIsNotInitialized -> InternalErrorCode.FACESDK_MODEL_IS_NOT_INITIALIZED
        Error.CanNotSetGPUIDAfterInitialization -> InternalErrorCode.FACESDK_CAN_NOT_SET_GPUID_AFTER_INITIALIZATION
        Error.CanNotSetGPUIDWithoutGPU -> InternalErrorCode.FACESDK_CAN_NOT_SET_GPUID_WITHOUT_GPU
        Error.CanNotReadLicense -> InternalErrorCode.FACESDK_CAN_NOT_READ_LICENSE
        Error.SystemTimeTampered -> InternalErrorCode.FACESDK_SYSTEM_TIME_TAMPERED
        Error.LicenseNotStarted -> InternalErrorCode.FACESDK_LICENSE_NOT_STARTED
        Error.SystemFunctionError -> InternalErrorCode.FACESDK_SYSTEM_FUNCTION_ERROR
        Error.NoError -> InternalErrorCode.FACESDK_NO_ERROR
    }
}
