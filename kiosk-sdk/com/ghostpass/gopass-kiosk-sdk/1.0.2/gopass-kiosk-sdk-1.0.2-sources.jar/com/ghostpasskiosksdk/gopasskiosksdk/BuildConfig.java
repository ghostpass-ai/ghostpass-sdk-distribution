/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.ghostpasskiosksdk.gopasskiosksdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.ghostpasskiosksdk.gopasskiosksdk";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "prod";
  // Field from product flavor: prod
  public static final String API_KEY = "e871b8eee98b2528b553d446802277228363b22a734b20e8b1ea04e37c6c2f74";
  // Field from product flavor: prod
  public static final String BASE_URL = "https://api.ghostpass.ai/";
  // Field from product flavor: prod
  public static final long CLOUD_PROJECT_NUMBER = 1022843687366L;
  // Field from product flavor: prod
  public static final String FB_API_KEY = "AIzaSyAk2OebswVEFTIs9OZ2Ai31dCz4gNkzOAA";
  // Field from product flavor: prod
  public static final String FB_APP_ID = "1:1009061735210:android:db59eff6a6986b9a144c53";
  // Field from product flavor: prod
  public static final String FB_DB_URL = "https://gpass-35626-default-rtdb.asia-southeast1.firebasedatabase.app";
  // Field from product flavor: prod
  public static final String FB_PROJECT_ID = "gpass-35626";
  // Field from product flavor: prod
  public static final String UUID = "8d3eaaf2-7a3e-4816-9921-3e1a6c4f911c";
}
