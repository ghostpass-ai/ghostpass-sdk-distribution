package com.ghostpasskiosksdk.gopasskiosksdk.domain.gateway

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.BeaconConfig

internal interface BeaconBroadcaster {
    suspend fun start(config: BeaconConfig): Boolean
    fun stop(): Boolean
    fun pause(): Boolean
    suspend fun resume(): Boolean
    fun currentBroadcastInfo(): String?
    fun isBroadcasting(): Boolean
}