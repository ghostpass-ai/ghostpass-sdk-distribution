package com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthChecks
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthPrecheckResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.FailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.LivenessResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceDetectionEngine
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceExtractEngine
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceLivenessEngine
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class PrepareFaceAuthUseCase (
    private val detectionEngine: FaceDetectionEngine,
    private val livenessEngine: FaceLivenessEngine,
    private val extractEngine: FaceExtractEngine,
    private val livenessEnabled: () -> Boolean
) {

    companion object {
        const val TAG = "PrepareFaceAuthUsecase TAG"
    }
    /**
     * 역할 : 얼굴 검출 + 조건 체크 + 벡터 추출
     */
    suspend fun execute(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotation: Int
    ): FaceAuthPrecheckResult = withContext(Dispatchers.Default) {

        try {
            // 1) 메모리 체크
            val memFail = detectionEngine.checkMemory(width, height)
            if (memFail != null) return@withContext memFail

            // 2) InputImage 생성
            val inputImage =
                detectionEngine.createInputImage(faceImage, width, height, rotation)

            // 3) 얼굴 검출
            val face = detectionEngine.detectFirstFace(inputImage)
                ?: return@withContext FaceAuthPrecheckResult.Failed(
                    checks = FaceAuthChecks(),
                    reasons = listOf(FailReason.NO_FACE)
                )

            // 4) pose/position/size 체크
            detectionEngine.validatePose(face)?.let { return@withContext it }
            detectionEngine.validatePosition(inputImage, face)?.let { return@withContext it }
            detectionEngine.validateSizeMin(inputImage, face)?.let { return@withContext it }
            detectionEngine.validateSizeMax(inputImage, face)?.let { return@withContext it }

            // 5) liveness
            if (livenessEnabled()) {
                when (livenessEngine.evaluate(inputImage, face)) {
                    LivenessResult.Collecting ->
                        return@withContext FaceAuthPrecheckResult.Failed(
                            checks = FaceAuthChecks.ALL_PASSED,
                            reasons = listOf(FailReason.ALREADY_IN_PROGRESS)
                        )

                    LivenessResult.NotConfirmed ->
                        return@withContext FaceAuthPrecheckResult.Failed(
                            checks = FaceAuthChecks.ALL_PASSED,
                            reasons = listOf(FailReason.LIVENESS_NOT_CONFIRMED)
                        )

                    LivenessResult.TxFailed ->
                        return@withContext FaceAuthPrecheckResult.Failed(
                            checks = FaceAuthChecks.ALL_PASSED,
                            reasons = listOf(FailReason.LIVENESS_TX_FAILED)
                        )

                    LivenessResult.Passed -> Unit
                }
            }


            // 6) landmark confidence
            detectionEngine.validateLandmarkConfidence(inputImage, face)
                ?.let { return@withContext it }

            val landmark = extractEngine.extractLandmarkVector(inputImage, face)

            return@withContext FaceAuthPrecheckResult.Success(
                checks = FaceAuthChecks.ALL_PASSED,
                landmark = landmark
            )
        } catch (e: OutOfMemoryError) {
            System.gc()
            return@withContext FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(),
                reasons = listOf(FailReason.OOM)
            )
        } catch (e: Exception) {
            errorLog(TAG, "얼굴 precheck e: $e")
            return@withContext FaceAuthPrecheckResult.Failed(
                checks = FaceAuthChecks(),
                reasons = listOf(FailReason.UNKNOWN)
            )
        }
    }

    /**
     * 얼굴 인증 준비 단계의 내부 상태를 초기화합니다.
     * Liveness 수집 프레임, 실패 카운터 등이 리셋됩니다.
     */
    fun reset() {
        if (livenessEnabled()) {
            livenessEngine.reset()
        }
    }
}
