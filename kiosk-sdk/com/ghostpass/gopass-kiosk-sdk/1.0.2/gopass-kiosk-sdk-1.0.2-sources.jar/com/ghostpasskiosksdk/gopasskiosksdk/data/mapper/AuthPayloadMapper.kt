package com.ghostpasskiosksdk.gopasskiosksdk.data.mapper

import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.auth.AuthPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.AuthPayload

internal fun AuthPayloadDto.toDomain(): AuthPayload =
    if (type == "AUTH_RESULT" && result == "SUCCESS") {
        AuthPayload.Success(deviceId = deviceId)
    } else {
        AuthPayload.Failed
    }