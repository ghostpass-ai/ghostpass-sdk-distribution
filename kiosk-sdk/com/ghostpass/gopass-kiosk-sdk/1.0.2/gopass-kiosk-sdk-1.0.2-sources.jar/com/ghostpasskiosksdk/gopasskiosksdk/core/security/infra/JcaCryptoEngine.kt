package com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra

import android.util.Base64
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.useAndWipe
import java.security.Key
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

internal class JcaCryptoEngine : CryptoEngine {

    companion object {
        private const val TAG = "CryptoEngine TAG"
        // 알고리즘 스펙 상수화
        private const val AES_GCM = "AES/GCM/NoPadding"
        private const val HMAC_ALGORITHM = "HmacSHA256"
        private const val KEY_AGREEMENT_ALGORITHM = "ECDH"
        private const val KEY_FACTORY_ALGORITHM = "EC"
        private const val DIGEST_ALGORITHM = "SHA-256"

        // 길이 관련 상수화
        private const val GCM_IV_LENGTH = 12
        private const val GCM_TAG_LENGTH = 128
        private const val HKDF_HASH_LENGTH = 32
    }

    // Shared Key 도출 (기존 에러 매핑 복원)
    override fun deriveSharedKey(key: PrivateKey, serverPublicKey: PublicKey): ByteArray {
        return try {
            val ka = KeyAgreement.getInstance(KEY_AGREEMENT_ALGORITHM)
            ka.init(key)
            ka.doPhase(serverPublicKey, true)
            ka.generateSecret()
        } catch (e: GoPassSdkException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "sharedKey error : $e")
            throw GoPassSdkException.from(
                error = ErrorCode.INIT_FAILED,
                cause = InternalErrorCode.SHARED_KEY_GENERATION_FAILED
            )
        }
    }

    override fun hkdf(ikm: ByteArray, salt: ByteArray, info: String): ByteArray {
        val mac = Mac.getInstance(HMAC_ALGORITHM)
        // 1. Extract (추출)
        mac.init(SecretKeySpec(if (salt.isEmpty()) ByteArray(HKDF_HASH_LENGTH) else salt, HMAC_ALGORITHM))

        return mac.doFinal(ikm).useAndWipe { safePrk ->
            // 2. Expand (확장)
            mac.init(SecretKeySpec(safePrk, HMAC_ALGORITHM))
            mac.update(info.toByteArray(Charsets.UTF_8))
            mac.doFinal(byteArrayOf(1))
        }
    }

    // 복호화 : kioskSecret, dk_user
    override fun decryptData(key: Key, encryptedBase64: String, aad: ByteArray): ByteArray {
        val fullData = Base64.decode(encryptedBase64, Base64.NO_WRAP)

        val iv = fullData.sliceArray(0 until GCM_IV_LENGTH)
        val cipherText = fullData.sliceArray(GCM_IV_LENGTH until fullData.size)

        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_LENGTH, iv))
        aad.takeIf { it.isNotEmpty() }?.let { cipher.updateAAD(it) }
        return cipher.doFinal(cipherText)
    }

    override fun encrypt(plainText: String, key: Key, aad: ByteArray): String {
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        aad.takeIf { it.isNotEmpty() }?.let { cipher.updateAAD(it) }

        val cipherTextWithTag = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

        val combinedPayload = ByteArray(iv.size + cipherTextWithTag.size)
        System.arraycopy(iv, 0, combinedPayload, 0, iv.size)
        System.arraycopy(cipherTextWithTag, 0, combinedPayload, iv.size, cipherTextWithTag.size)

        return Base64.encodeToString(combinedPayload, Base64.NO_WRAP)
    }

    override fun generateHmacSignature(key: SecretKey, stringToSign: String): String {
        val mac = Mac.getInstance(HMAC_ALGORITHM)
        mac.init(key)

        val signatureBytes = mac.doFinal(stringToSign.toByteArray(Charsets.UTF_8))

        return signatureBytes.joinToString("") { "%02x".format(it) }
    }

    override fun decodeECPublicKey(base64: String): PublicKey {
        val keyBytes = Base64.decode(base64, Base64.DEFAULT)
        val keySpec = X509EncodedKeySpec(keyBytes)
        return KeyFactory.getInstance(KEY_FACTORY_ALGORITHM).generatePublic(keySpec)
    }

    override fun hashSha256(input: String): String {
        val digest = MessageDigest.getInstance(DIGEST_ALGORITHM)
        return digest.digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}