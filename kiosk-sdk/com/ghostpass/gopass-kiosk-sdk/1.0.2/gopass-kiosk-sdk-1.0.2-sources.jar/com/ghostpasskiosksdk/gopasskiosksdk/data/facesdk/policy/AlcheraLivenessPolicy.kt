package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.policy

internal object AlcheraLivenessPolicy {
    private const val LIVENESS_QUALITY = 63.96f
    private const val VALID_FACE_DETECT_LIVENESS_VALUE = 0.3f

    fun shouldCollectFrame(quality: Float): Boolean = quality >= LIVENESS_QUALITY

    fun isPassed(confidence: Float): Boolean = confidence > VALID_FACE_DETECT_LIVENESS_VALUE
}
