package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SseEvent
import kotlinx.coroutines.flow.Flow

internal interface RemotePathRepository {
    fun observePaths(): Flow<SseEvent>
}
