package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode

// 서버 401 인증 에러
internal enum class SecurityFilterErrorCode(
    val code: String,
    val external: ErrorCode = ErrorCode.SERVER_ERROR
) {
    MISSING_API_KEY("R-100"),
    SDK_SERVICE_INACTIVE("R-101"),
    MISSING_IDENTIFIER("R-102"),
    MISSING_HMAC_HEADERS("R-103"),
    TIMESTAMP_EXPIRED("R-104"),
    NONCE_REUSED("R-105"),
    HMAC_INVALID("R-106"),
    SDK_SERVICE_NOT_FOUND("R-107"),
    UNKNOWN("R-999");

    companion object {
        fun fromCode(code: String): SecurityFilterErrorCode =
            entries.find { it.code == code } ?: UNKNOWN
    }
}