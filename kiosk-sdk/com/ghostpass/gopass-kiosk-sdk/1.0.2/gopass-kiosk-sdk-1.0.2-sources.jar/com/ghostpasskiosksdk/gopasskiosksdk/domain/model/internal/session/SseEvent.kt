package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session

internal sealed class SseEvent {
    data object Connected : SseEvent()
    data object Heartbeat : SseEvent()
    data class SessionCreated(val payload: SseSessionPayload) : SseEvent()
}
