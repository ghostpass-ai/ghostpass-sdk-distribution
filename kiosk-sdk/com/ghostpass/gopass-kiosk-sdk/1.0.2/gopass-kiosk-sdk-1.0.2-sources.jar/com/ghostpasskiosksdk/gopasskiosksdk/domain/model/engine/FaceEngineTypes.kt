package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine

internal interface FaceEngineTypes {
    // 외부 SDK의 이미지 객체(예: InputImage)를 대체할 도메인 마커 인터페이스
    interface FaceImageFrame

    // 외부 SDK의 얼굴 객체(예: Face)를 대체할 도메인 마커 인터페이스
    interface DetectedFace
}