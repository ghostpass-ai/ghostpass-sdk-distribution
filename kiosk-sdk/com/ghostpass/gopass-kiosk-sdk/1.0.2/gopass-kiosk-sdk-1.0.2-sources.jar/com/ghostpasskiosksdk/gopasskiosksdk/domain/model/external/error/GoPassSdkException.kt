package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.SecurityFilterErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode

class GoPassSdkException(
    val code: String,
    override val message: String,
    val causeCode: String? = null,
) : Exception(message) {
    override fun fillInStackTrace(): Throwable = this

    override fun toString(): String {
        val internalInfo = causeCode?.let { " (Internal: $it)" } ?: ""
        return "[$code] $message$internalInfo"
    }

    companion object {
        fun from(
            error: ErrorCode,
            customMessage: String? = null
        ): GoPassSdkException {
            val msg = customMessage ?: error.message ?: "GoPass SDK error: ${error.externalCode}"
            return GoPassSdkException(
                code = error.externalCode,
                message = msg,
                causeCode = null
            )
        }

        internal fun from(
            error: ErrorCode,
            customMessage: String? = null,
            cause: InternalErrorCode?)
        : GoPassSdkException {
            val msg = customMessage ?: error.message ?: "GoPass SDK error: ${error.externalCode}"
            return GoPassSdkException(
                code = error.externalCode,
                message = msg,
                causeCode = cause?.code
            )
        }

        internal fun from(error: ErrorCode,
                 customMessage: String? = null,
                 cause: SecurityFilterErrorCode?): GoPassSdkException {
            val msg = customMessage ?: error.message ?: "GoPass SDK error: ${error.externalCode}"
            return GoPassSdkException(
                code = error.externalCode,
                message = msg,
                causeCode = cause?.code
            )
        }
    }
}