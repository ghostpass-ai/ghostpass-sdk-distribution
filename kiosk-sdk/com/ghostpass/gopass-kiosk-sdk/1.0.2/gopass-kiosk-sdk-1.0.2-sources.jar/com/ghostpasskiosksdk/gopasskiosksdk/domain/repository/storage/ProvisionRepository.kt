package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.BeaconConfig

internal interface ProvisionRepository {
    suspend fun provisionIfNeeded(
        apiKey: String,
        kioskId: String,
        beaconConfig: BeaconConfig
    )
}
