package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.session

import kotlinx.serialization.Serializable

@Serializable
internal data class SessionResultRequest(
    val success: Boolean
)