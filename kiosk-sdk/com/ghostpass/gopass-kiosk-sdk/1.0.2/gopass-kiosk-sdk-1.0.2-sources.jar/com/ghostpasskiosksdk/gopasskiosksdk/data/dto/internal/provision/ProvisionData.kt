package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision

import kotlinx.serialization.Serializable

@Serializable
internal data class ProvisionData(
    val serverPublicKey: String,
    val encryptedKioskSecret: String,
    val kioskId: String
)