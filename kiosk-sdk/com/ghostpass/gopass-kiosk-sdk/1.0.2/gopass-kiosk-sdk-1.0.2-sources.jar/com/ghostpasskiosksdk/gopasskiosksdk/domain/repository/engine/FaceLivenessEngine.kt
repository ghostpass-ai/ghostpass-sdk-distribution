package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.LivenessResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine.FaceEngineTypes

internal interface FaceLivenessEngine {
    fun evaluate(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): LivenessResult

    /** 수집된 프레임 및 내부 상태를 초기화합니다. */
    fun reset()
}