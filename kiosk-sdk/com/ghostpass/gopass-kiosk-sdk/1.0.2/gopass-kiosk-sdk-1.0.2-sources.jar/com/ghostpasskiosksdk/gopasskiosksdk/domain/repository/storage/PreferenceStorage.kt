package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.BeaconConfig

internal interface PreferenceStorage {
    fun saveApiKey(apiKey: String)
    fun getApiKey(): String?
    fun saveKioskId(kioskId: String)
    fun getKioskId(): String?
    fun saveBeaconConfig(beaconConfig: BeaconConfig)
    fun getBeaconConfig(): BeaconConfig?
    fun clearAll()
}