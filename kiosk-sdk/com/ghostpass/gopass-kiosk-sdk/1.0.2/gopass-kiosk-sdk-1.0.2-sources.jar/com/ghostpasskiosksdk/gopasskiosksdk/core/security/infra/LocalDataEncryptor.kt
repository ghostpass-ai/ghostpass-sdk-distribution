package com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra

import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager
import com.ghostpasskiosksdk.gopasskiosksdk.utils.useAndWipe

internal class LocalDataEncryptor(
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager
) {
    fun encrypt(plainText: String): String {
        val masterKey = keyManager.getSecretKey(KeyManager.MASTER_KEY_ALIAS)
        val emptyAad = ByteArray(0)
        return cryptoEngine.encrypt(plainText, masterKey, emptyAad)
    }

    fun decrypt(encryptedBase64: String): String {
        val masterKey = keyManager.getSecretKey(KeyManager.MASTER_KEY_ALIAS)
        val emptyAad = ByteArray(0)
        return cryptoEngine.decryptData(masterKey, encryptedBase64, emptyAad)
            .useAndWipe { safeBytes ->
                String(safeBytes, Charsets.UTF_8)
            }
    }
}