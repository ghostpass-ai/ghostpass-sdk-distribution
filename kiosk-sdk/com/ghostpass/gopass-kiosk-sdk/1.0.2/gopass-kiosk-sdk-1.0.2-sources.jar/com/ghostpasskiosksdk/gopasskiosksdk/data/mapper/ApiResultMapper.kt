package com.ghostpasskiosksdk.gopasskiosksdk.data.mapper

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.SecurityFilterErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.ServerErrorCode

internal fun ApiResult.Failure.toSdkException(): GoPassSdkException {
    if (code == "PARSE_ERROR" || code == "EMPTY_BODY") {
        return GoPassSdkException.from(
            error = ErrorCode.INTERNAL_ERROR,
            cause = InternalErrorCode.INVALID_FORM
        )
    }

    if (httpCode == 401) {

        if(code == ErrorCode.INVALID_API_KEY.name){
            return GoPassSdkException.from(
                error = ErrorCode.INVALID_API_KEY,
                customMessage = this.message
            )
        }

        val authError = SecurityFilterErrorCode.fromCode(code ?: "")
        return GoPassSdkException.from(
            error = authError.external,
            cause = authError,
            customMessage = this.message
        )
    }

    val serverError = ServerErrorCode.fromCode(code ?: "")

    return if (serverError != null) {
        GoPassSdkException.from(
            error = serverError.external,
            cause = serverError.internal,
            customMessage = this.message
        )
    } else {
        // 정의되지 않은 코드 처리
        GoPassSdkException.from(
            error = ErrorCode.SERVER_ERROR,
            customMessage = this.message
        )
    }
}

internal fun <T, R> ApiResult<T>.map(transform: (T) -> R): ApiResult<R> = when (this) {
    is ApiResult.Success -> ApiResult.Success(transform(data), message)
    is ApiResult.Failure -> this
    is ApiResult.NetworkError -> this
}

internal fun <T> ApiResult<T>.getOrThrow(
): T = when (this) {
    is ApiResult.Success -> data

    is ApiResult.Failure -> throw this.toSdkException()

    is ApiResult.NetworkError -> {
        throw GoPassSdkException.from(
            error = ErrorCode.NETWORK_ERROR
        )
    }
}