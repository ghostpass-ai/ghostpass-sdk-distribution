package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.UserToKioskPayload
import kotlinx.serialization.Serializable
import kotlin.Long

@Serializable
internal data class UserToKioskPayloadDto(
    val payload: String,
    val seq: Int,
    val ts: Long = 0L
) {
    fun toDomain(): UserToKioskPayload = UserToKioskPayload(
        payload = this.payload,
        seq = this.seq,
        ts = this.ts
    )
}
