package com.ghostpasskiosksdk.gopasskiosksdk.core.device.infra

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

internal class ScreenStateMonitor(
    context: Context
) {
    companion object {
        private const val TAG = "ScreenStateMonitor TAG"
        private const val MIN_WAKE_CALLBACK_INTERVAL_MILLIS = 3_000L
    }

    private val appContext = context.applicationContext
    private val isMonitoring = AtomicBoolean(false)
    private val lastWakeCallbackAt = AtomicLong(0L)
    private var receiver: BroadcastReceiver? = null

    fun startMonitoring(onWake: (String) -> Unit) {
        if (!isMonitoring.compareAndSet(false, true)) return

        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_ON,
                    Intent.ACTION_USER_PRESENT -> {
                        val now = System.currentTimeMillis()
                        val previous = lastWakeCallbackAt.get()
                        if (now - previous < MIN_WAKE_CALLBACK_INTERVAL_MILLIS) {
                            warnLog(TAG, "화면 복귀 이벤트 중복 감지: ${intent.action}")
                            return
                        }
                        lastWakeCallbackAt.set(now)
                        warnLog(TAG, "화면 복귀 감지: ${intent.action}")
                        onWake(intent.action.orEmpty())
                    }
                }
            }
        }

        val intentFilter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }

        val localReceiver = receiver ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            appContext.registerReceiver(localReceiver, intentFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            appContext.registerReceiver(localReceiver, intentFilter)
        }
    }

    fun stopMonitoring() {
        if (!isMonitoring.compareAndSet(true, false)) return

        receiver?.let { localReceiver ->
            runCatching {
                appContext.unregisterReceiver(localReceiver)
            }.onFailure {
                warnLog(TAG, "화면 상태 리시버 해제 실패 또는 미등록 상태")
            }
        }
        lastWakeCallbackAt.set(0L)
        receiver = null
    }
}
