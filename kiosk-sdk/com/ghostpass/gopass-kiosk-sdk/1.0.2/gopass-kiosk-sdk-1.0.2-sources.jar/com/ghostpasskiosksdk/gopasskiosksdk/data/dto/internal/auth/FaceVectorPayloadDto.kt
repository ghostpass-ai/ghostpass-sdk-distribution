package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.auth

import kotlinx.serialization.Serializable

@Serializable
internal data class FaceVectorPayloadDto(
    val type: String = "FACE_VECTOR",
    val vector: FloatArray,
    val timestamp: Long
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as FaceVectorPayloadDto

        return vector.contentEquals(other.vector)
    }

    override fun hashCode(): Int {
        return vector.contentHashCode()
    }
}