package com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session

internal data class EncryptedSessionPayload(
    val encryptedData: String,
    val seq: Int
)