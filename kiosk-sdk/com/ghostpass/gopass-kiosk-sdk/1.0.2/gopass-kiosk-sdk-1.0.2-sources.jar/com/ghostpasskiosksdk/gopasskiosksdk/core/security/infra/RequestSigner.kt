package com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra

import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.KeyManager

internal class RequestSigner(
    private val cryptoEngine: CryptoEngine,
    private val keyManager: KeyManager
) {

    fun isAvailable(): Boolean = keyManager.hasSecretKey(KeyManager.HMAC_ALIAS)

    fun sign(stringToSign: String): String {
        val hmacKey = keyManager.getSecretKey(KeyManager.HMAC_ALIAS)
        return cryptoEngine.generateHmacSignature(hmacKey, stringToSign)
    }

    fun hashBody(body: String): String = cryptoEngine.hashSha256(body)
}