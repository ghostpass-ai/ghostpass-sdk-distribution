package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.core.network.model.ApiResult
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.challenge.ChallengeData
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.provision.ProvisionData

internal interface AuthRepository {
    suspend fun challenge(): ApiResult<ChallengeData>
    suspend fun provision(request: ProvisionRequest): ApiResult<ProvisionData>
}