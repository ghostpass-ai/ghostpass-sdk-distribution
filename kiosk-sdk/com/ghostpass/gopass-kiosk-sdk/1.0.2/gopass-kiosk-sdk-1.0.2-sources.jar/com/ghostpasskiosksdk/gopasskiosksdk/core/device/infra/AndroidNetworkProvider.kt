package com.ghostpasskiosksdk.gopasskiosksdk.core.device.infra

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.NetworkStateProvider
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

internal class AndroidNetworkProvider(
    private val context: Context
) : NetworkStateProvider {

    companion object {
        private const val TAG = "AndroidNetworkProvider TAG"
    }

    private val _isAvailable = MutableStateFlow(checkNetworkState())
    override val isAvailable: StateFlow<Boolean> = _isAvailable.asStateFlow()

    private val isMonitoring = AtomicBoolean(false)

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            updateNetworkState()
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            updateNetworkState(networkCapabilities)
        }

        override fun onLost(network: Network) {
            val isStillConnected = checkNetworkState()
            if (isStillConnected) {
                warnLog(TAG, "네트워크 전환 감지 (기존 네트워크 끊김, 대체 네트워크 사용 중)")
            } else if (_isAvailable.value) {
                // 완전히 모든 검증된 네트워크가 끊긴 상황
                _isAvailable.value = false
                warnLog(TAG, "검증된 네트워크 끊김")
            }
        }
    }

    override fun startMonitoring() {
        if (!isMonitoring.compareAndSet(false, true)) return

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        cm.registerNetworkCallback(request, networkCallback)
    }

    override fun stopMonitoring() {
        if (!isMonitoring.compareAndSet(true, false)) return

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        cm?.let {
            try {
                it.unregisterNetworkCallback(networkCallback)
            } catch (e: IllegalArgumentException) {
                warnLog(TAG, "등록된 네트워크 콜백이 존재하지 않습니다")
            }
        }
    }

    /**
     * 모니터링 시작 시점의 초기 네트워크 상태를 동기적으로 확인합니다.
     */
    private fun checkNetworkState(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return isValidatedNetwork(caps)
    }

    private fun updateNetworkState(capabilities: NetworkCapabilities? = null) {
        val isAvailable = capabilities?.let(::isValidatedNetwork) ?: checkNetworkState()
        if (_isAvailable.value != isAvailable) {
            _isAvailable.value = isAvailable
            warnLog(TAG, if (isAvailable) "검증된 네트워크 복구됨" else "검증된 네트워크를 찾을 수 없음")
        }
    }

    private fun isValidatedNetwork(capabilities: NetworkCapabilities): Boolean {
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}
