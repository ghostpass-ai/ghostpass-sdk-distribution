package com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class KioskToUserPayloadDto(
    val payload: String,
    val seq: Int,
    val ts: FirebaseServerValueDto = FirebaseServerValueDto()
)
@Serializable
internal data class FirebaseServerValueDto(
    @SerialName(".sv") val sv: String = "timestamp"
)