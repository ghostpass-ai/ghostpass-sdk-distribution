package com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage

import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken

internal interface RemoteStateChannelRepository {
    suspend fun observeSessionId(
        sessionIds: Set<SessionData>,
        tokenMap: Map<String, AuthToken>,
        timeoutMs: Long = 5000L
    ): SessionIdEvent
    suspend fun updateKioskSecureData(
        sessionPayloads: Map<SessionData, EncryptedSessionPayload>
    ): Map<SessionData, Result<AuthToken>>
}