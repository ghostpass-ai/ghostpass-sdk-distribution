package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.BluetoothStateProvider
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.NetworkStateProvider
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.infra.ScreenStateMonitor
import com.ghostpasskiosksdk.gopasskiosksdk.domain.gateway.BeaconBroadcaster
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

internal class SystemStateCoordinator(
    private val bluetoothStateProvider: BluetoothStateProvider,
    private val networkStateProvider: NetworkStateProvider,
    private val screenStateMonitor: ScreenStateMonitor,
    private val beaconBroadcaster: BeaconBroadcaster,
    private val authOrchestrator: AuthOrchestrator
) {
    companion object {
        private const val TAG = "SystemStateCoordinator ${BuildConfig.SIGNATURE}"
    }

    private val isStarted = AtomicBoolean(false)

    fun start(scope: CoroutineScope) {
        if (!isStarted.compareAndSet(false, true)) return

        try {
            bluetoothStateProvider.startMonitoring()
            networkStateProvider.startMonitoring()

            screenStateMonitor.startMonitoring { action ->
                if (networkStateProvider.isAvailable.value) {
                    authOrchestrator.forceReconnect("screen wake: $action")
                }
            }

            scope.launch {
                combine(
                    bluetoothStateProvider.isEnabled,
                    networkStateProvider.isAvailable
                ) { bt, network -> Pair(bt, network) }
                    .distinctUntilChanged()
                    .collect { (btEnabled, networkAvailable) ->
                        warnLog(TAG, "시스템 상태 변경: BT=$btEnabled, Network=$networkAvailable")

                        if (btEnabled && networkAvailable) {
                            beaconBroadcaster.resume()
                        } else {
                            beaconBroadcaster.pause()
                        }

                        if (networkAvailable) {
                            authOrchestrator.startSessionCollection()
                        } else {
                            warnLog(TAG, "Network=false 감지로 SSE 수집/재연결 작업 중단")
                            authOrchestrator.stopSessionCollection()
                        }
                    }
            }
        } catch (e: Throwable) {
            errorLog(TAG, "시스템 상태 모니터링 시작 실패: ${e.message}")
            runCatching { screenStateMonitor.stopMonitoring() }
            runCatching { networkStateProvider.stopMonitoring() }
            runCatching { bluetoothStateProvider.stopMonitoring() }
            isStarted.set(false)
            throw e
        }
    }

    fun stop() {
        if (!isStarted.compareAndSet(true, false)) return

        var firstException: Throwable? = null

        runCatching { screenStateMonitor.stopMonitoring() }
            .onFailure { e ->
                errorLog(TAG, "screenStateMonitor stop 실패: ${e.message}")
                firstException = e
            }

        runCatching { bluetoothStateProvider.stopMonitoring() }
            .onFailure { e ->
                errorLog(TAG, "bluetoothStateProvider stop 실패: ${e.message}")
                if (firstException == null) firstException = e
            }

        runCatching { networkStateProvider.stopMonitoring() }
            .onFailure { e ->
                errorLog(TAG, "networkStateProvider stop 실패: ${e.message}")
                if (firstException == null) firstException = e
            }

        try {
            authOrchestrator.destroy()
        } catch (e: Throwable) {
            errorLog(TAG, "authOrchestrator destroy 실패: ${e.message}")
            if (firstException == null) firstException = e
        }

        if (firstException != null) {
            throw firstException
        }
    }
}
