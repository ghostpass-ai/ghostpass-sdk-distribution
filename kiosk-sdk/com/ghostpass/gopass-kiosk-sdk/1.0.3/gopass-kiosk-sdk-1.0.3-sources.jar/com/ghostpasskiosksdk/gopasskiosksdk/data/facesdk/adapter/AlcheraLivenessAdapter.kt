package com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.adapter

import com.alcherainc.facesdk.type.InputImage
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.manager.AlcheraSdkManager
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.policy.AlcheraLivenessPolicy
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.LivenessResult
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper.AlcheraDetectedFace
import com.ghostpasskiosksdk.gopasskiosksdk.data.facesdk.wrapper.AlcheraImageFrame
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.engine.FaceEngineTypes
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.engine.FaceLivenessEngine
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog

internal class AlcheraLivenessAdapter (
    private val sdkManager: AlcheraSdkManager
) : FaceLivenessEngine {

    @Volatile private var livenessTxFailCount = 0

    private val livenessArray = ArrayList<InputImage>(4)

    private companion object {
        const val TAG = "Liveness Adapter ${BuildConfig.SIGNATURE}"
        const val LIVENESS_TX_FAIL_LIMIT = 3
    }

    override fun evaluate(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): LivenessResult {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        val faceQuality = sdkManager.featureExtension.EstimateFaceQuality(nativeImage, nativeFace, false)
        debugLog(TAG, "livenessArray : ${livenessArray.size} faceQuality : ${faceQuality.quality}")

        if (AlcheraLivenessPolicy.shouldCollectFrame(faceQuality.quality)) {
            debugLog(TAG,"퀄리티 초과로 add")
            // 추출한 원본 객체를 배열에 저장
            livenessArray.add(nativeImage)
        }

        // 아직 4장 안 모임
        if (livenessArray.size != 4) return LivenessResult.Collecting

        val resultLive = sdkManager.antispoofingExtension.CheckLivenessFromBGRImage(
            livenessArray[0], livenessArray[1], livenessArray[2], livenessArray[3], nativeFace
        )

        // 이번 4장 평가 끝 -> 다음 평가 준비
        livenessArray.clear()
        sdkManager.antispoofingExtension.ResetInputBGRLivenessChecker()

        val passed = AlcheraLivenessPolicy.isPassed(resultLive.confidence)
        debugLog(TAG, "PAD 결과 : $passed, confidence = ${resultLive.confidence}")

        return if (passed) {
            livenessTxFailCount = 0
            LivenessResult.Passed
        } else {
            livenessTxFailCount += 1

            if (livenessTxFailCount >= LIVENESS_TX_FAIL_LIMIT) {
                livenessTxFailCount = 0
                LivenessResult.TxFailed
            } else {
                LivenessResult.NotConfirmed // confidence 미달로 재시도
            }
        }
    }

    override fun reset() {
        livenessTxFailCount = 0
        livenessArray.clear()
        sdkManager.antispoofingExtension.ResetInputBGRLivenessChecker()
    }
}
