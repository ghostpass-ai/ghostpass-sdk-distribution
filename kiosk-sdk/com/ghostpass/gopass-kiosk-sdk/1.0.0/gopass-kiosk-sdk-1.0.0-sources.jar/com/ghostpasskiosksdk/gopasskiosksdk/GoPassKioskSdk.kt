package com.ghostpasskiosksdk.gopasskiosksdk

import android.content.Context
import androidx.annotation.Keep
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.BeaconConfig
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.KioskId
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.GoPassAuthResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.internal.di.SdkContainer
import kotlin.jvm.Throws

@Keep
object GoPassKioskSdk {

    @Throws(GoPassSdkException::class)
    suspend fun initialize(
        context: Context,
        apiKey: String,
        kioskId: KioskId,
        beaconConfig: BeaconConfig
    ): Boolean {
        val container = SdkContainer.getOrCreate(context)
        return try {
            container.infraManager.initialize(apiKey, kioskId, beaconConfig)
        } catch (t: Throwable) {
            SdkContainer.destroyInstance()
            throw t
        }
    }

    @Throws(GoPassSdkException::class)
    suspend fun detection(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotationDegrees: Int
    ): GoPassAuthResult {
        return SdkContainer.requireInstance().authOrchestrator.execute(
            faceImage = faceImage,
            width = width,
            height = height,
            rotation = rotationDegrees
        )
    }

    @Throws(GoPassSdkException::class)
    suspend fun preparePhoneAuth(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotationDegrees: Int
    ): GoPassAuthResult {
        return SdkContainer.requireInstance().authOrchestrator
            .prepareLandmarkForPhoneAuth(
                faceImage = faceImage,
                width = width,
                height = height,
                rotation = rotationDegrees
            )
    }

    @Throws(GoPassSdkException::class)
    suspend fun submitPhoneAuth(deviceId: String): GoPassAuthResult {
        return SdkContainer.requireInstance().authOrchestrator
            .executePhoneAuth(deviceId = deviceId)
    }

    @Throws(GoPassSdkException::class)
    suspend fun reset(): Boolean {
        try {
            return SdkContainer.requireInstance().infraManager.reset()
        } finally {
            SdkContainer.destroyInstance()
        }
    }
}
