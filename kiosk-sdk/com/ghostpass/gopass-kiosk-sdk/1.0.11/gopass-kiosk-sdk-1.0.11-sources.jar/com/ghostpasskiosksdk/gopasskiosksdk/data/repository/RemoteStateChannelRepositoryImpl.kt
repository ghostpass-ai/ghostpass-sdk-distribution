package com.ghostpasskiosksdk.gopasskiosksdk.data.repository

import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.data.api.FirebaseApi
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.auth.AuthPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.CustomTokenSignInRequest
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.KioskToUserPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.firebase.UserToKioskPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.toDomain
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.SdkDiagnosticEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.AuthPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.firebase.AuthToken
import com.ghostpasskiosksdk.gopasskiosksdk.domain.repository.storage.RemoteStateChannelRepository
import com.ghostpasskiosksdk.gopasskiosksdk.utils.DiagnosticEventBus
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.useAndWipe
import com.ghostpasskiosksdk.gopasskiosksdk.utils.verboseLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.transform
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json.Default.decodeFromString
import java.security.Key

internal class RemoteStateChannelRepositoryImpl(
    private val firebaseApi: FirebaseApi,
    private val cryptoEngine: CryptoEngine

) : RemoteStateChannelRepository {

    companion object {
        val TAG = "RemoteStateChannelRepo ${BuildConfig.SIGNATURE}"
        const val KIOSK_TO_USER = "kiosk_to_user"
        const val USER_TO_KIOSK = "user_to_kiosk"
        private const val USER_TO_KIOSK_POLL_INTERVAL_MS = 300L
    }

    private class ServerException(
        val httpCode: Int,
        override val cause: GoPassSdkException
    ) : Exception("RTDB server error: HTTP $httpCode", cause)

    private sealed class DecodeResult {
        data class Success(val sessionId: String, val deviceId: String) : DecodeResult()
        data class Error(val sessionId: String, val reason: FaceAuthFailReason) : DecodeResult()
    }

    override suspend fun observeSessionId(
        sessionIds: Set<SessionData>,
        tokenMap: Map<String, AuthToken>,
        expectedSeqMap: Map<String, Int>,
        timeoutMs: Long
    ): SessionIdEvent {
        debugLog(TAG, "[OBSERVE] 세션 관찰 시작: ${sessionIds.size}개, expectedSeqMap=$expectedSeqMap")
        if (sessionIds.isEmpty()) return SessionIdEvent.Failed(FaceAuthFailReason.EMPTY_SESSION_IDS)

        val flowList = sessionIds.map { session ->
            flow {
                val idToken = tokenMap[session.sessionId]?.idToken
                    ?: throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = InternalErrorCode.FB_AUTH_NULL
                    )
                val expectedSeq = expectedSeqMap[session.sessionId]
                    ?: throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = InternalErrorCode.OBSERVE_SEQ_MAP_MISSING
                    )
                pollSingleSessionResult(session, idToken, expectedSeq).collect { emit(it) }
            }.catch { e ->
                errorLog(TAG, "세션 [${session.sessionId}] 옵저빙 실패: ${e.message}")
                emit(DecodeResult.Error(session.sessionId, FaceAuthFailReason.UNKNOWN))
            }
        }

        val result = withTimeoutOrNull(timeoutMs) {
            val failedSessionIds = mutableSetOf<String>()
            val totalSessions = sessionIds.size

            flowList.merge().transform { res ->
                when (res) {
                    is DecodeResult.Success -> {
                        emit(res) // 🚨 1명이라도 성공하면 즉시 방출 후 종료 (나머지 세션 소켓 자동 파기)
                    }
                    is DecodeResult.Error -> {
                        val isNew = failedSessionIds.add(res.sessionId)
                        if (!isNew) {
                            debugLog(TAG, "[OBSERVE] 중복 FAIL 무시 [${res.sessionId}], 현재 실패 세션: ${failedSessionIds.size}/$totalSessions")
                        }
                        if (isNew && failedSessionIds.size >= totalSessions) {
                            debugLog(TAG, "[OBSERVE] 전원 실패 확정: failedSessionIds=$failedSessionIds")
                            emit(res) // 🚨 전원 실패 시, 타임아웃까지 기다리지 않고 즉시 에러 방출 후 종료
                        }
                    }
                }
            }.firstOrNull()
        }

        return when (result) {
            is DecodeResult.Success -> SessionIdEvent.Success(result.sessionId, result.deviceId)
            is DecodeResult.Error -> SessionIdEvent.Failed(FaceAuthFailReason.ALL_FAILED)
            null -> SessionIdEvent.Failed(FaceAuthFailReason.TIMEOUT)
        }
    }

    private suspend fun authenticate(customToken: String): AuthToken {
        val request = CustomTokenSignInRequest(token = customToken, returnSecureToken = true)
        val response = firebaseApi.signInWithCustomToken(BuildConfig.FB_API_KEY, request)
        if (response.isSuccessful) {
            val body = response.body() ?: throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.FB_AUTH_NULL
            )
            return AuthToken(idToken = body.idToken)
        } else {
            throw GoPassSdkException.from(
                error = ErrorCode.INTERNAL_ERROR,
                cause = InternalErrorCode.FIREBASE_AUTH_SIGNIN_FAILED
            )
        }
    }

    private fun pollSingleSessionResult(
          session: SessionData,
          idToken: String,
          expectedSeq: Int
      ): Flow<DecodeResult> = flow {
          val pollUrl = "${BuildConfig.FB_DB_URL}${session.rtdbPath.trimEnd('/')}/$USER_TO_KIOSK.json"
          var lastLoggedSeq: Int? = null

          debugLog(TAG, "[POLL] user_to_kiosk polling 시작 [${session.sessionId}], expectedSeq=$expectedSeq")

          while (true) {
              val payloadMap = try {
                  fetchUserToKioskPayload(url = pollUrl, idToken = idToken)
              } catch (e: ServerException) {
                  // 5xx: 서버 장애 — diagnostic emit 후 즉시 세션 FAIL 처리
                  errorLog(TAG, "[POLL] 서버 에러(${e.httpCode}), polling 중단 [${session.sessionId}]")
                  DiagnosticEventBus.emit {
                      SdkDiagnosticEvent.ObserveError(
                          sessionId = session.sessionId,
                          reason = "poll_server_error",
                          errorDetail = e.toString()
                      )
                  }
                  emit(DecodeResult.Error(session.sessionId, FaceAuthFailReason.UNKNOWN))
                  return@flow
              } catch (e: Exception) {
                  // 4xx, 네트워크 타임아웃 등: transient로 간주, 재시도
                  warnLog(TAG, "[POLL] GET 실패, 재시도 [${session.sessionId}]: ${e.message}")
                  DiagnosticEventBus.emit {
                      SdkDiagnosticEvent.ObserveError(
                          sessionId = session.sessionId,
                          reason = "poll_get_failed",
                          errorDetail = e.toString()
                      )
                  }
                  delay(USER_TO_KIOSK_POLL_INTERVAL_MS)
                  continue
              }

              if (payloadMap == null) {
                  delay(USER_TO_KIOSK_POLL_INTERVAL_MS)
                  continue
              }

              if (payloadMap.seq != expectedSeq) {
                  if (lastLoggedSeq != payloadMap.seq) {
                      warnLog(
                          TAG,
                          "[POLL] stale AUTH_RESULT 무시 [${session.sessionId}]: expectedSeq=$expectedSeq, actualSeq=${payloadMap.seq}"
                      )
                      lastLoggedSeq = payloadMap.seq
                  }
                  delay(USER_TO_KIOSK_POLL_INTERVAL_MS)
                  continue
              }

              debugLog(TAG, "[POLL] expected AUTH_RESULT 수신 [${session.sessionId}]: seq=${payloadMap.seq}")
              emit(decodeAuthEvent(payloadMap.payload, session.sessionId, payloadMap.seq, session.dkKiosk))
              return@flow
          }
      }

    private suspend fun fetchUserToKioskPayload(
        url: String,
        idToken: String
    ): UserToKioskPayloadDto? {
        val response = try {
            firebaseApi.getSessionData(url, idToken)
        } catch (e: SerializationException) {
            // Firebase RTDB는 노드 미존재 시 HTTP 200 + body "null" (문자열 리터럴) 반환
            // kotlinx.serialization이 "null"을 DTO로 파싱 시도 시 실패 → 노드 없음으로 처리
            return null
        }

        if (!response.isSuccessful) {
            val httpCode = response.code()
            val exception = GoPassSdkException.from(
                error = ErrorCode.NETWORK_ERROR,
                customMessage = "RTDB GET failed: HTTP $httpCode",
                cause = when (httpCode) {
                    401 -> InternalErrorCode.CHANNEL_UPDATE_UNAUTHORIZED
                    403 -> InternalErrorCode.CHANNEL_UPDATE_FORBIDDEN
                    in 500..599 -> InternalErrorCode.CHANNEL_UPDATE_SERVER_ERROR
                    else -> InternalErrorCode.CHANNEL_UPDATE_UNEXPECTED_HTTP
                }
            )
            if (httpCode in 500..599) {
                throw ServerException(httpCode, exception)
            }
            throw exception
        }

        return response.body()
    }

    private fun decodeAuthEvent(payload: String, sid: String, seq: Int, key: Key): DecodeResult {
        if (seq < 1) {
            errorLog(TAG, "비정상적인 메시지 순서 (Replay 공격 의심): seq=$seq")
            return DecodeResult.Error(sid, FaceAuthFailReason.UNKNOWN)
        }
        val decryptedJson = try {
            val aadString = "${sid}:${seq}:u2k"

            cryptoEngine.decryptData(
                key = key,
                encryptedBase64 = payload,
                aad = aadString.toByteArray(Charsets.UTF_8)
            ).useAndWipe { safeBytes ->
                String(safeBytes, Charsets.UTF_8)
            }

        } catch (e: Exception) {
            errorLog(TAG, "decryptedJson error : $e")
            DiagnosticEventBus.emit {
                SdkDiagnosticEvent.ObserveError(
                    sessionId = sid,
                    reason = "decryption_error",
                    errorDetail = "seq=$seq, ${e.toString()}"
                )
            }
            return DecodeResult.Error(sid, FaceAuthFailReason.DECRYPTION_ERROR)
        }

        verboseLog(TAG, " decryptedJson : $decryptedJson")

        return try {
            val dto = decodeFromString<AuthPayloadDto>(decryptedJson)
            infoLog(TAG, "AuthPayload : $dto")
            val domain = dto.toDomain()

            if (domain is AuthPayload.Success) {
                DecodeResult.Success(sid, domain.deviceId)
            } else {
                DecodeResult.Error(sid, FaceAuthFailReason.UNKNOWN)
            }
        } catch (e: Exception) {
            errorLog(TAG, "AuthPayloadDto error : $e")
            DiagnosticEventBus.emit {
                SdkDiagnosticEvent.ObserveError(
                    sessionId = sid,
                    reason = "auth_payload_parse_error",
                    errorDetail = "seq=$seq, ${e.toString()}"
                )
            }
            DecodeResult.Error(sid, FaceAuthFailReason.PARSE_ERROR)
        }
    }

    override suspend fun clearUserToKioskData(
        sessions: Set<SessionData>,
        tokenMap: Map<String, AuthToken>
    ): Unit = coroutineScope {
        debugLog(TAG, "[CLEAR] user_to_kiosk 삭제 시작: ${sessions.size}개 세션")
        sessions.map { session ->
            async {
                val idToken = tokenMap[session.sessionId]?.idToken
                if (idToken == null) {
                    warnLog(TAG, "[CLEAR] user_to_kiosk 삭제 스킵 (토큰 없음) [${session.sessionId}]")
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.RtdbClearExecuted(
                            sessionId = session.sessionId,
                            node = USER_TO_KIOSK,
                            success = false
                        )
                    }
                    return@async
                }
                val result = runCatching {
                    val path = "${session.rtdbPath.trimEnd('/')}/$USER_TO_KIOSK.json"
                    firebaseApi.deleteSessionData("${BuildConfig.FB_DB_URL}$path", idToken)
                }
                result.onSuccess {
                    debugLog(TAG, "[CLEAR] 🧹user_to_kiosk 삭제 완료 [${session.sessionId}]")
                }.onFailure { e ->
                    errorLog(TAG, "[CLEAR] user_to_kiosk 삭제 실패 [${session.sessionId}]: ${e.message}")
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.RtdbClearExecuted(
                            sessionId = session.sessionId,
                            node = USER_TO_KIOSK,
                            success = false
                        )
                    }
                }
            }
        }.awaitAll()
    }

    override suspend fun clearKioskToUserData(
        sessions: Set<SessionData>,
        tokenMap: Map<String, AuthToken>
    ): Unit = coroutineScope {
        debugLog(TAG, "[CLEAR] kiosk_to_user 삭제 시작: ${sessions.size}개 세션")
        sessions.map { session ->
            async {
                val idToken = tokenMap[session.sessionId]?.idToken
                if (idToken == null) {
                    warnLog(TAG, "[CLEAR] kiosk_to_user 삭제 스킵 (토큰 없음) [${session.sessionId}]")
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.RtdbClearExecuted(
                            sessionId = session.sessionId,
                            node = KIOSK_TO_USER,
                            success = false
                        )
                    }
                    return@async
                }
                val result = runCatching {
                    val path = "${session.rtdbPath.trimEnd('/')}/$KIOSK_TO_USER.json"
                    firebaseApi.deleteSessionData("${BuildConfig.FB_DB_URL}$path", idToken)
                }
                result.onSuccess {
                    debugLog(TAG, "[CLEAR] 🧹kiosk_to_user 삭제 완료 [${session.sessionId}]")
                }.onFailure { e ->
                    errorLog(TAG, "[CLEAR] kiosk_to_user 삭제 실패 [${session.sessionId}]: ${e.message}")
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.RtdbClearExecuted(
                            sessionId = session.sessionId,
                            node = KIOSK_TO_USER,
                            success = false
                        )
                    }
                }
            }
        }.awaitAll()
    }

    override suspend fun authenticateSessions(
        sessions: Set<SessionData>
    ): Map<SessionData, Result<AuthToken>> = coroutineScope {
        debugLog(TAG, "authenticateSessions 병렬 인증 시작: ${sessions.size}개 세션")

        sessions.map { session ->
            async {
                val result = runCatching { authenticate(session.firebaseToken) }
                session to result
            }
        }.awaitAll().toMap()
    }

    override suspend fun updateKioskSecureData(
        sessionPayloads: Map<SessionData, EncryptedSessionPayload>,
        tokenMap: Map<SessionData, AuthToken>
    ): Map<SessionData, Result<Unit>> = coroutineScope {
        debugLog(TAG, "updateKioskSecureData 일괄 업데이트 진행: ${sessionPayloads.size}개 세션")

        sessionPayloads.map { (session, payload) ->
            async {
                val result = runCatching {
                    val authToken = tokenMap[session] ?: throw GoPassSdkException.from(
                        error = ErrorCode.INTERNAL_ERROR,
                        cause = InternalErrorCode.FB_AUTH_NULL
                    )

                    // 🚨 키오스크가 유저에게 전송하므로 KIOSK_TO_USER 경로 업데이트
                    val path = "${session.rtdbPath.trimEnd('/')}/$KIOSK_TO_USER.json"

                    val dataToPush = KioskToUserPayloadDto(
                        payload = payload.encryptedData,
                        seq = payload.seq
                    )

                    val response = firebaseApi.updateSessionState("${BuildConfig.FB_DB_URL}$path", authToken.idToken, dataToPush)
                    if (!response.isSuccessful) {
                        val httpCode = response.code()
                        throw GoPassSdkException.from(
                            error = ErrorCode.INTERNAL_ERROR,
                            customMessage = "RTDB PATCH failed: HTTP $httpCode",
                            cause = when (httpCode) {
                                401 -> InternalErrorCode.CHANNEL_UPDATE_UNAUTHORIZED
                                403 -> InternalErrorCode.CHANNEL_UPDATE_FORBIDDEN
                                in 500..599 -> InternalErrorCode.CHANNEL_UPDATE_SERVER_ERROR
                                else -> InternalErrorCode.CHANNEL_UPDATE_UNEXPECTED_HTTP
                            }
                        )
                    }
                }
                result.onFailure { e ->
                    DiagnosticEventBus.emit {
                        SdkDiagnosticEvent.RtdbWriteResult(
                            sessionId = session.sessionId,
                            seq = payload.seq,
                            success = false,
                            errorDetail = e.toString()
                        )
                    }
                }
                session to result
            }
        }.awaitAll().toMap()
    }
}
