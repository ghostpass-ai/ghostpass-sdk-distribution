package com.ghostpasskiosksdk.gopasskiosksdk.internal.manager

import android.view.Surface
import com.ghostpasskiosksdk.gopasskiosksdk.BuildConfig
import com.ghostpasskiosksdk.gopasskiosksdk.core.device.domain.NetworkStateProvider
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.infra.EphemeralAesKey
import com.ghostpasskiosksdk.gopasskiosksdk.core.security.domain.CryptoEngine
import com.ghostpasskiosksdk.gopasskiosksdk.data.dto.internal.auth.FaceVectorPayloadDto
import com.ghostpasskiosksdk.gopasskiosksdk.domain.gateway.BeaconBroadcaster
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.EncryptedSessionPayload
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.FailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.GoPassAuthResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.ErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.external.error.GoPassSdkException
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthFailReason
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.auth.FaceAuthPrecheckResult
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionData
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionIdEvent
import com.ghostpasskiosksdk.gopasskiosksdk.domain.model.internal.session.SessionInfoPayload
import com.ghostpasskiosksdk.gopasskiosksdk.data.mapper.getOrThrow
import com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase.ExecuteRemoteAuthUseCase
import com.ghostpasskiosksdk.gopasskiosksdk.domain.usecase.PrepareFaceAuthUseCase
import com.ghostpasskiosksdk.gopasskiosksdk.internal.mapper.mapAuthExceptionToResult
import com.ghostpasskiosksdk.gopasskiosksdk.utils.debugLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.errorLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.infoLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.warnLog
import com.ghostpasskiosksdk.gopasskiosksdk.utils.wipe
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json.Default.encodeToString
import java.util.concurrent.atomic.AtomicBoolean

internal class AuthOrchestrator(
    private val remoteAuthUseCase: ExecuteRemoteAuthUseCase,
    private val cryptoEngine: CryptoEngine,
    private val prepareFaceAuthUseCase: PrepareFaceAuthUseCase,
    private val beaconBroadcaster: BeaconBroadcaster,
    private val networkStateProvider: NetworkStateProvider,
    private val sessionManager: SessionManager,
    private val sseConnectionManager: SseConnectionManager
) : SseConnectionManager.EventListener {

    companion object {
        private val TAG = "AuthOrchestrator ${BuildConfig.SIGNATURE}"
        private const val LANDMARK_EXPIRY_MILLIS = 30_000L
        private const val PHONE_AUTH_RESULT_TIMEOUT_MILLIS = 8_000L
    }

    // 번호 인증용 랜드마크 임시 보관소
    @Volatile
    private var pendingLandmark: FloatArray? = null
    @Volatile
    private var landmarkTimestamp: Long = 0L

    private val orchestratorScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val connectedDeviceIds: StateFlow<List<String>>
        get() = sessionManager.connectedDeviceIds

    val sseConnectionState
        get() = sseConnectionManager.sseConnectionState

    // 상태 관리 플래그
    private val isProcessingInFlight = AtomicBoolean(false)
    private val isRemoteAuthInFlight = AtomicBoolean(false)

    // 백그라운드 인증 결과 저장소
    @Volatile
    private var pendingAuthResult: GoPassAuthResult? = null

    @Volatile
    private var isDestroyed = false

    // ── SSE 연결 위임 ──────────────────────────────────────────────

    init {
        sseConnectionManager.eventListener = this
    }

    fun startSessionCollection(force: Boolean = false): Boolean =
        sseConnectionManager.startSessionCollection(force)

    fun stopSessionCollection() = sseConnectionManager.stopSessionCollection()

    fun forceReconnect(reason: String): Boolean = sseConnectionManager.forceReconnect(reason)

    // ── SseConnectionManager.EventListener ─────────────────────────

    override suspend fun onSessionCreated(payload: SessionInfoPayload) =
        sessionManager.processSessionPayload(payload)

    override fun onSessionTerminated(sessionId: String) =
        sessionManager.processSessionTermination(sessionId)

    override fun onSessionSync(sessionIds: Set<String>) =
        sessionManager.processSessionSync(sessionIds)

    // ── 얼굴 인식 인증 시퀀스 ──────────────────────────────────────

    /**
     * 얼굴 인식부터 서버 인증까지의 전체 시퀀스 실행
     *
     * 얼굴 검증 통과 시 [GoPassAuthResult.Authenticating]을 즉시 반환하고,
     * 원격 인증은 백그라운드([launchRemoteAuth])로 실행한다.
     * 이후 호출에서 [pendingAuthResult]를 통해 최종 결과를 전달한다.
     */
    suspend fun execute(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotation: Int,
    ): GoPassAuthResult = withContext(Dispatchers.Default) {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 인증 요청은 거부됩니다.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.AUTH_ERROR,
                message = ErrorCode.AUTH_ERROR.message!!
            )
        }

        // 백그라운드 인증 결과가 준비되었으면 즉시 반환
        pendingAuthResult?.let { result ->
            pendingAuthResult = null
            debugLog(TAG, "백그라운드 인증 결과 반환: $result")
            return@withContext result
        }

        // 서버 인증이 백그라운드에서 진행 중이면 Authenticating 반환
        if (isRemoteAuthInFlight.get()) {
            return@withContext GoPassAuthResult.Authenticating
        }

        if (!networkStateProvider.isAvailable.value) {
            warnLog(TAG, "네트워크 단절 감지됨. 인증 시도 거부.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.NETWORK_ERROR,
                message = "기기 네트워크 연결이 끊어졌습니다."
            )
        }

        if (sseConnectionManager.isAuthBlockedBySseState()) {
            warnLog(TAG, "SSE 연결 불안정 상태 감지됨. 인증 시도 거부.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.NETWORK_ERROR,
                message = ErrorCode.NETWORK_ERROR.message!!
            )
        }

        if (sessionManager.sessions.value.isEmpty()) {
            return@withContext GoPassAuthResult.PrecheckGuide(listOf(FailReason.NO_SESSION))
        }

        if (!isProcessingInFlight.compareAndSet(false, true)) {
            return@withContext GoPassAuthResult.PrecheckGuide(listOf(FailReason.ALREADY_IN_PROGRESS))
        }

        // compareAndSet 직후 try 진입 — 사이에 코드 없음 (OOM 고착 방지)
        try {
            val surfaceRotation = mapToSurfaceRotation(rotation)
            val precheckResult = prepareFaceAuthUseCase.execute(
                faceImage = faceImage,
                width = width,
                height = height,
                rotation = surfaceRotation
            )

            if (precheckResult is FaceAuthPrecheckResult.Failed) {
                isProcessingInFlight.set(false)
                return@withContext GoPassAuthResult.PrecheckGuide(precheckResult.reasons)
            }

            val successPrecheck = precheckResult as FaceAuthPrecheckResult.Success
            debugLog(TAG, "landmark size : ${successPrecheck.landmark.size}")

            // 원격 인증을 백그라운드로 분리
            isRemoteAuthInFlight.set(true)
            launchRemoteAuth(successPrecheck)

            return@withContext GoPassAuthResult.Authenticating
        } catch (e: Exception) {
            isProcessingInFlight.set(false)
            errorLog(TAG, "execute precheck error: $e")
            return@withContext handleAuthException(e)
        }
    }

    /**
     * 원격 인증을 백그라운드로 실행한다.
     * 결과는 [pendingAuthResult]에 저장되며, 다음 [execute] 호출 시 반환된다.
     */
    private fun launchRemoteAuth(successPrecheck: FaceAuthPrecheckResult.Success) {
        orchestratorScope.launch(Dispatchers.Default) {
            var winnerSessionId: String? = null
            var currentSessions: Set<SessionData> = emptySet()
            try {
                beaconBroadcaster.pause()

                // 1. 캐싱된 토큰 수집
                currentSessions = sessionManager.sessions.value
                val uncachedSessions = currentSessions.filter { sessionManager.getCachedAuthToken(it.sessionId) == null }
                val freshTokens = if (uncachedSessions.isNotEmpty()) {
                    warnLog(TAG, "미캐싱 세션 ${uncachedSessions.size}개 즉시 인증 시도")
                    remoteAuthUseCase.authenticateSessions(uncachedSessions.toSet())
                } else emptyMap()

                val preAuthTokens = currentSessions.associateWith { session ->
                    sessionManager.getCachedAuthToken(session.sessionId)?.let { Result.success(it) }
                        ?: freshTokens[session]
                        ?: Result.failure(GoPassSdkException.from(
                            error = ErrorCode.INTERNAL_ERROR,
                            cause = InternalErrorCode.FB_AUTH_NULL
                        ))
                }

                // 2. auth-progress 비동기 호출 (타임아웃 +10초 버퍼 적용, 인증 완료 후 finally에서 복원)
                sessionManager.notifyAuthProgressWithBuffer(currentSessions)

                // 3. 암호화 + RTDB 업데이트 + 관찰
                val sessionPayloads = currentSessions.associateWith { session ->
                    val currentSeq = sessionManager.getAndIncrementSeq(session.sessionId)
                    encryptLandmark(successPrecheck.landmark, session, currentSeq)
                }

                val authResult = remoteAuthUseCase(sessionPayloads, preAuthTokens)
                if (authResult is SessionIdEvent.Success) {
                    winnerSessionId = authResult.sessionId
                }
                pendingAuthResult = mapAuthResult(authResult)
            } catch (e: Exception) {
                errorLog(TAG, "launchRemoteAuth error: $e")
                pendingAuthResult = handleAuthException(e)
             } finally {                     
                  // 부가 작업: 개별 runCatching으로 실패해도 다음 단계 실행 보장
                  runCatching {               
                      if (winnerSessionId != null) {                                                                                                                                                                                     
                          sessionManager.removeWinnerSession(winnerSessionId!!)
                      }                                                                                                                                                                                                                  
                  }                                        
                runCatching { sessionManager.restoreAuthProgressBuffer(currentSessions) }    
                runCatching { beaconBroadcaster.resume() }
                // AtomicBoolean.set()은 예외를 던질 수 없음 — 항상 실행 보장
                isRemoteAuthInFlight.set(false)
                isProcessingInFlight.set(false)
                warnLog(TAG, "백그라운드 인증 시퀀스 완료 sessionId size : ${sessionManager.sessions.value.size}")
            }
        }
    }

    // ── 공통 유틸 (detection / phoneAuth 공유) ─────────────────────

    private fun encryptLandmark(
        landmark: FloatArray,
        session: SessionData,
        seq: Int
    ): EncryptedSessionPayload {
        val aadString = "${session.sessionId}:${seq}:k2u"
        debugLog(TAG, "aadString : $aadString")
        val aad = aadString.toByteArray(Charsets.UTF_8)

        val payloadDto = FaceVectorPayloadDto(
            vector = landmark,
            timestamp = System.currentTimeMillis()
        )

        val plainTextJson = encodeToString(payloadDto)
        val finalPayload = cryptoEngine.encrypt(
            plainText = plainTextJson,
            key = session.dkKiosk,
            aad = aad
        )
        return EncryptedSessionPayload(encryptedData = finalPayload, seq = seq)
    }

    private fun mapAuthResult(authResult: SessionIdEvent): GoPassAuthResult {
        return when (authResult) {
            is SessionIdEvent.Success -> {
                debugLog(TAG, "인증 성공 sessionId: ${authResult.sessionId}")
                GoPassAuthResult.Success(deviceId = authResult.deviceId)
            }
            is SessionIdEvent.Failed -> {
                debugLog(TAG, "인증 실패: ${authResult.reason}")
                val errorCode = if (authResult.reason == FaceAuthFailReason.TIMEOUT) {
                    ErrorCode.AUTH_TIMEOUT
                } else {
                    ErrorCode.AUTH_REJECTED
                }
                GoPassAuthResult.ServerAuthFailed(
                    message = errorCode.message ?: ErrorCode.AUTH_ERROR.message!!,
                    errorCode = errorCode
                )
            }
        }
    }

    private fun handleAuthException(e: Exception): GoPassAuthResult {
        val result = mapAuthExceptionToResult(e)
        val sdkException = e as? GoPassSdkException
            ?: GoPassSdkException.from(error = ErrorCode.INTERNAL_ERROR)
        errorLog(
            TAG,
            "인증 중 예외 발생: code=${sdkException.code}, causeCode=${sdkException.causeCode}, mapped=${result.errorCode.externalCode}, message=${sdkException.message}"
        )
        return result
    }

    private fun mapToSurfaceRotation(degrees: Int): Int {
        return when (degrees) {
            270 -> Surface.ROTATION_270
            0 -> Surface.ROTATION_0
            90 -> Surface.ROTATION_90
            180 -> Surface.ROTATION_180
            else -> Surface.ROTATION_270
        }
    }

    // ── Phone Auth Step 1: 랜드마크 추출 및 임시 보관 ──────────────────────

    suspend fun prepareLandmarkForPhoneAuth(
        faceImage: ByteArray?,
        width: Int,
        height: Int,
        rotation: Int
    ): GoPassAuthResult = withContext(Dispatchers.Default) {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 preparePhoneAuth 요청은 거부됩니다.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.AUTH_ERROR,
                message = ErrorCode.AUTH_ERROR.message!!
            )
        }

        infoLog(TAG, "Phone Auth Step 1 (preparePhoneAuth) 호출")

        if (!networkStateProvider.isAvailable.value) {
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.NETWORK_ERROR,
                message = ErrorCode.NETWORK_ERROR.message!!
            )
        }

        if (!isProcessingInFlight.compareAndSet(false, true)) {
            return@withContext GoPassAuthResult.PrecheckGuide(listOf(FailReason.ALREADY_IN_PROGRESS))
        }

        try {
            val surfaceRotation = mapToSurfaceRotation(rotation)
            val precheckResult = prepareFaceAuthUseCase.execute(
                faceImage = faceImage,
                width = width,
                height = height,
                rotation = surfaceRotation
            )

            if (precheckResult is FaceAuthPrecheckResult.Failed) {
                return@withContext GoPassAuthResult.PrecheckGuide(precheckResult.reasons)
            }

            val successPrecheck = precheckResult as FaceAuthPrecheckResult.Success
            debugLog(TAG, "Phone Auth 랜드마크 추출 성공, size: ${successPrecheck.landmark.size}")

            clearPendingLandmark()
            pendingLandmark = successPrecheck.landmark.copyOf()
            landmarkTimestamp = System.currentTimeMillis()

            GoPassAuthResult.Success(deviceId = "")
        } finally {
            isProcessingInFlight.set(false)
        }
    }

    // ── Phone Auth Step 2: 세션 생성 + 랜드마크 업로드 + 인증 관찰 ──────

    suspend fun executePhoneAuth(
        deviceId: String
    ): GoPassAuthResult = withContext(Dispatchers.Default) {
        if (isDestroyed) {
            warnLog(TAG, "destroy 이후 submitPhoneAuth 요청은 거부됩니다.")
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.AUTH_ERROR,
                message = ErrorCode.AUTH_ERROR.message!!
            )
        }

        infoLog(TAG, "Phone Auth Step 2 (submitPhoneAuth) 호출")

        val landmark = pendingLandmark ?: return@withContext GoPassAuthResult.ServerAuthFailed(
            errorCode = ErrorCode.AUTH_ERROR,
            message = ErrorCode.AUTH_ERROR.message!!
        )

        val elapsed = System.currentTimeMillis() - landmarkTimestamp
        if (elapsed > LANDMARK_EXPIRY_MILLIS) {
            clearPendingLandmark()
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.PHONE_AUTH_LANDMARK_EXPIRED,
                message = ErrorCode.PHONE_AUTH_LANDMARK_EXPIRED.message!!
            )
        }

        if (!networkStateProvider.isAvailable.value) {
            return@withContext GoPassAuthResult.ServerAuthFailed(
                errorCode = ErrorCode.NETWORK_ERROR,
                message = ErrorCode.NETWORK_ERROR.message!!
            )
        }

        if (!isProcessingInFlight.compareAndSet(false, true)) {
            return@withContext GoPassAuthResult.PrecheckGuide(listOf(FailReason.ALREADY_IN_PROGRESS))
        }

        var session: SessionData? = null
        var beaconPaused = false
        try {
            val payload = sessionManager.requestSession(deviceId).getOrThrow()

            session = sessionManager.decryptAndCreateSessionData(
                sessionId = payload.sessionId,
                rtdbPath = payload.rtdbPath,
                encryptedDk = payload.encryptedDk,
                firebaseToken = payload.firebaseToken,
                expiresAtMillis = payload.expiresAtMillis,
                deviceId = deviceId
            )
            debugLog(TAG, "Phone Auth 세션 생성 완료: sessionId=${session.sessionId}")

            beaconBroadcaster.pause()
            beaconPaused = true

            val encryptedPayload = encryptLandmark(landmark, session, seq = 1)
            val preAuthTokens = remoteAuthUseCase.authenticateSessions(setOf(session))
            mapAuthResult(
                remoteAuthUseCase(
                    sessionPayloads = mapOf(session to encryptedPayload),
                    preAuthTokens = preAuthTokens,
                    timeoutMs = PHONE_AUTH_RESULT_TIMEOUT_MILLIS
                )
            )
        } catch (e: Exception) {
            errorLog(TAG, "executePhoneAuth error : $e")
            handleAuthException(e)
        } finally {
            clearPendingLandmark()
            session?.destroySecurely()
            isProcessingInFlight.set(false)
            if (beaconPaused) beaconBroadcaster.resume()
            warnLog(TAG, "Phone Auth 시퀀스 완료")
        }
    }

    // ── Phone Auth 유틸 ──────────────────────────────────────────────

    private fun clearPendingLandmark() {
        pendingLandmark.wipe()
        pendingLandmark = null
        landmarkTimestamp = 0L
    }

    // ── 자원 정리 ──────────────────────────────────────────────────

    fun destroy() {
        if (isDestroyed) {
            warnLog(TAG, "AuthOrchestrator destroy 중복 호출은 무시됩니다.")
            return
        }

        isDestroyed = true
        sseConnectionManager.destroy()
        sessionManager.destroy()
        clearPendingLandmark()
        pendingAuthResult = null
        isRemoteAuthInFlight.set(false)
        isProcessingInFlight.set(false)
        remoteAuthUseCase.destroy()
        prepareFaceAuthUseCase.reset()
        orchestratorScope.coroutineContext[Job]?.cancel()
        warnLog(TAG, "AuthOrchestrator 전체 자원 정리 완료")
    }

    private fun SessionData.destroySecurely() {
        runCatching {
            val ephemeralKey = this.dkKiosk as? EphemeralAesKey
            if (ephemeralKey?.isDestroyed() == false) {
                ephemeralKey.destroy()
                debugLog(TAG, "세션 [${this.sessionId}] dkKiosk 메모리 안전 파기 완료")
            }
        }.onFailure { e ->
            errorLog(TAG, "세션 [${this.sessionId}] dkKiosk 파기 실패: ${e.message}")
        }
    }
}
