/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.ghostpasssdk.gopasssdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.ghostpasssdk.gopasssdk";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "prod";
  // Field from product flavor: prod
  public static final String API_KEY = "e871b8eee98b2528b553d446802277228363b22a734b20e8b1ea04e37c6c2f74";
  // Field from product flavor: prod
  public static final String BASE_URL = "https://api.ghostpass.ai/";
  // Field from product flavor: prod
  public static final long CLOUD_PROJECT_NUMBER = 983728568L;
  // Field from product flavor: prod
  public static final String FB_API_KEY = "AIzaSyAk2OebswVEFTIs9OZ2Ai31dCz4gNkzOAA";
  // Field from product flavor: prod
  public static final String FB_APP_ID = "1:1009061735210:android:db59eff6a6986b9a144c53";
  // Field from product flavor: prod
  public static final String FB_DB_URL = "https://gpass-35626-default-rtdb.asia-southeast1.firebasedatabase.app";
  // Field from product flavor: prod
  public static final String FB_PROJECT_ID = "gpass-35626";
  // Field from default config.
  public static final String RTDB_IV = "wnuioUrF6A3pVDtp";
  // Field from default config.
  public static final String RTDB_SECRET_KEY = "2025Y03M13DDmM0a2tD2Hxa2ztUDJSge";
  // Field from build type: release
  public static final String SDK_VERSION = "1.1.1";
  // Field from default config.
  public static final String SHARED_KEY = "G/27bSLmS5bWI6iFiEEhvqza9nUXG7pMJmP/sGNpHtk=";
  // Field from default config.
  public static final String SIGNATURE = "TAG GHOSTPASS";
}
