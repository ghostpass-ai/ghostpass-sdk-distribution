package com.ghostpasssdk.gopasssdk.domain.engine.face.policy

import kotlin.math.ceil

/**
 * 얼굴 특징 추출에 사용되는 정렬 얼굴 이미지의 해상도 규격을 만족하는 입력인지 판정하는 정책.
 *
 * ## 근거
 * 알체라 SDK 의 인식 네트워크 입력은 고정 크기다.
 * `FeatureExtension.InputAlignedFaceImage.kWidth = kHeight = 112`, `kChannels = 3`
 * 즉 `ExtractFeature()` 는 어떤 경로로 들어와도 최종적으로 112x112 BGR 로 정렬(warp)된
 * 얼굴을 본다. 따라서 품질을 결정하는 것은 "정렬 결과의 크기"가 아니라
 * **원본 프레임에서 그 112px 를 만들어 내는 소스 픽셀의 양**이다.
 *
 * 얼굴 박스 폭이 [alignedFaceWidth] 에 미달하면 정렬 단계에서 업스케일이 발생하고,
 * 없는 정보를 보간해 만든 임베딩이 저장된다.
 *
 * ## 벤더 샘플의 croppedFace(ratio=0.33, resizeWidth=200) 와의 관계
 * 해당 헬퍼는 SDK jar 에 존재하지 않는 **샘플 앱 유틸**이며, 출력도
 * `200 x round(200 / (expandedWidth / expandedHeight))` 로 얼굴 박스 종횡비에 따라
 * 달라지는 가변 크기다(200x250 고정이 아니다). 200 은 화면 표시/전송용 크기이고
 * 인식 입력 규격이 아니다. 본 SDK 는 `ExtractFeature(InputImage, Face)` 로
 * 네이티브 정렬을 사용하므로 중간 리샘플 없이 원본 → 112x112 로 직행한다.
 */
internal class AlignedFaceSpecPolicy(
    private val alignedFaceWidth: Int,
    private val alignedFaceHeight: Int,
    private val maxFaceWidthFrameRate: Float = DEFAULT_MAX_FACE_WIDTH_FRAME_RATE
) {
    companion object {
        /**
         * 얼굴 박스 폭 상한을 정하는 프레임 폭 분모. 기존 어댑터 합의값을 그대로 승계한다.
         * (imageWidth / 1.7 이므로 480px 프레임에서 282px)
         */
        const val DEFAULT_MAX_FACE_WIDTH_FRAME_RATE = 1.7f
    }

    /**
     * 최소 얼굴 박스 폭(px). 모델 입력 폭과 동일하다.
     * 프레임 폭 대비 비율이 아닌 절대 픽셀 기준이므로 카메라 해상도가 달라져도 규격이 유지된다.
     *
     * **이 값은 필요조건이며 충분조건이 아니다.** 네이티브 정렬(affine warp)이 실제로 참조하는
     * 소스 영역은 얼굴 박스와 정확히 일치하지 않고(랜드마크 기준이라 박스보다 넓거나 좁을 수 있으며
     * 정확한 범위는 .so 내부라 확인 불가), 따라서 박스 폭이 이 값 이상이어도 업스케일이
     * 발생할 여지는 남는다. 다만 박스 폭이 이 값에 **미달하면 어떤 정렬 방식이든 업스케일이 확실히
     * 발생**하므로, 근거를 댈 수 있는 가장 관대한 하한으로서 채택한다.
     *
     * 더 엄격한 기준이 필요하면 벤더 프로파일 비율(`ALCFaceValidationConfig.VALID_FACE_SIZE_MIN_RATE`:
     * GENERAL 0.1 / FINANCE 0.4)을 [maxFaceWidthFrameRate] 처럼 별도 파라미터로 병행해야 한다.
     */
    val minFaceBoxWidth: Int = alignedFaceWidth

    /**
     * 규격을 만족하는 얼굴이 존재할 수 있는 최소 프레임 폭(px).
     *
     * 상한이 `imageWidth / [maxFaceWidthFrameRate]` 이므로, 프레임이 이보다 좁으면
     * 상한이 [minFaceBoxWidth] 아래로 내려가 하한/상한 구간이 역전된다.
     * 즉 사용자가 아무리 다가와도 통과할 수 없는 프레임이다.
     * (112 * 1.7 = 191px)
     */
    val minFrameWidth: Int = ceil(alignedFaceWidth * maxFaceWidthFrameRate).toInt()

    /** 얼굴 박스 폭 상한(px). */
    fun maxFaceBoxWidth(imageWidth: Int): Float = imageWidth / maxFaceWidthFrameRate

    fun isFrameCapable(imageWidth: Int): Boolean = imageWidth >= minFrameWidth

    /** 최소 얼굴 박스 높이(px). 모델 입력 높이와 동일하다. */
    val minFaceBoxHeight: Int = alignedFaceHeight

    /**
     * 벤더 샘플(`VerifyPhotoFragment.faceIsTooSmall`)은 `w * h < 112 * 112` 로 면적을 보지만,
     * 면적 기준은 납작하거나 홀쭉한 박스를 통과시킨다(예: 200x60 은 면적 미달로 탈락하지만
     * 300x50 은 면적을 충족한다). 양축을 각각 검사해 그 허점을 막는다.
     */
    fun isFaceLargeEnough(faceBoxWidth: Float, faceBoxHeight: Float): Boolean =
        faceBoxWidth >= minFaceBoxWidth && faceBoxHeight >= minFaceBoxHeight

    fun isFaceSmallEnough(imageWidth: Int, faceBoxWidth: Float): Boolean =
        faceBoxWidth < maxFaceBoxWidth(imageWidth)
}
