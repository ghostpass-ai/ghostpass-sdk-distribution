package com.ghostpasssdk.gopasssdk.data.engine.monitor

import android.content.Context
import android.content.Intent
import android.os.Build
import com.ghostpasssdk.gopasssdk.domain.engine.monitor.MonitoringServiceLauncher

internal class AndroidMonitoringServiceLauncher(
    private val context: Context
) : MonitoringServiceLauncher {

    override val isServiceRunning: Boolean
        get() = BeaconDetectionService.isServiceAlive

    override fun launchService() {
        val intent = Intent(context, BeaconDetectionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    override fun stopService() {
        val intent = Intent(context, BeaconDetectionService::class.java).apply {
            action = BeaconDetectionService.ACTION_STOP_FOREGROUND
        }
        context.startService(intent)
    }
}
