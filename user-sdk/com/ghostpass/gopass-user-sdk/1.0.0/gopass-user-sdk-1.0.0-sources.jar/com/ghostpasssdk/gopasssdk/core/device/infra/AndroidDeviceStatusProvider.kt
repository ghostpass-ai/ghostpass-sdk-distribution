package com.ghostpasssdk.gopasssdk.core.device.infra

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.bluetooth.BluetoothManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.ghostpasssdk.gopasssdk.core.device.domain.DeviceStatusProvider

internal class AndroidDeviceStatusProvider(
    private val context: Context,
    private val bluetoothManager: BluetoothManager,
    private val connectivityManager: ConnectivityManager,
    private val locationManager: LocationManager
) : DeviceStatusProvider {

    override fun isBluetoothPermissionGranted(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return true
        }

        return hasPermission(Manifest.permission.BLUETOOTH_SCAN)
    }

    override fun isLocationPermissionGranted(): Boolean {
        return hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
            hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    override fun isLocationPermissionSufficient(): Boolean {
        if (!isLocationPermissionGranted()) {
            return false
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return true
        }

        return hasPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    }

    override fun isBluetoothEnabled(): Boolean {
        return runCatching { bluetoothManager.adapter?.isEnabled == true }
            .getOrDefault(false)
    }

    override fun isNetworkConnected(): Boolean {
        val nw = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(nw) ?: return false

        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    override fun isGpsEnabled(): Boolean {
        return try {
            LocationManagerCompat.isLocationEnabled(locationManager)
        } catch (_: Exception) {
            false
        }
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }
}
