package com.ghostpasssdk.gopasssdk.domain.model.external

import androidx.annotation.Keep

@Keep
enum class CaptureGuide(
    val code: String,
    val message: String,
) {
    NO_FACE_DETECTED(
        code = "L1001",
        message = "얼굴이 감지되지 않았습니다. 정면을 바라봐 주세요.",
    ),

    INVALID_POSE_ROLL(
        code = "L1002",
        message = "고개를 삐딱하지 않게 똑바로 세워주세요.",
    ),

    INVALID_POSE_PITCH(
        code = "L1003",
        message = "고개를 숙이거나 들지 말고 정면을 바라봐 주세요.",
    ),

    INVALID_POSE_YAW(
        code = "L1004",
        message = "옆을 보지 말고 정면을 바라봐 주세요.",
    ),

    INVALID_POSITION(
        code = "L1005",
        message = "얼굴 위치가 화면 중앙에서 벗어났습니다.",
    ),

    FACE_TOO_SMALL(
        code = "L1006",
        message = "얼굴이 너무 멀리 있습니다. 카메라에 가까이 다가가 주세요.",
    ),

    FACE_TOO_BIG(
        code = "L1007",
        message = "얼굴이 너무 가까이 있습니다. 한 걸음 뒤로 물러나 주세요.",
    ),

    LOW_CONFIDENCE(
        code = "L1008",
        message = "얼굴 인식이 불안정합니다. 조금 만 더 또렷하게 보여주세요.",
    ),

    COLLECTING_FRAMES(
        code = "L1009",
        message = "인증을 진행하고 있습니다..."
    ),

    LIVENESS_NOT_CONFIRMED(
        code = "L1010",
        message = "실제 사람인지 확인 중입니다.\n잠시 멈춰주세요."
    ),

    ALREADY_COMPLETED(
        code = "L1011",
        message = "이미 완료되었습니다."
    )
}