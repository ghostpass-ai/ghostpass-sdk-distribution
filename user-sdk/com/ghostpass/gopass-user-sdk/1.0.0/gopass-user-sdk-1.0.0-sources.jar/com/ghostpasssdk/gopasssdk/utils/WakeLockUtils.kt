package com.ghostpasssdk.gopasssdk.utils

import android.content.Context
import android.os.PowerManager

suspend inline fun <T> Context.withUploadWakeSuspend(
    timeoutMs: Long = 7_000,
    crossinline block: suspend () -> T
): T {
    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
    val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ghostpass:beacon-upload")
    wl.acquire(timeoutMs)
    try {
        return block()
    } finally {
        if (wl.isHeld) wl.release()
    }
}