package com.ghostpasssdk.gopasssdk.data.api

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResponse
import com.ghostpasssdk.gopasssdk.data.dto.token.PushTokenRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

internal interface TokenApi {
    companion object {
        private const val PREFIX = "api/v1/sdk"
    }

    @POST("$PREFIX/device/push-token")
    suspend fun requestPushTokenUpdate(@Body body: PushTokenRequest): Response<ApiResponse<Unit>>
}