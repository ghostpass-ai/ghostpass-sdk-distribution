package com.ghostpasssdk.gopasssdk.core.security.infra

import com.ghostpasssdk.gopasssdk.utils.wipe
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.SecretKey
import javax.security.auth.Destroyable

internal class EphemeralAesKey(
    private var keyBytes: ByteArray
) : SecretKey, Destroyable {
    private val destroyed = AtomicBoolean(false)

    override fun getAlgorithm(): String = "AES"

    override fun getFormat(): String = "RAW"

    override fun getEncoded(): ByteArray {
        check(!destroyed.get()) { "EphemeralAesKey is already destroyed" }
        return keyBytes.copyOf()
    }

    override fun destroy() {
        if (!destroyed.compareAndSet(false, true)) return

        keyBytes.wipe()
        keyBytes = ByteArray(0)
    }

    override fun isDestroyed(): Boolean = destroyed.get()
}
