package com.ghostpasssdk.gopasssdk.domain.model.internal.provision

internal data class Provision(
    val serverPublicKey: String,
    val encryptedAppSecret: String,
    val identityId: String,
    val deviceId: String
)
