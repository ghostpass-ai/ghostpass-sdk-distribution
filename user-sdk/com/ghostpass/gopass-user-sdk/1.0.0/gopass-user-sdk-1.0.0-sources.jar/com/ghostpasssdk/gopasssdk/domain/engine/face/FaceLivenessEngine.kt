package com.ghostpasssdk.gopasssdk.domain.engine.face

import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceEngineTypes
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.LivenessResult

internal interface FaceLivenessEngine {
    suspend fun evaluate(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): LivenessResult
}