package com.ghostpasssdk.gopasssdk.data.engine.face

import com.ghostpasssdk.gopasssdk.domain.model.external.CaptureGuide
import com.ghostpasssdk.gopasssdk.data.engine.face.capability.FaceDetectionCapability
import com.ghostpasssdk.gopasssdk.data.engine.face.wrapper.AlcheraDetectedFace
import com.ghostpasssdk.gopasssdk.data.engine.face.wrapper.AlcheraImageFrame
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceDetectionEngine
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceEngineTypes
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceExtractResult
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlin.math.abs

internal class AlcheraDetectionAdapter(
    private val capability: FaceDetectionCapability
) : FaceDetectionEngine {
    companion object {
        private const val TAG = "AlcheraDetection TAG"
        private const val YAW_DEGREE = 15.0f
        private const val PITCH_DEGREE = 20.0f
        private const val ROLL_DEGREE = 15.0f
        private const val VALID_FACE_WIDTH_POSITION_RATE = 9f
        private const val VALID_FACE_HEIGHT_POSITION_RATE = 9f
        private const val VALID_FACE_SIZE_MIN_RATE_ORIENTATION_PORTRAIT = 8.0f
        private const val VALID_FACE_SIZE_MAX_RATE_ORIENTATION_PORTRAIT = 1.7f
        private const val VALID_FACE_DETECT_CONFIDENCE_VALUE = 0.9f
    }

    override fun checkMemory(width: Int, height: Int) {
        val runtime = Runtime.getRuntime()
        val available = runtime.maxMemory() - (runtime.totalMemory() - runtime.freeMemory())
        val expected = (width * height * 1.5).toLong()
        debugLog(
            TAG,
            "checkMemory | available=${available / 1024}KB, expected=${expected * 2 / 1024}KB"
        )

        if (available < expected * 2) {
            System.gc()
            warnLog(TAG, "checkMemory | OOM 위험 → Failed")
            throw GoPassException.from(
                error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                internalCode = InternalErrorCode.INPUT_IMAGE_MEMORY_INSUFFICIENT
            )
        }
    }

    override fun createInputImage(
        faceImage: ByteArray, width: Int, height: Int, rotation: Int
    ): FaceEngineTypes.FaceImageFrame {
        val inputImage = capability.getInputImageFromNV21Buffer(
            faceImage, width, height, rotation, true
        )
        return AlcheraImageFrame(inputImage)
    }

    override fun detectFirstFace(
        inputImage: FaceEngineTypes.FaceImageFrame
    ): FaceEngineTypes.DetectedFace? {
        return try {
            val alcheraImage = (inputImage as AlcheraImageFrame).originImage

            val facesResult = capability.detectFaceInContinuousImage(alcheraImage)
            val face = facesResult.faces.firstOrNull()
            if (face != null)
                AlcheraDetectedFace(face)
            else null

        } catch (e: Exception) {
            errorLog(TAG, "detectFirstFace | error: $e")
            throw GoPassException.from(
                error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                customMessage = "얼굴 감지 중 예외 발생: ${e.message}"
            )
        }
    }

    override fun validatePose(
        face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue? {
        val pose = (face as AlcheraDetectedFace).originFace.pose

        val failReason = when {
            abs(pose.roll_degree) >= ROLL_DEGREE -> CaptureGuide.INVALID_POSE_ROLL
            abs(pose.pitch_degree) >= PITCH_DEGREE -> CaptureGuide.INVALID_POSE_PITCH // (참고: pitch도 abs() 씌우는 것이 안전합니다)
            abs(pose.yaw_degree) >= YAW_DEGREE -> CaptureGuide.INVALID_POSE_YAW
            else -> null
        }

        return if (failReason != null)
            FaceExtractResult.Continue(failReason)
        else null
    }

    override fun validatePosition(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace
        val box = nativeFace.box

        val imageW = nativeImage.width
        val imageH = nativeImage.height
        val faceCenterX = box.x + box.width / 2
        val faceCenterY = box.y + box.height / 2
        val imageCenterX = imageW / 2
        val imageCenterY = imageH / 2
        val diffX = abs(imageCenterX - faceCenterX)
        val diffY = abs(imageCenterY - faceCenterY)
        val limitX = imageW / VALID_FACE_WIDTH_POSITION_RATE
        val limitY = imageH / VALID_FACE_HEIGHT_POSITION_RATE

        val result = diffX < limitX && diffY < limitY
        return if (!result)
            FaceExtractResult.Continue(CaptureGuide.INVALID_POSITION)
        else null

    }

    override fun validateSizeMin(
        inputImage: FaceEngineTypes.FaceImageFrame, face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue? {
        val imageW = (inputImage as AlcheraImageFrame).originImage.width
        val faceW = (face as AlcheraDetectedFace).originFace.box.width
        val minSize = imageW / VALID_FACE_SIZE_MIN_RATE_ORIENTATION_PORTRAIT

        return if (minSize >= faceW) {
            FaceExtractResult.Continue(CaptureGuide.FACE_TOO_SMALL)
        } else null
    }

    override fun validateSizeMax(
        inputImage: FaceEngineTypes.FaceImageFrame, face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue? {
        val imageW = (inputImage as AlcheraImageFrame).originImage.width
        val faceW = (face as AlcheraDetectedFace).originFace.box.width
        val maxSize = imageW / VALID_FACE_SIZE_MAX_RATE_ORIENTATION_PORTRAIT

        return if (maxSize <= faceW) {
            FaceExtractResult.Continue(CaptureGuide.FACE_TOO_BIG)
        } else null
    }

    override fun validateLandmarkConfidence(
        inputImage: FaceEngineTypes.FaceImageFrame, face: FaceEngineTypes.DetectedFace
    ): FaceExtractResult.Continue? {
        val nativeImage = (inputImage as AlcheraImageFrame).originImage
        val nativeFace = (face as AlcheraDetectedFace).originFace

        val confidence = capability.computeLandmarkConfidence(nativeImage, nativeFace)

        return if (confidence.confidence < VALID_FACE_DETECT_CONFIDENCE_VALUE) {
            FaceExtractResult.Continue(CaptureGuide.LOW_CONFIDENCE)
        } else null
    }
}
