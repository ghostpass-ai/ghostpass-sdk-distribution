package com.ghostpasssdk.gopasssdk.data.dto.firebase

import kotlinx.serialization.Serializable

@Serializable
internal data class FirebaseSseWrapperDto(
    val path: String,
    val data: KioskToUserPayloadDto? = null
)
