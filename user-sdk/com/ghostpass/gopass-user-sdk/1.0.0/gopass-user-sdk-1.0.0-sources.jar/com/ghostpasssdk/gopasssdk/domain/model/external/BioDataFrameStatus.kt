package com.ghostpasssdk.gopasssdk.domain.model.external

import androidx.annotation.Keep

@Keep
sealed interface BioDataFrameStatus {
    @Keep // 진행 계속
    data class ContinueCapture(val reason: CaptureGuide) : BioDataFrameStatus

    @Keep // 최종 성공
    object Success : BioDataFrameStatus
}