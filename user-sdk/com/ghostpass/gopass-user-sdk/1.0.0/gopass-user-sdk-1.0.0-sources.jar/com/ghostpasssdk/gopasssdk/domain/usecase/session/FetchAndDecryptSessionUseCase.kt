package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.data.repository.mapper.ApiEndpoint
import com.ghostpasssdk.gopasssdk.data.repository.mapper.getOrThrow
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionParams
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository

internal class FetchAndDecryptSessionUseCase(
    private val sessionRepository: SessionRepository,
    private val decryptSessionUseCase: DecryptSessionUseCase
) {
    suspend fun execute(major: Int, minor: Int, rssi: Int): DecryptedSession {
        val params = SessionParams(major = major, minor = minor, rssi = rssi)
        val encrypted = sessionRepository.sessions(params).getOrThrow(ApiEndpoint.SESSION)
        return decryptSessionUseCase.execute(encrypted)
    }
}