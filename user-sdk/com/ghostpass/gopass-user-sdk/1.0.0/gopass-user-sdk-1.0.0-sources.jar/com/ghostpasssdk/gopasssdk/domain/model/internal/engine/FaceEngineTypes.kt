package com.ghostpasssdk.gopasssdk.domain.model.internal.engine

internal interface FaceEngineTypes {
    interface FaceImageFrame
    interface DetectedFace
}