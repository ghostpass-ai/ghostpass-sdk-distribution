package com.ghostpasssdk.gopasssdk.data.dto.token

import kotlinx.serialization.Serializable

@Serializable
internal data class PushTokenRequest(
    val pushToken: String
)
