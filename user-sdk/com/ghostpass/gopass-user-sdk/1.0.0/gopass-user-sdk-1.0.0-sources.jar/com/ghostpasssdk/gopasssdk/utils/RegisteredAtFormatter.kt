package com.ghostpasssdk.gopasssdk.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val REGISTERED_AT_PATTERN = "yyyy.MM.dd"

internal fun formatRegisteredAt(timestamp: Long): String {
    return SimpleDateFormat(REGISTERED_AT_PATTERN, Locale.KOREA).format(Date(timestamp))
}
