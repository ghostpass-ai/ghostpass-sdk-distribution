package com.ghostpasssdk.gopasssdk.domain.model.internal.provision


internal data class Challenge(
    val challenge: String,
    val expiresIn: Long
)
