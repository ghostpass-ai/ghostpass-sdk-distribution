package com.ghostpasssdk.gopasssdk.domain.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult

internal interface TokenRepository {
    suspend fun updateToken(token: String): ApiResult<Unit>
}