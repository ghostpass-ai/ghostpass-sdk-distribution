package com.ghostpasssdk.gopasssdk.domain.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionParams

internal interface SessionRepository {
    suspend fun sessions(params: SessionParams): ApiResult<EncryptedSession>
}