package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.UserToKioskPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import kotlinx.serialization.json.Json.Default.encodeToString
import retrofit2.http.POST
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

internal class UpdateSessionResultUseCase(
    private val realtimeSessionRepository: RealtimeSessionRepository,
    private val cryptoEngine: CryptoEngine,
    private val identityRepository: IdentityRepository
) {
    companion object {
        private const val TAG = "UpdateSessionUseCase TAG"
        private const val STATUS_SUCCESS = "SUCCESS"
        private const val STATUS_FAIL = "FAIL"
        private const val TYPE = "AUTH_RESULT"
    }

    private val sessionSequences = ConcurrentHashMap<String, AtomicInteger>()

    suspend fun execute(session: DecryptedSession, idToken: String, isSuccess: Boolean): Boolean {
        return try {
            val finalStatus = if (isSuccess) STATUS_SUCCESS else STATUS_FAIL

            val deviceId = identityRepository.getDeviceId()

            if(deviceId.isNullOrBlank()){
                errorLog(TAG, "deviceID 누락")
                return false
            }

            val payloadMap = mapOf(
                "type" to TYPE,
                "result" to finalStatus,
                "deviceId" to deviceId
            )

            val plaintext = encodeToString(payloadMap)

            val seq = nextSequence(session.sessionId)
            val aadString = "${session.sessionId}:$seq:u2k"
            val aadBytes = aadString.toByteArray(Charsets.UTF_8)

            val encryptedData = cryptoEngine.encrypt(
                plainText = plaintext,
                aad = aadBytes,
                key = session.dkUser
            )

            val updatePayload = UserToKioskPayload(
                payload = encryptedData,
                seq = seq
            )

            val result = realtimeSessionRepository.updateSession(
                path = session.rtdbPath,
                authToken = idToken,
                data = updatePayload
            )

            if (result.isSuccess) {
                debugLog(TAG, "✅ [서버 전송 성공]")
                true
            } else {
                errorLog(TAG, "❌ [서버 전송 실패] 에러: ${result.exceptionOrNull()?.message}")
                false
            }

        } catch (e: Exception) {
            errorLog(TAG, "🚨 암호화 또는 전송 중 치명적 에러: ${e.message}")
            false
        }
    }

    fun clearSessionState(sessionId: String) {
        sessionSequences.remove(sessionId)
    }

    private fun nextSequence(sessionId: String): Int {
        val counter = sessionSequences.computeIfAbsent(sessionId) { AtomicInteger(0) }
        return counter.incrementAndGet()
    }
}
