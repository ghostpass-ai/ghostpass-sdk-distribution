package com.ghostpasssdk.gopasssdk.domain.repository.integrity

internal interface IntegrityTokenProvider {
    suspend fun fetchIntegrityToken(hash: String): String
}