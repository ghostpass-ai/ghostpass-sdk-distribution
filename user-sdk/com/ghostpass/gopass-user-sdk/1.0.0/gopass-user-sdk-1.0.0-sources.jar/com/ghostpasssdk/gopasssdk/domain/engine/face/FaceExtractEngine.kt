package com.ghostpasssdk.gopasssdk.domain.engine.face

import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceEngineTypes

internal interface FaceExtractEngine {
    suspend fun extractLandmarkVector(
        inputImage: FaceEngineTypes.FaceImageFrame,
        face: FaceEngineTypes.DetectedFace
    ): FloatArray
}