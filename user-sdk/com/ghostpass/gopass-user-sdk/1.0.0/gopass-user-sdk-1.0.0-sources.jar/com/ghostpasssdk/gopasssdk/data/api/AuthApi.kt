package com.ghostpasssdk.gopasssdk.data.api

import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.HEADER_SKIP_SIGNATURE
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.HEADER_SIGNED_CONTEXT
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.SIGNED_CONTEXT_CONFIG
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.SIGNED_CONTEXT_CONFIRM
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResponse
import com.ghostpasssdk.gopasssdk.data.dto.challenge.ChallengeDto
import com.ghostpasssdk.gopasssdk.data.dto.config.ConfigDto
import com.ghostpasssdk.gopasssdk.data.dto.confirm.ConfirmDto
import com.ghostpasssdk.gopasssdk.data.dto.confirm.ConfirmRequest
import com.ghostpasssdk.gopasssdk.data.dto.provision.ProvisionDto
import com.ghostpasssdk.gopasssdk.data.dto.provision.ProvisionRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

internal interface AuthApi {
    companion object {
        private const val PREFIX = "api/v1/sdk"
    }

    @Headers("${HEADER_SKIP_SIGNATURE}: true")
    @GET("$PREFIX/attestation/challenge")
    suspend fun requestChallenge(): Response<ApiResponse<ChallengeDto>>

    @Headers("${HEADER_SKIP_SIGNATURE}: true")
    @POST("$PREFIX/provision")
    suspend fun requestProvision(@Body body: ProvisionRequest): Response<ApiResponse<ProvisionDto>>

    @Headers("${HEADER_SIGNED_CONTEXT}: ${SIGNED_CONTEXT_CONFIRM}")
    @POST("$PREFIX/identity/confirm")
    suspend fun requestConfirm(@Body body: ConfirmRequest): Response<ApiResponse<ConfirmDto>>

    @Headers("${HEADER_SIGNED_CONTEXT}: ${SIGNED_CONTEXT_CONFIG}")
    @GET("$PREFIX/config")
    suspend fun requestConfig(): Response<ApiResponse<ConfigDto>>
}
