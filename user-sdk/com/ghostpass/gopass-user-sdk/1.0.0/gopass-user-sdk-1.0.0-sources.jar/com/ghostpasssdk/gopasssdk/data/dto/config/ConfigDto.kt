package com.ghostpasssdk.gopasssdk.data.dto.config

import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Config
import kotlinx.serialization.Serializable

@Serializable
internal data class ConfigDto(
    val beaconUuid: String,
    val rtdbBasePath: String,
    val minSdkVersion: String
){
    fun toDomain(): Config = Config(
        beaconUuid = this.beaconUuid,
        rtdbBasePath = this.rtdbBasePath,
        minSdkVersion = this.minSdkVersion
    )
}