package com.ghostpasssdk.gopasssdk.internal.manager

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconServiceEventBus
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.CompareFacesUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.FetchAndDecryptSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.ProcessSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.UpdateSessionResultUseCase
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.useAndWipe
import com.ghostpasssdk.gopasssdk.utils.verboseLog
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import javax.security.auth.Destroyable

internal class ProximityObserver(
    private val fetchAndDecryptSessionUseCase: FetchAndDecryptSessionUseCase,
    private val processSessionUseCase: ProcessSessionUseCase,
    private val compareFacesUseCase: CompareFacesUseCase,
    private val updateSessionResultUseCase: UpdateSessionResultUseCase
) {
    companion object {
        private const val TAG = "ProximityObserver TAG"
        private const val TARGET_HIT_COUNT = 3 // 목표 감지 횟수
        private const val SESSION_TIMEOUT_MILLIS = 60 * 1000L // 1분
        private val COOLDOWN_MILLIS = if (BuildConfig.DEBUG) 60 * 1000L else 5 * 60 * 1000L
    }

    private val lifecycleScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val isLifecycleInitialized = AtomicBoolean(false)
    private val isListening = AtomicBoolean(false)

    fun initializeLifecycle() {
        if (!isLifecycleInitialized.compareAndSet(false, true)) {
            debugLog(TAG, "Lifecycle collector already initialized")
            return
        }

        lifecycleScope.launch {
            launch {
                BeaconServiceEventBus.regionEntered.collect {
                    debugLog(TAG, "📡 리전 진입 감지 -> 옵저버 Listening 시작")
                    startListening()
                }
            }

            launch {
                BeaconServiceEventBus.regionExited.collect {
                    debugLog(TAG, "⏸️ 리전 이탈 감지 -> 옵저버 Listening 일시 정지")
                    stopListening()
                }
            }

            launch {
                BeaconServiceEventBus.scanStopped.collect {
                    debugLog(TAG, "⏸️ 비콘 스캔 중단 감지 -> 옵저버 Listening 일시 정지")
                    stopListening()
                }
            }
            launch {
                BeaconServiceEventBus.serviceDestroyed.collect {
                    debugLog(TAG, "🛑 서비스 완전 종료 감지 -> 진행 중 세션 정리 및 Listening 중단")
                    handleServiceDestroyed()
                }
            }
        }
    }
    private val observerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // 비콘 신호 수집만 전담할 코루틴 Job
    private var collectorJob: Job? = null

    // 비콘 기기별 감지 누적 횟수
    private val hitCounts = ConcurrentHashMap<String, Int>()

    // 비콘 기기별 "세션 획득 ~ RTDB 인증 대기" 전체 과정을 담은 Job
    private val activeSessionJobs = ConcurrentHashMap<String, Job>()
    private val cooldownMap = ConcurrentHashMap<String, Long>()

    fun startListening() {
        if (!isListening.compareAndSet(false, true)) return

        collectorJob = observerScope.launch {
            BeaconServiceEventBus.beaconDetected.collect { event ->
                val beaconKey = "${event.major}_${event.minor}"

                val lastFinishedTime = cooldownMap[beaconKey]
                if (lastFinishedTime != null) {
                    if (System.currentTimeMillis() - lastFinishedTime < COOLDOWN_MILLIS) {
                        return@collect
                    } else {
                        cooldownMap.remove(beaconKey)
                    }
                }

                if (activeSessionJobs.containsKey(beaconKey)) return@collect

                val currentCount = hitCounts.merge(beaconKey, 1) { oldVal, _ -> oldVal + 1 } ?: 1
                debugLog(TAG, "비콘 감지 누적: Key=$beaconKey, 카운트=$currentCount/$TARGET_HIT_COUNT")

                if (currentCount >= TARGET_HIT_COUNT) {
                    hitCounts.remove(beaconKey)
                    handleSessionLifecycle(beaconKey, event.major, event.minor, event.rssi)
                }
            }
        }
    }

    /**
     * FCM으로 전달받은 세션을 비콘 감지 없이 직접 세션 라이프사이클에 주입한다.
     * 복호화는 caller(InfrastructureManager)에서 완료된 상태로 전달받는다.
     * RTDB 관찰 → 얼굴 비교 → 결과 전송 흐름은 비콘 경로와 동일.
     */
    fun delegateSession(decrypted: DecryptedSession) {
        val sessionKey = "fcm_${decrypted.sessionId}"

        val existingJob = activeSessionJobs.putIfAbsent(sessionKey, Job())
        if (existingJob != null) {
            debugLog(TAG, "이미 진행 중인 세션: $sessionKey — 중복 세션 키 파기")
            decrypted.destroySecurely()
            return
        }

        val job = observerScope.launch {
            try {
                debugLog(TAG, "📩 FCM 세션 관찰 시작 (${decrypted.sessionId})")
                runSessionObservation(sessionKey, decrypted)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                errorLog(TAG, "FCM 세션 처리 중 에러: ${e.message}")
            } finally {
                activeSessionJobs.remove(sessionKey)
                debugLog(TAG, "🧹 FCM 세션 자원 정리 완료 ($sessionKey)")
            }
        }

        activeSessionJobs[sessionKey] = job

        // scope 취소 등으로 코루틴이 즉시 취소된 경우 body 미실행 → destroySecurely 수동 호출
        if (job.isCancelled) {
            decrypted.destroySecurely()
            activeSessionJobs.remove(sessionKey)
        }
    }

    private fun handleSessionLifecycle(beaconKey: String, major: Int, minor: Int, rssi: Int) {
        lateinit var sessionJob: Job
        sessionJob = observerScope.launch(start = CoroutineStart.LAZY) {
            try {
                verboseLog(TAG, "🎯 3회 감지 완료! 세션 API 호출 시작 ($beaconKey)")
                val sessionResponse = fetchAndDecryptSessionUseCase.execute(major, minor, rssi)

                debugLog(TAG, "✅ 세션 획득 및 복호화 완료! RTDB 인증 대기 시작 (최대 1분)")
                runSessionObservation(beaconKey, sessionResponse)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                errorLog(TAG, "세션 통신 또는 RTDB 처리 중 에러: ${e.message}")
            } finally {
                activeSessionJobs.remove(beaconKey, sessionJob)
                hitCounts.remove(beaconKey)
                debugLog(TAG, "🧹 세션 자원 로컬 정리 완료. 다시 비콘 신호 수신 대기 ($beaconKey)")
            }
        }

        val existingJob = activeSessionJobs.putIfAbsent(beaconKey, sessionJob)
        if (existingJob != null) {
            sessionJob.cancel()
            return
        }

        sessionJob.start()
    }

    /**
     * 비콘/FCM 양쪽에서 공유하는 세션 관찰 공통 로직.
     * DecryptedSession을 받아 RTDB 인증 → SSE 관찰 → 얼굴 비교 → 결과 전송을 수행한다.
     */
    private suspend fun runSessionObservation(
        sessionKey: String,
        session: DecryptedSession
    ) {
        try {
            val (facePayloadFlow, idToken) = processSessionUseCase.execute(session)

            val timedOut = withTimeoutOrNull(SESSION_TIMEOUT_MILLIS) {
                facePayloadFlow.first { facePayload ->
                    debugLog(
                        TAG,
                        "📦 payload 수신. 벡터 크기=${facePayload.vector.size}, ts=${facePayload.timestamp}"
                    )

                    val compareResult = facePayload.vector.useAndWipe { vector ->
                        compareFacesUseCase.execute(vector)
                    }.also {
                        debugLog(TAG, "🛡️ [보안] 메모리 내 수신된 생체 벡터 데이터 영구 소각 완료")
                    }

                    val isUpdateSuccess = updateSessionResultUseCase.execute(
                        session = session,
                        idToken = idToken,
                        isSuccess = compareResult
                    )
                    debugLog(TAG, "키오스크 인증 연산: $compareResult, 결과 전송 통신: $isUpdateSuccess")

                    if (compareResult && isUpdateSuccess) {
                        cooldownMap[sessionKey] = System.currentTimeMillis()
                        debugLog(TAG, "⏱️ [최종 성공] 세션 종료 ($sessionKey)")
                        true
                    } else {
                        debugLog(TAG, "🔄 [인증 실패 OR 서버 전송 실패] 세션 유지. timeout까지 다음 payload 대기")
                        false
                    }
                }
                true
            } == null

            if (timedOut) {
                debugLog(TAG, "⏰ 1분 만료! 세션 자연 종료 ($sessionKey)")
            }
        } finally {
            updateSessionResultUseCase.clearSessionState(session.sessionId)
            session.destroySecurely()
        }
    }

    fun stopListening() {
        if (!isListening.compareAndSet(true, false)) return

        collectorJob?.cancel()
        collectorJob = null

        hitCounts.clear()

        debugLog(TAG, "옵저버 완전 종료")
    }

    private fun handleServiceDestroyed() {
        stopListening()
        observerScope.coroutineContext.cancelChildren()
        activeSessionJobs.clear()
        hitCounts.clear()
        cooldownMap.clear()
        debugLog(TAG, "🧹 서비스 종료에 따른 세션/쿨다운 자원 정리 완료")
    }

    fun destroy() {
        stopListening()
        lifecycleScope.cancel()
        observerScope.cancel()
        activeSessionJobs.clear()
        cooldownMap.clear()
        debugLog(TAG, "🛑 옵저버 자원 완전 파기 완료")
    }

    fun destroySessionSecurely(session: DecryptedSession) {
        session.destroySecurely()
    }

    private fun DecryptedSession.destroySecurely() {
        runCatching {
            val destroyableKey = dkUser as? Destroyable
            if (destroyableKey?.isDestroyed == false) {
                destroyableKey.destroy()
                debugLog(TAG, "세션 [$sessionId] dkUser 메모리 안전 파기 완료")
            }
        }.onFailure { e ->
            errorLog(TAG, "세션 [$sessionId] dkUser 파기 실패: ${e.message}")
        }
    }
}
