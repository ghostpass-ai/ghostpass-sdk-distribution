package com.ghostpasssdk.gopasssdk.domain.model.internal.provision

internal data class Config(
    val beaconUuid: String,
    val rtdbBasePath: String,
    val minSdkVersion: String
)
