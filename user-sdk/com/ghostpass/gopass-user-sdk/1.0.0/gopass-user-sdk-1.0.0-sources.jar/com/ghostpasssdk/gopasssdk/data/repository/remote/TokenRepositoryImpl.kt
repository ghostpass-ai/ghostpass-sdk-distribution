package com.ghostpasssdk.gopasssdk.data.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.infra.SignedRequestPreflightChecker
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.core.network.utils.safeApiCallNoData
import com.ghostpasssdk.gopasssdk.data.api.TokenApi
import com.ghostpasssdk.gopasssdk.data.dto.token.PushTokenRequest
import com.ghostpasssdk.gopasssdk.domain.repository.remote.TokenRepository

internal class TokenRepositoryImpl(
    private val tokenApi: TokenApi,
    private val signedRequestPreflightChecker: SignedRequestPreflightChecker
) : TokenRepository {

    override suspend fun updateToken(token: String): ApiResult<Unit> {
        signedRequestPreflightChecker.ensurePushTokenReady()
        return safeApiCallNoData {
            tokenApi.requestPushTokenUpdate(PushTokenRequest(pushToken = token))
        }
    }
}
