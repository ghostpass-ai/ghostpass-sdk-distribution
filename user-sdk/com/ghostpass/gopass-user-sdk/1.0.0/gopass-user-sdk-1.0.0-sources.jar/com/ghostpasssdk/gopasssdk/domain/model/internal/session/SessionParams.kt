package com.ghostpasssdk.gopasssdk.domain.model.internal.session

internal data class SessionParams(
    val major: Int,
    val minor: Int,
    val rssi: Int
)