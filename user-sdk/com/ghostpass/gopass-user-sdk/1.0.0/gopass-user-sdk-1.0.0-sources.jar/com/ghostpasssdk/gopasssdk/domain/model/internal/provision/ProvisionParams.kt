package com.ghostpasssdk.gopasssdk.domain.model.internal.provision

internal data class ProvisionParams(
    val challenge: String,
    val attestation: String,
    val platform: String,
    val platformId: String,
    val installId: String,
    val osVersion: String,
    val appVersion: String,
    val sdkVersion: String,
    val clientPublicKey: String
)
