package com.ghostpasssdk.gopasssdk.utils

import java.util.Arrays

internal fun ByteArray?.wipe() {
    if (this == null) return
    Arrays.fill(this, 0)
}

internal inline fun <R> ByteArray.useAndWipe(block: (ByteArray) -> R): R {
    return try {
        block(this)
    } finally {
        wipe()
    }
}

internal fun FloatArray?.wipe(){
    if(this == null) return
    Arrays.fill(this, 0f)
}

internal inline fun <R> FloatArray.useAndWipe(block: (FloatArray) -> R): R {
    return try {
        block(this)
    } finally {
        wipe()
    }
}
