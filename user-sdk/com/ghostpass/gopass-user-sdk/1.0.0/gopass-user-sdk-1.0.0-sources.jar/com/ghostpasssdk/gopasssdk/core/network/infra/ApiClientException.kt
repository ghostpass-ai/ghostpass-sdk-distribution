package com.ghostpasssdk.gopasssdk.core.network.infra

import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import java.io.IOException

internal class ApiClientException(
    val goPassException: GoPassException
) : IOException(goPassException.message)
