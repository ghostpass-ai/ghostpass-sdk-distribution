package com.ghostpasssdk.gopasssdk.data.dto.confirm

import kotlinx.serialization.Serializable

@Serializable
internal data class ConfirmRequest(
    val identityId: String,
    val deviceId: String
)