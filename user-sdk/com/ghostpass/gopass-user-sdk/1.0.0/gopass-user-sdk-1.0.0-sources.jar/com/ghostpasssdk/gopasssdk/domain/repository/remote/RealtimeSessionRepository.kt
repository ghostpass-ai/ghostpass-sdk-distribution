package com.ghostpasssdk.gopasssdk.domain.repository.remote

import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.AuthToken
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.KioskToUserPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.UserToKioskPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.landmark.FaceVectorPayload
import kotlinx.coroutines.flow.Flow
import java.security.Key

internal interface RealtimeSessionRepository {

    /**
     * 1. 실시간 서버(RTDB 등) 통신을 위한 인증 토큰 획득
     * @param customToken 서버에서 발급받은 커스텀 토큰
     */
    suspend fun authenticate(customToken: String): AuthToken

    /**
     * 2. 특정 세션 경로의 상태 변화를 실시간 관찰 (REST의 SSE 방식 활용)
     * @param path 관찰할 서버 경로
     * @param authToken authenticate()에서 획득한 토큰
     * @return 상태값(String)의 지속적인 스트림. (ex: "PENDING" -> "SUCCESS")
     * ※ Flow 자체는 비동기 스트림이므로 suspend 필요 X
     */
    fun observeKioskPayload(path: String, authToken: String): Flow<KioskToUserPayload>

    /**
     * 3. 특정 세션 경로에 상태(결과) 업데이트
     * @param path 업데이트할 서버 경로
     * @param authToken 인증 토큰
     * @param data 업데이트할 Key-Value 데이터 (ex: {"status": "SUCCESS", "errorCode": null})
     */
    suspend fun updateSession(path: String, authToken: String, data: UserToKioskPayload): Result<Unit>

    fun observeAndDecryptFacePayload(
        rtdbPath: String,
        idToken: String,
        sessionId: String,
        dkUser: Key
    ): Flow<FaceVectorPayload>
}