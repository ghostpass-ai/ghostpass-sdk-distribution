package com.ghostpasssdk.gopasssdk.domain.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Challenge
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Config
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Confirm
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ConfirmParams
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Provision
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ProvisionParams

internal interface AuthRepository {
    suspend fun challenge(): ApiResult<Challenge>

    suspend fun provision(params: ProvisionParams): ApiResult<Provision>

    suspend fun confirm(params: ConfirmParams): ApiResult<Confirm>

    suspend fun config(): ApiResult<Config>
}