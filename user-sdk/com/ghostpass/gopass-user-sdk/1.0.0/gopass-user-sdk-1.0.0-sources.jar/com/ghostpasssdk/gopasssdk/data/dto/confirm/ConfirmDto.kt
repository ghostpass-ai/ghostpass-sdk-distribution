package com.ghostpasssdk.gopasssdk.data.dto.confirm

import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Confirm
import kotlinx.serialization.Serializable

@Serializable
internal data class ConfirmDto(
    val confirmed: Boolean,
    val message: String
){
    fun toDomain(): Confirm = Confirm(
        confirmed = this.confirmed,
        message = this.message
    )
}