package com.ghostpasssdk.gopasssdk.data.repository.mapper

import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode

internal enum class ApiEndpoint(
    val requestFailed: InternalErrorCode,
    val responseInvalid: InternalErrorCode,
    val serverError: InternalErrorCode,
    val decodingFailed: InternalErrorCode,
) {
    CHALLENGE(
        requestFailed = InternalErrorCode.CHALLENGE_REQUEST_FAILED,
        responseInvalid = InternalErrorCode.CHALLENGE_RESPONSE_INVALID,
        serverError = InternalErrorCode.CHALLENGE_SERVER_ERROR,
        decodingFailed = InternalErrorCode.CHALLENGE_DECODING_FAILED,
    ),
    PROVISION(
        requestFailed = InternalErrorCode.PROVISION_REQUEST_FAILED,
        responseInvalid = InternalErrorCode.PROVISION_RESPONSE_INVALID,
        serverError = InternalErrorCode.PROVISION_SERVER_ERROR,
        decodingFailed = InternalErrorCode.PROVISION_DECODING_FAILED,
    ),
    CONFIRM(
        requestFailed = InternalErrorCode.CONFIRM_REQUEST_FAILED,
        responseInvalid = InternalErrorCode.CONFIRM_RESPONSE_INVALID,
        serverError = InternalErrorCode.CONFIRM_SERVER_ERROR,
        decodingFailed = InternalErrorCode.CONFIRM_DECODING_FAILED,
    ),
    CONFIG(
        requestFailed = InternalErrorCode.CONFIG_REQUEST_FAILED,
        responseInvalid = InternalErrorCode.CONFIG_RESPONSE_INVALID,
        serverError = InternalErrorCode.CONFIG_SERVER_ERROR,
        decodingFailed = InternalErrorCode.CONFIG_DECODING_FAILED,
    ),
    SESSION(
        requestFailed = InternalErrorCode.SESSION_REQUEST_FAILED,
        responseInvalid = InternalErrorCode.SESSION_RESPONSE_INVALID,
        serverError = InternalErrorCode.SESSION_SERVER_ERROR,
        decodingFailed = InternalErrorCode.SESSION_DECODING_FAILED,
    ),
    PUSH_TOKEN(
        requestFailed = InternalErrorCode.PUSH_TOKEN_REQUEST_FAILED,
        responseInvalid = InternalErrorCode.PUSH_TOKEN_RESPONSE_INVALID,
        serverError = InternalErrorCode.PUSH_TOKEN_SERVER_ERROR,
        decodingFailed = InternalErrorCode.PUSH_TOKEN_DECODING_FAILED,
    )
}
