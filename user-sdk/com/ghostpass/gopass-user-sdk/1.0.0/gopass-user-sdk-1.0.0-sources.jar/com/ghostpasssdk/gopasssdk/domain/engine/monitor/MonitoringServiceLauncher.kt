package com.ghostpasssdk.gopasssdk.domain.engine.monitor

internal interface MonitoringServiceLauncher {
    val isServiceRunning: Boolean
    fun launchService()
    fun stopService()
}
