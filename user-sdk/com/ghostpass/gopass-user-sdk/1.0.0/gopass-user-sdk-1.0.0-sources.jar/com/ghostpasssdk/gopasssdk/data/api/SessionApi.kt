package com.ghostpasssdk.gopasssdk.data.api

import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.HEADER_SIGNED_CONTEXT
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.SIGNED_CONTEXT_SESSION
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResponse
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionDto
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

internal interface SessionApi {
    companion object {
        private const val PREFIX = "api/v1"
    }

    @Headers("${HEADER_SIGNED_CONTEXT}: ${SIGNED_CONTEXT_SESSION}")
    @POST("${PREFIX}/sessions")
    suspend fun requestSession(@Body body: SessionRequest): Response<ApiResponse<SessionDto>>
}
