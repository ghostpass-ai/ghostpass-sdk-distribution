package com.ghostpasssdk.gopasssdk.domain.repository.storage

internal interface IdentityRepository {
    fun saveApiKey(apiKey: String)
    fun saveBeaconUuid(beaconUuid: String)
    fun saveInstallId(installId: String)
    fun saveDeviceId(deviceId: String)
    fun saveIdentityId(identityId: String)
    fun saveRegisteredAt(registeredAt: Long)
    fun getApiKey(): String?
    fun getBeaconUuid(): String?
    fun getInstallId(): String?
    fun getDeviceId(): String?
    fun getIdentityId(): String?
    fun getRegisteredAt(): Long?
    fun clearRegisteredAt()
    fun clearIdentity()
}
