package com.ghostpasssdk.gopasssdk.domain.usecase.landmark

import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceDetectionEngine
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceExtractEngine
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceLivenessEngine
import com.ghostpasssdk.gopasssdk.domain.model.external.CaptureGuide
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.FaceExtractResult
import com.ghostpasssdk.gopasssdk.domain.model.internal.engine.LivenessResult
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.infoLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

internal class FaceRegisterUseCase(
    private val detectionEngine: FaceDetectionEngine,
    private val livenessEngine: FaceLivenessEngine,
    private val extractEngine: FaceExtractEngine
) {
    companion object {
        private const val TAG = "FaceRegisterUseCase TAG"
    }
    @Volatile private var isCompleted = false
    private val mutex = Mutex()

    suspend fun execute(
        faceImage: ByteArray,
        width: Int,
        height: Int,
        rotation: Int
    ): FaceExtractResult = withContext(Dispatchers.Default){
        warnLog(TAG, "PrepareFaceAuthUseCase 호출")
        mutex.withLock {
            try {
                if (isCompleted) {
                    return@withLock FaceExtractResult.Continue(CaptureGuide.ALREADY_COMPLETED)
                }

                if (faceImage.isEmpty()) {
                    throw GoPassException.from(
                        error = ErrorCode.INVALID_IMAGE_BYTES
                    )
                }

                detectionEngine.checkMemory(width, height)

                val inputImage =
                    detectionEngine.createInputImage(faceImage, width, height, rotation)

                // 3) 얼굴 검출
                val face = detectionEngine.detectFirstFace(inputImage)
                    ?: return@withLock FaceExtractResult.Continue(CaptureGuide.NO_FACE_DETECTED)

                // 4) pose/position/size 체크
                detectionEngine.validatePose(face)?.let {
                    return@withLock FaceExtractResult.Continue(it.reason)
                }
                detectionEngine.validatePosition(inputImage, face)?.let {
                    return@withLock FaceExtractResult.Continue(it.reason)
                }
                detectionEngine.validateSizeMin(inputImage, face)?.let {
                    return@withLock FaceExtractResult.Continue(it.reason)
                }
                detectionEngine.validateSizeMax(inputImage, face)?.let {
                    return@withLock FaceExtractResult.Continue(it.reason)
                }

                when (livenessEngine.evaluate(inputImage, face)) {
                    LivenessResult.Collecting -> {
                        return@withLock FaceExtractResult.Continue(CaptureGuide.COLLECTING_FRAMES)
                    }
                    LivenessResult.NotConfirmed -> {
                        return@withLock FaceExtractResult.Continue(CaptureGuide.LIVENESS_NOT_CONFIRMED)
                    }
                    LivenessResult.TxFailed -> {
                        throw GoPassException.from(
                            error = ErrorCode.LIVENESS_NOT_SATISFIED
                        )
                    }
                    LivenessResult.Passed -> { /* 통과, 다음으로 진행 */ }
                }

                // 9. 랜드마크 신뢰도
                detectionEngine.validateLandmarkConfidence(inputImage, face)?.let {
                    return@withLock FaceExtractResult.Continue(it.reason)
                }

                // 10. 특징 추출
                val landmark = extractEngine.extractLandmarkVector(inputImage, face)
                isCompleted = true

                infoLog(TAG, "========== execute 성공! ==========")
                return@withContext FaceExtractResult.Success(landmark = landmark)

            } catch (e: GoPassException) {
                errorLog(TAG, "========== execute GoPassSdkException: $e ==========")
                throw e
            } catch (e: Exception) {
                errorLog(TAG, "========== execute 예외 발생: $e ==========")
                throw GoPassException.from(
                    error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                    customMessage = "얼굴 등록 처리 중 예외 발생: ${e.message}"
                )
            }
        }
    }

    fun resetCompletedState() {
        isCompleted = false
    }
}