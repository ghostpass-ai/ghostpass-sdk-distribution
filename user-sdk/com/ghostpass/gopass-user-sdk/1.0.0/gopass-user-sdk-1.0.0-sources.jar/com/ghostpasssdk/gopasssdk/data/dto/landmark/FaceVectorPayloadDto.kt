package com.ghostpasssdk.gopasssdk.data.dto.landmark

import com.ghostpasssdk.gopasssdk.domain.model.internal.landmark.FaceVectorPayload
import kotlinx.serialization.Serializable

@Serializable
internal data class FaceVectorPayloadDto(
    val type: String = "FACE_VECTOR",
    val vector: FloatArray,
    val timestamp: Long
) {
    fun toDomain(): FaceVectorPayload = FaceVectorPayload(
        type = this.type,
        vector = this.vector,
        timestamp = this.timestamp
    )

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as FaceVectorPayloadDto

        if (timestamp != other.timestamp) return false
        if (type != other.type) return false
        if (!vector.contentEquals(other.vector)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = timestamp.hashCode()
        result = 31 * result + type.hashCode()
        result = 31 * result + vector.contentHashCode()
        return result
    }

}