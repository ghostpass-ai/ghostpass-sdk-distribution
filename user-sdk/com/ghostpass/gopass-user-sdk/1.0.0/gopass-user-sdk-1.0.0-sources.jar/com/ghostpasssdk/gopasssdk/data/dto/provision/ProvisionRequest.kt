package com.ghostpasssdk.gopasssdk.data.dto.provision

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class ProvisionRequest(
    val challenge: String,
    @SerialName("attestationData")val attestation: String,
    val platform: String,
    val platformId: String,
    val installId: String,
    val osVersion: String,
    val appVersion: String,
    val sdkVersion: String,
    val clientPublicKey: String
)