package com.ghostpasssdk.gopasssdk.domain.model.external

import androidx.annotation.Keep

@Keep
data class InitResult(
    val deviceId: String,
    val hasBioData: Boolean,
    val registeredAt: String?
)
