package com.ghostpasssdk.gopasssdk.domain.usecase.provision

import android.content.Context
import android.provider.Settings.Secure.ANDROID_ID
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import java.util.UUID

internal class DeviceIdUseCase(
    private val cryptoEngine: CryptoEngine,
    private val identityRepository: IdentityRepository,
    private val context: Context
) {
    fun getOrCreate(): String {
        identityRepository.getDeviceId()?.let { return it }

        val platformId = "android"

        val installId = identityRepository.getInstallId() ?: run {
            val newId = UUID.randomUUID().toString()
            identityRepository.saveInstallId(newId)
            newId
        }
        val bundleId = context.packageName

        val deviceId = cryptoEngine.hashSha256("$platformId$installId$bundleId")
        identityRepository.saveDeviceId(deviceId)
        return deviceId
    }

    fun getPlatformId(): String = ANDROID_ID

    fun getInstallId(): String =
        identityRepository.getInstallId() ?: run {
            val newId = UUID.randomUUID().toString()
            identityRepository.saveInstallId(newId)
            newId
        }

    fun getBundleId(): String = context.packageName
}
