package com.ghostpasssdk.gopasssdk.core.network.utils

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResponse
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.utils.verboseLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.serialization.SerializationException
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

import retrofit2.Response

private val errorParserJson = Json {
    ignoreUnknownKeys = true
}

internal suspend fun <T,R> safeApiCall(
    call: suspend () -> Response<ApiResponse<T>>,
    mapper: (T) -> R
): ApiResult<R> {
    return try {
        val resp = call()
        val httpCode = resp.code()
        verboseLog("API 호출 TAG", "response : $resp")

        if (resp.isSuccessful) {
            val body = resp.body()
                ?: return ApiResult.Failure(httpCode, code = "EMPTY_BODY", message = "Empty response body")
            warnLog("API 호출 TAG", "success body : ${resp.body()}")
            return if (body.success) {
                body.data?.let { ApiResult.Success(mapper(it), body.message) }
                    ?: ApiResult.Failure(httpCode, code = body.code ?: "MISSING_DATA", message = body.message)
            } else {
                ApiResult.Failure(httpCode, code = body.code, message = body.message)
            }
        }

        parseErrorBody(resp.errorBody()?.string(), httpCode)
    } catch (t: Throwable) {
        ApiResult.NetworkError(t)
    }
}

/**
 * data 페이로드가 없는(또는 무시 가능한) 명령형 엔드포인트 전용 헬퍼.
 * success 플래그만으로 성공/실패를 판단하며, body.data == null 도 정상 응답으로 간주한다.
 */
internal suspend fun safeApiCallNoData(
    call: suspend () -> Response<ApiResponse<Unit>>
): ApiResult<Unit> {
    return try {
        val resp = call()
        val httpCode = resp.code()
        verboseLog("API 호출 TAG", "response : $resp")

        if (resp.isSuccessful) {
            val body = resp.body()
                ?: return ApiResult.Failure(httpCode, code = "EMPTY_BODY", message = "Empty response body")
            warnLog("API 호출 TAG", "success body : $body")
            return if (body.success) {
                ApiResult.Success(Unit, body.message)
            } else {
                ApiResult.Failure(httpCode, code = body.code, message = body.message)
            }
        }

        parseErrorBody(resp.errorBody()?.string(), httpCode)
    } catch (t: Throwable) {
        ApiResult.NetworkError(t)
    }
}

private fun parseErrorBody(raw: String?, httpCode: Int): ApiResult.Failure {
    if (raw.isNullOrBlank()) {
        return ApiResult.Failure(httpCode, message = "HTTP error with empty body")
    }
    return try {
        val err = errorParserJson.decodeFromString(
            ApiResponse.serializer(Unit.serializer()),
            raw
        )
        warnLog("API 호출 TAG", "error Body : $err")
        ApiResult.Failure(httpCode, code = err.code, message = err.message)
    } catch (se: SerializationException) {
        ApiResult.Failure(httpCode, code = "PARSE_ERROR", message = se.message)
    }
}