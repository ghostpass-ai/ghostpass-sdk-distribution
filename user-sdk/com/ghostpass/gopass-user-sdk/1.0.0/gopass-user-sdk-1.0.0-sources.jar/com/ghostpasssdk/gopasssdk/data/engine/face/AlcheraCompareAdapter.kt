package com.ghostpasssdk.gopasssdk.data.engine.face

import com.ghostpasssdk.gopasssdk.data.engine.face.capability.FaceFeatureCapability
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceCompareEngine

internal class AlcheraCompareAdapter(
    private val capability: FaceFeatureCapability
) : FaceCompareEngine {
    override suspend fun compare(
        sourceVector: FloatArray,
        targetVector: FloatArray
    ): Float {
        return capability.computeFeatures(
            sourceVector = sourceVector,
            targetVector = targetVector
        ).distance
    }
}