package com.ghostpasssdk.gopasssdk.data.engine.face.capability

import com.alcherainc.facesdk.type.AntispoofingExtension.BGRImageLiveness
import com.alcherainc.facesdk.type.Face
import com.alcherainc.facesdk.type.FeatureExtension.FaceQuality
import com.alcherainc.facesdk.type.InputImage

internal interface FaceLivenessCapability {
    fun checkLivenessFromBGRImage(
        i0: InputImage, i1: InputImage,
        i2: InputImage, i3: InputImage,
        face: Face
    ): BGRImageLiveness
    fun resetInputBGRLivenessChecker()
    fun estimateFaceQuality(
        image: InputImage,
        face: Face,
        returnFeature: Boolean
    ): FaceQuality
}