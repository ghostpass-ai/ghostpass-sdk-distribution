package com.ghostpasssdk.gopasssdk.data.engine.restart

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.errorLog
import java.util.concurrent.TimeUnit

/**
 * FGS 재시작 보조 경로. 주 경로는 PackageReplacedReceiver의 직접 시작이며,
 * 워커 실행 시점에는 백그라운드 FGS 시작 면제가 없으므로
 * 배터리 최적화 해제(면제) 기기에서만 성공할 수 있다.
 */
internal class ServiceRestartWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return when (ServiceRestartExecutor(context).execute()) {
            RestartExecutionResult.COMPLETED -> Result.success()
            RestartExecutionResult.PERMANENT_FAILURE -> {
                errorLog(TAG, "구조적 실패 — 재시도 중단 (attempt=$runAttemptCount)")
                Result.failure()
            }
            RestartExecutionResult.RETRYABLE_FAILURE ->
                if (runAttemptCount >= MAX_RETRY_COUNT) {
                    errorLog(TAG, "최대 재시도 횟수 초과 → 포기 (attempt=$runAttemptCount)")
                    Result.failure()
                } else {
                    Result.retry()
                }
        }
    }

    companion object {
        private val TAG = "ServiceRestartWorker ${BuildConfig.SIGNATURE}"
        private const val UNIQUE_WORK_NAME = "gopass-service-restart"
        internal const val MAX_RETRY_COUNT = 3

        fun enqueue(context: Context) {
            val request = OneTimeWorkRequestBuilder<ServiceRestartWorker>()
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniqueWork(UNIQUE_WORK_NAME, ExistingWorkPolicy.KEEP, request)
        }
    }
}
