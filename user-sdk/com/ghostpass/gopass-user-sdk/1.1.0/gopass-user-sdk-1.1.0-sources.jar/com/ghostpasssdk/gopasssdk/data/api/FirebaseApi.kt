package com.ghostpasssdk.gopasssdk.data.api

import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient.Companion.HEADER_SKIP_API_KEY
import com.ghostpasssdk.gopasssdk.data.dto.firebase.CustomTokenSignInDto
import com.ghostpasssdk.gopasssdk.data.dto.firebase.CustomTokenSignInRequest
import com.ghostpasssdk.gopasssdk.data.dto.firebase.UserToKioskPayloadDto
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Query
import retrofit2.http.Url

internal interface FirebaseApi {
    @Headers("${HEADER_SKIP_API_KEY}: true")
    @POST("https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken")
    suspend fun signInWithCustomToken(
        @Query("key") apiKey: String, // Firebase Web API Key
        @Body request: CustomTokenSignInRequest
    ): Response<CustomTokenSignInDto>

    @Headers("${HEADER_SKIP_API_KEY}: true")
    @PATCH
    suspend fun updateSessionState(
        @Url url: String,
        @Query("auth") auth: String,
        @Body data: UserToKioskPayloadDto,
        // 서버가 write된 데이터를 응답 body로 echo하지 않고 204 No Content로 응답 (전송량 절약)
        @Query("print") print: String = "silent"
    ): Response<Unit>

    @Headers("${HEADER_SKIP_API_KEY}: true")
    @PUT
    suspend fun updateLastSeenAt(
        @Url url: String,
        @Query("auth") auth: String,
        @Body body: RequestBody,
        @Query("print") print: String = "silent"
    ): Response<Unit>

    @Headers("${HEADER_SKIP_API_KEY}: true")
    @GET
    // RTDB는 빈 노드에 200 + body "null"을 반환하므로 DTO 직파싱 불가 → ResponseBody로 받아 호출부에서 판별
    suspend fun getKioskPayload(
        @Url url: String,
        @Query("auth") auth: String
    ): Response<ResponseBody>

    @Headers("${HEADER_SKIP_API_KEY}: true")
    @GET
    suspend fun getNode(
        @Url url: String,
        @Query("auth") auth: String,
        @Query("shallow") shallow: Boolean = true
    ): Response<ResponseBody>
}
