package com.ghostpasssdk.gopasssdk.data.engine.restart

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog

internal class PackageReplacedReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        // MY_PACKAGE_REPLACED 수신 컨텍스트가 백그라운드 FGS 시작 면제 조건이다.
        // WorkManager로 지연 위임하면 면제가 소멸해 API 31+에서
        // ForegroundServiceStartNotAllowedException이 나므로 onReceive 안에서 직접 시작한다.
        debugLog(TAG, "앱 업데이트 감지 → FGS 재시작 시도")
        val result = ServiceRestartExecutor(context).execute()
        if (result == RestartExecutionResult.RETRYABLE_FAILURE) {
            // 2차 안전망: 일시 오류에만 유효. 구조적 실패(FGS 시작 불허)는 워커도
            // 반드시 동일하게 실패하므로(배터리 최적화 면제는 리시버 시작에도 동일 적용) enqueue하지 않는다.
            ServiceRestartWorker.enqueue(context)
        }
    }

    companion object {
        private val TAG = "PackageReplacedReceiver ${BuildConfig.SIGNATURE}"
    }
}
