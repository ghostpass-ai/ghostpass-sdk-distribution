package com.ghostpasssdk.gopasssdk.data.engine.restart

internal interface ServiceRestartPolicy {
    fun hasLandmark(): Boolean
    fun hasBackgroundLocationPermission(): Boolean
    fun isServiceAlive(): Boolean
}

internal enum class RestartDecision {
    START,
    SKIP_NO_LANDMARK,
    SKIP_NO_PERMISSION,
    SKIP_ALREADY_RUNNING
}

internal fun ServiceRestartPolicy.evaluate(): RestartDecision = when {
    !hasLandmark() -> RestartDecision.SKIP_NO_LANDMARK
    !hasBackgroundLocationPermission() -> RestartDecision.SKIP_NO_PERMISSION
    isServiceAlive() -> RestartDecision.SKIP_ALREADY_RUNNING
    else -> RestartDecision.START
}
