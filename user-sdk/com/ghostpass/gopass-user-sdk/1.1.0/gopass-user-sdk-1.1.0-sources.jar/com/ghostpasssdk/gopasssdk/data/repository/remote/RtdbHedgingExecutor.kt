package com.ghostpasssdk.gopasssdk.data.repository.remote

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.withTimeoutOrNull

/**
 * hedge delay 근거 (실측 분포, USP-1081):
 * 정상 클러스터 95~283ms, tail 클러스터 532~820ms — 사이 gap(283~532ms)에 관측치 없음.
 * hedge delay는 이 gap 안에 두되, 표본이 작고(116건) 프로덕션 셀룰러 환경에서는
 * 정상 응답이 더 느려질 수 있으므로 gap 상단(500ms)을 택해
 * 불필요한 hedge 발사(트래픽 2배) 확률을 줄인다. 실측 후 튜닝 전제의 초기값.
 */
internal enum class RtdbHedgedOp(val label: String, val hedgeDelayMs: Long) {
    SESSION_STATE("PATCH user_to_kiosk", 500L),
    HEARTBEAT("PUT lastSeenAt", 500L),

    // 하트비트의 세션 노드 확인 GET. 동일 host(RTDB) 대상 소형 응답이라 write와 latency
    // 특성이 같다고 보고 동일 delay를 재사용한다. 응답 body가 있으므로 패자 완주(drain) 시
    // 커넥션 풀 반납을 위해 호출 블록 안에서 body를 반드시 소비(consume)할 것.
    SESSION_NODE_CHECK("GET session node", 500L)
}

/**
 * RTDB REST 멱등 요청(PATCH/PUT/GET) 전용 hedged request 실행기.
 *
 * 실측(USP-1076 latency 분석) 결과 RTDB(asia-southeast1) 응답의 10~15%가
 * 500ms+ tail을 보였고, 이는 요청 단위의 확률적 지연이다(total ≈ network,
 * dispatcher queue 병목 없음).
 *
 * hedge delay 안에 응답이 없으면 첫 요청을 취소하지 않은 채 두 번째 요청을
 * 병렬 발사하고 먼저 완료되는 쪽을 채택한다. 결과 latency는
 * min(첫 요청, delay + 두 번째 요청)이므로 "취소 후 재시도" 방식과 달리
 * 어떤 분포에서도 hedge 없는 경우보다 느려지지 않는다.
 *
 * 동일 payload의 PATCH/PUT과 GET은 멱등이므로 두 요청이 모두 서버에 도달해도
 * 최종 상태가 같다. 반드시 멱등 요청에만 사용할 것.
 */
internal class RtdbHedgingExecutor {
    companion object {
        private val TAG = "RtdbHedge ${BuildConfig.SIGNATURE}"
    }

    /**
     * 시도 실행용 스코프. coroutineScope(자식 완료까지 대기) 대신 이 스코프를 쓰는 이유:
     * 승자 확정 후 패자를 취소하지 않고 완주(drain)시켜야 하는데, 호출자의 반환은
     * 패자 완료를 기다리면 안 되기 때문(반환 지연 금지). 시도의 수명은 OkHttp
     * read timeout(~10s)으로 유계이므로 스코프에 남는 작업은 자연 소멸한다.
     */
    private val attemptScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * [block]을 실행하고, [RtdbHedgedOp.hedgeDelayMs] 안에 완료되지 않으면 두 번째 [block]을
     * 병렬로 발사해 먼저 완료되는 결과를 반환한다.
     * - 먼저 완료된 쪽이 성공이면 즉시 반환하고, 패자는 취소하지 않고 백그라운드에서 완주시킨다.
     *   근거: http/1.1은 응답 도중 취소된 커넥션을 재사용할 수 없어 풀에서 폐기된다(churn).
     *   우리 요청은 멱등 + 응답이 print=silent(204 빈 응답) 또는 소형 body(GET 세션노드)라
     *   끝까지 읽는 비용이 사실상 0이므로,
     *   완주시켜 커넥션을 풀에 정상 반납하는 쪽이 항상 이득이다 (USP-1076 실측: 취소로 인한
     *   커넥션 재수립이 열화 경로에서 TCP+TLS 수 초 비용 유발).
     * - 먼저 완료된 쪽이 예외로 실패하면 남은 쪽의 결과를 기다린다.
     * - hedge 발사 전에 첫 요청이 실패하면 즉시 전파한다 (지연에만 반응, 오류엔 재시도 없음).
     * - 호출자가 취소되면 진행 중인 시도를 모두 취소한다 (구조적 동시성 수동 보존).
     */
    suspend fun <T> execute(op: RtdbHedgedOp, block: suspend () -> T): T {
        val first = attemptScope.async { runAttempt(block) }
        try {
            // hedge delay 안에 첫 요청이 끝나면 그대로 반환 (오버헤드 0).
            // withTimeoutOrNull은 await()만 취소할 뿐 first 자체는 계속 실행된다.
            withTimeoutOrNull(op.hedgeDelayMs) { first.await() }
                ?.let { return it.getOrThrow() }

            warnLog(TAG, "${op.label} ${op.hedgeDelayMs}ms 초과 → hedge 요청 병렬 발사 (기존 요청 유지)")
            val second = attemptScope.async { runAttempt(block) }
            try {
                val winner = select<Winner<T>> {
                    first.onAwait { Winner(result = it, loser = second) }
                    second.onAwait { Winner(result = it, loser = first) }
                }

                return if (winner.result.isSuccess) {
                    // 패자는 attemptScope에서 완주 후 자연 소멸 (커넥션 풀 보존)
                    winner.result.getOrThrow()
                } else {
                    // 먼저 끝난 쪽이 실패 → 남은 쪽에 마지막 기회. 둘 다 실패면 남은 쪽 예외 전파.
                    winner.loser.await().getOrThrow()
                }
            } catch (e: CancellationException) {
                second.cancel()
                throw e
            }
        } catch (e: CancellationException) {
            first.cancel()
            throw e
        }
    }

    private class Winner<T>(
        val result: Result<T>,
        val loser: Deferred<Result<T>>
    )

    /** 실패를 Result로 감싸되, 취소는 구조적 동시성을 위해 그대로 전파한다. */
    private suspend fun <T> runAttempt(block: suspend () -> T): Result<T> =
        try {
            Result.success(block())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
}
