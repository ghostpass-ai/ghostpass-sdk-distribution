package com.ghostpasssdk.gopasssdk.internal.di

import android.bluetooth.BluetoothManager
import android.content.Context
import android.location.LocationManager
import android.net.ConnectivityManager
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.device.domain.DeviceStatusProvider
import com.ghostpasssdk.gopasssdk.core.device.infra.AndroidDeviceStatusProvider
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient
import com.ghostpasssdk.gopasssdk.core.network.infra.ConnDiagEventListenerFactory
import com.ghostpasssdk.gopasssdk.core.network.infra.SignedRequestPreflightChecker
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager
import com.ghostpasssdk.gopasssdk.core.security.infra.AndroidKeyManager
import com.ghostpasssdk.gopasssdk.core.security.infra.JcaCryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.infra.LocalDataEncryptor
import com.ghostpasssdk.gopasssdk.core.security.infra.RequestSigner
import com.ghostpasssdk.gopasssdk.data.repository.integrity.PlayIntegrityTokenProvider
import com.ghostpasssdk.gopasssdk.domain.repository.integrity.IntegrityTokenProvider
import com.ghostpasssdk.gopasssdk.data.api.AuthApi
import com.ghostpasssdk.gopasssdk.data.api.FirebaseApi
import com.ghostpasssdk.gopasssdk.data.api.RuntimeFlowLogApi
import com.ghostpasssdk.gopasssdk.data.api.SessionApi
import com.ghostpasssdk.gopasssdk.data.api.TokenApi
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraCompareAdapter
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraDetectionAdapter
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraExtractAdapter
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraLivenessAdapter
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraSdkManager
import com.ghostpasssdk.gopasssdk.data.engine.monitor.AndroidMonitoringServiceLauncher
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconMonitorAdapter
import com.ghostpasssdk.gopasssdk.data.repository.remote.AuthRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.remote.FirebaseRealtimeSessionRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.remote.RtdbHedgingExecutor
import com.ghostpasssdk.gopasssdk.data.repository.remote.RuntimeFlowLogRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.remote.SessionRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.remote.TokenRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.storage.IdentityRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.storage.LandmarkRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.storage.MonitoringPolicyRepositoryImpl
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceCompareEngine
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceDetectionEngine
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceEngineManager
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceExtractEngine
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceLivenessEngine
import com.ghostpasssdk.gopasssdk.domain.engine.monitor.ProximityMonitorEngine
import com.ghostpasssdk.gopasssdk.domain.repository.remote.AuthRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RuntimeFlowLogRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.TokenRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.MonitoringPolicyRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.device.CheckAllConditionsUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.errorlog.RuntimeFlowErrorReporter
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.CompareFacesUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.FaceRegisterUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StartProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StopProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.DeviceIdUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.ProvisionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.DecryptSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.FetchSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.ProcessSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.SessionSequenceTracker
import com.ghostpasssdk.gopasssdk.domain.usecase.session.UpdateSessionResultUseCase
import com.ghostpasssdk.gopasssdk.internal.manager.InfrastructureManager
import com.ghostpasssdk.gopasssdk.internal.manager.LandmarkManager
import com.ghostpasssdk.gopasssdk.internal.manager.MonitoringController
import com.ghostpasssdk.gopasssdk.internal.manager.ProximityObserver
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit
import kotlin.getValue

internal class SdkContainer private constructor(context: Context) {
    internal val appContext = context.applicationContext
    internal val keyManager: KeyManager by lazy { AndroidKeyManager(appContext) }
    private val cryptoEngine: CryptoEngine by lazy { JcaCryptoEngine() }

    private val localDataEncryptor by lazy {
        LocalDataEncryptor(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    private val requestSigner by lazy {
        RequestSigner(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    private val signedRequestPreflightChecker by lazy {
        SignedRequestPreflightChecker(
            identityRepository = identityRepository,
            requestSigner = requestSigner
        )
    }

    internal val provisionUseCase by lazy {
        ProvisionUseCase(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    internal val deviceIdUseCase by lazy {
        DeviceIdUseCase(
            context = appContext,
            cryptoEngine = cryptoEngine,
            identityRepository = identityRepository
        )
    }

    val identityRepository: IdentityRepository by lazy {
        IdentityRepositoryImpl(
            context = appContext,
            localDataEncryptor = localDataEncryptor
        )
    }

    private val json: Json by lazy {
        Json {
            ignoreUnknownKeys = true
            isLenient = true
            explicitNulls = false
            encodeDefaults = true
        }
    }

    private val apiClient: ApiClient by lazy {
        ApiClient(
            json = json,
            requestSigner = requestSigner,
            identityRepository = identityRepository
        )
    }

    private val okHttpClientLazy = lazy {
        apiClient.getSecureClientBuilder()
            .dispatcher(newDispatcher())
            .build()
    }
    private val okHttpClient: OkHttpClient by okHttpClientLazy

    private val firebaseRestOkHttpClientLazy = lazy {
        apiClient.getSecureClientBuilder()
            .dispatcher(newHighConcurrencyDispatcher())
            .eventListenerFactory(ConnDiagEventListenerFactory("REST")) // 임시 진단, 검증 후 롤백
            .build()
    }
    private val firebaseRestOkHttpClient: OkHttpClient by firebaseRestOkHttpClientLazy

    private val firebaseSseOkHttpClientLazy = lazy {
        apiClient.getSecureClientBuilder()
            .dispatcher(newHighConcurrencyDispatcher())
            .eventListenerFactory(ConnDiagEventListenerFactory("SSE")) // 임시 진단, 검증 후 롤백
            .build()
    }
    private val firebaseSseOkHttpClient: OkHttpClient by firebaseSseOkHttpClientLazy

    private val firebaseCriticalOkHttpClientLazy = lazy {
        apiClient.getSecureClientBuilder()
            .dispatcher(newCriticalFirebaseDispatcher())
            .connectionPool(ConnectionPool(FIREBASE_CRITICAL_MAX_IDLE_CONNECTIONS, FIREBASE_KEEP_ALIVE_MINUTES, TimeUnit.MINUTES))
            .eventListenerFactory(ConnDiagEventListenerFactory("CRITICAL")) // 임시 진단, 검증 후 롤백
            .build()
    }
    private val firebaseCriticalOkHttpClient: OkHttpClient by firebaseCriticalOkHttpClientLazy

    private val retrofit: Retrofit by lazy {
        apiClient.buildRetrofit(BuildConfig.BASE_URL, okHttpClient)
    }

    private val firebaseRetrofit: Retrofit by lazy {
        apiClient.buildRetrofit(BuildConfig.BASE_URL, firebaseRestOkHttpClient)
    }

    private val firebaseCriticalRetrofit: Retrofit by lazy {
        apiClient.buildRetrofit(BuildConfig.BASE_URL, firebaseCriticalOkHttpClient)
    }

    internal val integrityTokenProvider: IntegrityTokenProvider by lazy {
        PlayIntegrityTokenProvider(appContext)
    }

    private val authApi: AuthApi by lazy {
        retrofit.create(AuthApi::class.java)
    }

    private val sessionApi: SessionApi by lazy {
        retrofit.create(SessionApi::class.java)
    }

    private val tokenApi: TokenApi by lazy {
        retrofit.create(TokenApi::class.java)
    }

    private val runtimeFlowLogApi: RuntimeFlowLogApi by lazy {
        retrofit.create(RuntimeFlowLogApi::class.java)
    }

    private val firebaseApi by lazy {
        firebaseRetrofit.create(FirebaseApi::class.java)
    }

    private val criticalFirebaseApi by lazy {
        firebaseCriticalRetrofit.create(FirebaseApi::class.java)
    }

    internal val authRepository: AuthRepository by lazy {
        AuthRepositoryImpl(
            authApi = authApi,
            signedRequestPreflightChecker = signedRequestPreflightChecker
        )
    }

    internal val sessionRepository: SessionRepository by lazy {
        SessionRepositoryImpl(
            sessionApi = sessionApi,
            signedRequestPreflightChecker = signedRequestPreflightChecker
        )
    }

    private val runtimeFlowLogRepository: RuntimeFlowLogRepository by lazy {
        RuntimeFlowLogRepositoryImpl(
            runtimeFlowLogApi = runtimeFlowLogApi
        )
    }

    internal val runtimeFlowErrorReporter: RuntimeFlowErrorReporter by lazy {
        RuntimeFlowErrorReporter(
            repository = runtimeFlowLogRepository
        )
    }

    private val tokenRepository: TokenRepository by lazy {
        TokenRepositoryImpl(
            tokenApi = tokenApi,
            signedRequestPreflightChecker = signedRequestPreflightChecker
        )
    }

    private val alcheraSdkManager by lazy { AlcheraSdkManager(appContext) }

    private val faceEngineManager: FaceEngineManager get() = alcheraSdkManager

    /**
     * cold start 시 FaceSDK 네이티브 로드(~5s)를 최대한 앞당기기 위한 사전 초기화 Job.
     * getOrCreate() 시점에 시작되어, delegateAuthSession Phase 2 진입 전까지 초기화 시간 확보.
     * 이미 초기화된 상태에서는 faceEngineManager.initialize()가 멱등이므로 즉시 완료.
     */
    internal var faceEngineWarmUpJob: Job? = null
        private set

    internal fun warmUpFaceEngine() {
        if (faceEngineWarmUpJob != null) return
        faceEngineWarmUpJob = CoroutineScope(Dispatchers.IO).launch {
            runCatching { faceEngineManager.initialize() }
        }
    }

    private val faceDetectionEngine: FaceDetectionEngine by lazy {
        AlcheraDetectionAdapter(alcheraSdkManager)
    }

    private val faceLivenessEngine: FaceLivenessEngine by lazy {
        AlcheraLivenessAdapter(alcheraSdkManager)
    }

    private val faceExtractEngine: FaceExtractEngine by lazy {
        AlcheraExtractAdapter(alcheraSdkManager)
    }

    private val faceCompareEngine: FaceCompareEngine by lazy {
        AlcheraCompareAdapter(alcheraSdkManager)
    }

    private val landmarkRepository: LandmarkRepository by lazy {
        LandmarkRepositoryImpl(
            context = appContext,
            localDataEncryptor = localDataEncryptor,
            identityRepository = identityRepository
        )
    }

    private val faceRegisterUseCase by lazy {
        FaceRegisterUseCase(
            detectionEngine = faceDetectionEngine,
            livenessEngine = faceLivenessEngine,
            extractEngine = faceExtractEngine
        )
    }

    private val monitoringServiceLauncher by lazy {
        AndroidMonitoringServiceLauncher(context = appContext)
    }

    private val monitorEngine: ProximityMonitorEngine by lazy {
        BeaconMonitorAdapter(serviceLauncher = monitoringServiceLauncher)
    }

    private val monitoringPolicyRepository: MonitoringPolicyRepository by lazy {
        MonitoringPolicyRepositoryImpl(context = appContext)
    }

    private val startMonitorUseCase by lazy {
        StartProximityMonitorUseCase(
            monitorEngine = monitorEngine,
            landmarkRepository = landmarkRepository,
            identityRepository = identityRepository,
            deviceStatusProvider = deviceStatusProvider,
            monitoringPolicyRepository = monitoringPolicyRepository
        )
    }

    private val stopMonitorUseCase by lazy {
        StopProximityMonitorUseCase(
            monitorEngine = monitorEngine
        )
    }

    private val decryptSessionUseCase by lazy {
        DecryptSessionUseCase(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager,
            errorReporter = runtimeFlowErrorReporter
        )
    }

    private val fetchSessionUseCase by lazy {
        FetchSessionUseCase(
            sessionRepository = sessionRepository,
            landmarkRepository = landmarkRepository,
            errorReporter = runtimeFlowErrorReporter
        )
    }

    private val rtdbHedgingExecutor by lazy {
        RtdbHedgingExecutor()
    }

    private val realtimeSessionRepository: RealtimeSessionRepository by lazy {
        FirebaseRealtimeSessionRepositoryImpl(
            firebaseApi = firebaseApi,
            criticalFirebaseApi = criticalFirebaseApi,
            sseOkHttpClient = firebaseSseOkHttpClient,
            cryptoEngine = cryptoEngine,
            errorReporter = runtimeFlowErrorReporter,
            hedgingExecutor = rtdbHedgingExecutor
        )
    }

    private val processSessionUseCase by lazy {
        ProcessSessionUseCase(
            realtimeSessionRepository = realtimeSessionRepository
        )
    }

    private val compareFacesUseCase by lazy {
        CompareFacesUseCase(
            landmarkRepository = landmarkRepository,
            faceCompareEngine = faceCompareEngine,
            errorReporter = runtimeFlowErrorReporter
        )
    }

    private val sessionSequenceTracker by lazy { SessionSequenceTracker() }

    private val updateSessionResultUseCase by lazy {
        UpdateSessionResultUseCase(
            realtimeSessionRepository = realtimeSessionRepository,
            sessionRepository = sessionRepository,
            cryptoEngine = cryptoEngine,
            identityRepository = identityRepository,
            errorReporter = runtimeFlowErrorReporter
        )
    }

    private val proximityObserver by lazy {
        ProximityObserver(
            fetchSessionUseCase = fetchSessionUseCase,
            decryptSessionUseCase = decryptSessionUseCase,
            processSessionUseCase = processSessionUseCase,
            compareFacesUseCase = compareFacesUseCase,
            updateSessionResultUseCase = updateSessionResultUseCase,
            sessionRepository = sessionRepository,
            sessionSequenceTracker = sessionSequenceTracker,
            errorReporter = runtimeFlowErrorReporter
        )
    }

    val infrastructureManager by lazy {
        InfrastructureManager(
            context = appContext,
            identityRepository = identityRepository,
            deviceIdUseCase = deviceIdUseCase,
            provisionUseCase = provisionUseCase,
            authRepository = authRepository,
            integrityTokenProvider = integrityTokenProvider,
            faceEngineManager = faceEngineManager,
            startMonitorUseCase = startMonitorUseCase,
            stopMonitorUseCase = stopMonitorUseCase,
            proximityObserver = proximityObserver,
            landmarkRepository = landmarkRepository,
            monitoringPolicyRepository = monitoringPolicyRepository,
            tokenRepository = tokenRepository,
            decryptSessionUseCase = decryptSessionUseCase,
            faceEngineWarmUpJob = { faceEngineWarmUpJob }
        )
    }

    val monitoringController by lazy {
        MonitoringController(
            monitoringPolicyRepository = monitoringPolicyRepository,
            startMonitorUseCase = startMonitorUseCase,
            stopMonitorUseCase = stopMonitorUseCase
        )
    }

    val landmarkManager by lazy {
        LandmarkManager(
            faceRegisterUseCase = faceRegisterUseCase,
            landmarkRepository = landmarkRepository,
            identityRepository = identityRepository,
            startProximityMonitorUseCase = startMonitorUseCase,
            stopProximityMonitorUseCase = stopMonitorUseCase,
            proximityObserver = proximityObserver
        )
    }

    private val deviceStatusProvider: DeviceStatusProvider by lazy {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        AndroidDeviceStatusProvider(
            context = appContext,
            bluetoothManager = bluetoothManager,
            connectivityManager = connectivityManager,
            locationManager = locationManager
        )
    }

    val checkAllConditionsUseCase: CheckAllConditionsUseCase by lazy {
        CheckAllConditionsUseCase(
            deviceStatusProvider = deviceStatusProvider
        )
    }

    /**
     * START_STICKY로 서비스가 재시작될 때 ProximityObserver의 EventBus 컬렉터를 복원한다.
     * 정상 경로(GoPassSDK.initialize)에서는 InfrastructureManager가 호출하므로
     * AtomicBoolean 가드에 의해 중복 초기화가 방지된다.
     */
    fun ensureProximityLifecycle() {
        proximityObserver.initializeLifecycle()
    }

    fun triggerSessionForBeacon(major: Int, minor: Int, rssi: Int) {
        proximityObserver.triggerSessionForBeacon(major, minor, rssi)
    }

    /**
     * 초기화된 OkHttp 클라이언트의 커넥션 풀과 디스패처를 정리합니다.
     * lazy 미초기화 상태에서는 불필요한 객체 생성을 방지합니다.
     */
    private fun release() {
        faceEngineWarmUpJob?.cancel()
        faceEngineWarmUpJob = null
        releaseOkHttpClientIfInitialized(okHttpClientLazy)
        releaseOkHttpClientIfInitialized(firebaseRestOkHttpClientLazy)
        releaseOkHttpClientIfInitialized(firebaseSseOkHttpClientLazy)
        releaseOkHttpClientIfInitialized(firebaseCriticalOkHttpClientLazy)
    }

    private fun releaseOkHttpClientIfInitialized(clientLazy: Lazy<OkHttpClient>) {
        if (!clientLazy.isInitialized()) return
        val client = clientLazy.value
        client.connectionPool.evictAll()
        client.dispatcher.executorService.shutdown()
    }

    companion object {
        private const val DEFAULT_MAX_REQUESTS = 64
        private const val FIREBASE_MAX_REQUESTS = 64
        private const val FIREBASE_MAX_REQUESTS_PER_HOST = 50
        private const val FIREBASE_CRITICAL_MAX_IDLE_CONNECTIONS = 8
        private const val FIREBASE_KEEP_ALIVE_MINUTES = 5L

        @Volatile
        private var instance: SdkContainer? = null

        private fun newDispatcher(): Dispatcher = Dispatcher().apply {
            maxRequests = DEFAULT_MAX_REQUESTS
        }

        private fun newHighConcurrencyDispatcher(): Dispatcher = Dispatcher().apply {
            maxRequests = FIREBASE_MAX_REQUESTS
            maxRequestsPerHost = FIREBASE_MAX_REQUESTS_PER_HOST
        }

        private fun newCriticalFirebaseDispatcher(): Dispatcher = Dispatcher().apply {
            maxRequests = FIREBASE_MAX_REQUESTS
            maxRequestsPerHost = FIREBASE_MAX_REQUESTS_PER_HOST
        }

        internal fun getOrCreate(context: Context): SdkContainer {
            val applicationContext = context.applicationContext
            return instance ?: synchronized(this) {
                instance ?: SdkContainer(applicationContext).also {
                    instance = it
                    it.warmUpFaceEngine()
                }
            }
        }

        internal fun requireInstance(): SdkContainer {
            return instance ?: throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.CONTAINER_IS_NULL
            )
        }

        internal suspend fun destroyInstance() {
            withContext(Dispatchers.IO) {
                synchronized(this@Companion) {
                    instance?.release()
                    instance = null
                }
            }
        }
    }
}
