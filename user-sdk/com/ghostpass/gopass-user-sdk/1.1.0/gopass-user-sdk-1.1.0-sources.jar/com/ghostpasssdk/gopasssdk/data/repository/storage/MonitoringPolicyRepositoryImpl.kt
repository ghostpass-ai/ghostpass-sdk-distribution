package com.ghostpasssdk.gopasssdk.data.repository.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.ghostpasssdk.gopasssdk.domain.repository.storage.MonitoringPolicyRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * [MonitoringPolicyRepository]의 SharedPreferences 구현.
 *
 * - 최초 접근 시 디스크에서 1회 로드 후 메모리 캐시로 읽는다.
 * - 쓰기는 메모리 캐시를 즉시 갱신하고, 디스크는 IO 디스패처에서 commit으로 동기 반영한다.
 *   (프로세스 kill 직후에도 호스트 의도가 유실되지 않도록 apply 대신 commit 사용)
 */
internal class MonitoringPolicyRepositoryImpl(
    private val context: Context
) : MonitoringPolicyRepository {

    @Volatile
    private var cachedSuppressed: Boolean? = null

    override val isSuppressedByHost: Boolean
        get() = cachedSuppressed ?: isSuppressedByHostSync(context).also { cachedSuppressed = it }

    override suspend fun suppressByHost() = write(suppressed = true)

    override suspend fun clearSuppression() = write(suppressed = false)

    private suspend fun write(suppressed: Boolean) {
        cachedSuppressed = suppressed
        withContext(Dispatchers.IO) {
            prefs(context).edit(commit = true) {
                putBoolean(KEY_HOST_SUPPRESSED, suppressed)
            }
        }
    }

    companion object {
        private const val PREFS_NAME = "gopass_monitoring_policy"
        private const val KEY_HOST_SUPPRESSED = "host_suppressed"

        private fun prefs(context: Context): SharedPreferences =
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        /**
         * 디스크 직독. 서비스/리시버 프로세스가 SdkContainer 초기화 없이
         * 억제 상태를 확인해야 할 때 사용한다 (보험 스캔 wake-up, START_STICKY 재시작 방어).
         */
        internal fun isSuppressedByHostSync(context: Context): Boolean =
            prefs(context).getBoolean(KEY_HOST_SUPPRESSED, false)
    }
}
