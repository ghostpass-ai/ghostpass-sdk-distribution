package com.ghostpasssdk.gopasssdk.data.engine.restart

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog

internal class BootCompletedReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        // BOOT_COMPLETED 수신 컨텍스트가 백그라운드 FGS 시작 면제 조건이다
        // (MY_PACKAGE_REPLACED와 동일한 공식 면제 목록 항목).
        // 워커로 지연 위임하면 면제가 소멸하므로 onReceive 안에서 직접 시작한다.
        // API 34+의 BOOT_COMPLETED 리시버 FGS 타입 제한에 location은 포함되지 않는다.
        // BT 스택 준비 등 부팅 직후 대기는 서비스 내부(DeviceStateObserver)가 담당한다.
        debugLog(TAG, "부팅 완료 감지 → FGS 재시작 시도")
        val result = ServiceRestartExecutor(context).execute()
        if (result == RestartExecutionResult.RETRYABLE_FAILURE) {
            // 2차 안전망: 일시 오류에만 유효 (PackageReplacedReceiver와 동일 정책)
            ServiceRestartWorker.enqueue(context)
        }
    }

    companion object {
        private val TAG = "BootCompletedReceiver ${BuildConfig.SIGNATURE}"
    }
}
