package com.ghostpasssdk.gopasssdk.domain.usecase.monitor

import com.ghostpasssdk.gopasssdk.domain.engine.monitor.ProximityMonitorEngine
import com.ghostpasssdk.gopasssdk.core.device.domain.DeviceStatusProvider
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.MonitoringPolicyRepository
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class StartProximityMonitorUseCase(
    private val monitorEngine: ProximityMonitorEngine,
    private val landmarkRepository: LandmarkRepository,
    private val identityRepository: IdentityRepository,
    private val deviceStatusProvider: DeviceStatusProvider,
    private val monitoringPolicyRepository: MonitoringPolicyRepository
) {
    companion object {
        private val TAG = "StartProximityMonitorUseCase ${BuildConfig.SIGNATURE}"
    }
    suspend fun execute(): Boolean = withContext(Dispatchers.Default){
        debugLog(TAG, "비콘 시작 호출")
        if(monitoringPolicyRepository.isSuppressedByHost){
            debugLog(TAG, "호스트가 명시적으로 모니터링을 중지한 상태 — 시작 요청 무효화")
            return@withContext false
        }
        if(monitorEngine.isRunning){
            debugLog(TAG, "이미 모니터링 중 — 중복 호출 무시")
            return@withContext true
        }
        if(!landmarkRepository.hasLandmark()){
            debugLog(TAG, "비콘 모니터링을 시작했지만 랜드마크가 존재하지 않습니다.")
            return@withContext false
        }

        validateEnvironment()

        return@withContext monitorEngine.startMonitoring()
    }

    private fun validateEnvironment() {
        if (!deviceStatusProvider.isBluetoothPermissionGranted()) {
            throw GoPassException.from(
                error = ErrorCode.BLUETOOTH_PERMISSION_DENIED,
                internalCode = InternalErrorCode.BLUETOOTH_PERMISSION_DENIED
            )
        }

        if (!deviceStatusProvider.isLocationPermissionGranted()) {
            throw GoPassException.from(
                error = ErrorCode.LOCATION_PERMISSION_DENIED,
                internalCode = InternalErrorCode.LOCATION_PERMISSION_DENIED
            )
        }

        if (!deviceStatusProvider.isLocationPermissionSufficient()) {
            throw GoPassException.from(
                error = ErrorCode.LOCATION_PERMISSION_INSUFFICIENT,
                internalCode = InternalErrorCode.LOCATION_PERMISSION_INSUFFICIENT
            )
        }

        if (identityRepository.getBeaconUuid().isNullOrBlank()) {
            throw GoPassException.from(
                error = ErrorCode.BEACON_UUID_NOT_FOUND,
                internalCode = InternalErrorCode.BEACON_UUID_NOT_FOUND
            )
        }
    }
}
