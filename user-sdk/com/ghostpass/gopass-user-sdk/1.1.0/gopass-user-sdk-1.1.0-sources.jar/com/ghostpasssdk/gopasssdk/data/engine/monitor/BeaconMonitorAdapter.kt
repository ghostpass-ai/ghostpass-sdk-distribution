package com.ghostpasssdk.gopasssdk.data.engine.monitor

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.engine.monitor.MonitoringServiceLauncher
import com.ghostpasssdk.gopasssdk.domain.engine.monitor.ProximityMonitorEngine
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.withTimeoutOrNull

internal class BeaconMonitorAdapter(
    private val serviceLauncher: MonitoringServiceLauncher,
    private val timeoutMillis: Long = TIMEOUT_MILLIS
): ProximityMonitorEngine {

    companion object {
        private val TAG = "BeaconMonitorAdapter ${BuildConfig.SIGNATURE}"
        private const val TIMEOUT_MILLIS = 5000L
    }

    override val isRunning: Boolean
        get() = serviceLauncher.isServiceRunning

    override suspend fun startMonitoring(): Boolean {
        debugLog(TAG, "startMonitoring: 안드로이드 포그라운드 서비스 호출")

        BeaconServiceEvents.clearScanStartEvents()

        try {
            serviceLauncher.launchService()
        } catch (e: Exception) {
            errorLog(TAG, "서비스 시작 실패 (OS 예외): ${e.message}")
            runCatching { serviceLauncher.stopService() }
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.MONITORING_SERVICE_OS_EXCEPTION
            )
        }

        val result = withTimeoutOrNull(timeoutMillis) {
            merge(
                BeaconServiceEvents.monitorReady.map { true },
                BeaconServiceEvents.scanStarted.map { true },
                BeaconServiceEvents.scanStartFailed.map {
                    errorLog(TAG, "서비스 시작 실패됨: $it")
                    runCatching { serviceLauncher.stopService() }
                    false
                }
            ).first()
        }

        if (result == null) {
            runCatching { serviceLauncher.stopService() }
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.MONITORING_SERVICE_TIMEOUT
            )
        }

        if (!result) {
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.MONITORING_SERVICE_START_FAILED
            )
        }

        return true
    }

    override suspend fun stopMonitoring(): Boolean {
        debugLog(TAG, "stopMonitoring: 호출")

        BeaconServiceEvents.clearDestroyEvents()

        runCatching { serviceLauncher.stopService() }

        val result = withTimeoutOrNull(timeoutMillis) {
            BeaconServiceEvents.serviceDestroyed.first()
            true
        }

        if (result == null) {
            errorLog(TAG, "stopMonitoring 타임아웃: 서비스 종료 신호를 받지 못함")
            // 종료 "확인" 실패이지 종료 실패 확정이 아님 — 서비스가 늦게 죽을 수 있으며,
            // 재호출 시 isRunning=false면 멱등 성공하므로 호스트는 안전하게 재시도 가능
            throw GoPassException.from(
                error = ErrorCode.MONITORING_STOP_FAILED,
                internalCode = InternalErrorCode.MONITORING_SERVICE_STOP_TIMEOUT
            )
        }
        return true
    }
}
