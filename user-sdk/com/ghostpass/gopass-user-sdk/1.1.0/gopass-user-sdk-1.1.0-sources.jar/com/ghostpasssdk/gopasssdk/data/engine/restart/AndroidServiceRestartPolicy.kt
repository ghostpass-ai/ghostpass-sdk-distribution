package com.ghostpasssdk.gopasssdk.data.engine.restart

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconDetectionService
import com.ghostpasssdk.gopasssdk.data.repository.storage.LandmarkRepositoryImpl

internal class AndroidServiceRestartPolicy(
    private val context: Context
) : ServiceRestartPolicy {

    override fun hasLandmark(): Boolean =
        LandmarkRepositoryImpl.hasLandmark(context)

    override fun hasBackgroundLocationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_BACKGROUND_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun isServiceAlive(): Boolean =
        BeaconDetectionService.isServiceAlive
}
