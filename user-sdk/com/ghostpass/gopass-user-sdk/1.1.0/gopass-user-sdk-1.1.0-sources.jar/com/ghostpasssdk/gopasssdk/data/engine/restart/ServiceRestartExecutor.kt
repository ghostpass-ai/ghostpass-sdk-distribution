package com.ghostpasssdk.gopasssdk.data.engine.restart

import android.app.ForegroundServiceStartNotAllowedException
import android.content.Context
import android.content.Intent
import android.os.Build
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconDetectionService
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.warnLog

/** 재시작 실행 결과. 워커 재시도·리시버 안전망 enqueue 판단에 사용한다. */
internal enum class RestartExecutionResult {
    /** 시작 성공 또는 시작 불필요(랜드마크 없음·이미 실행 중·권한 없음) */
    COMPLETED,

    /** 일시 오류 — 재시도 의미 있음 */
    RETRYABLE_FAILURE,

    /** 구조적 실패(백그라운드 FGS 시작 불허 등) — 재시도해도 동일하게 실패 */
    PERMANENT_FAILURE
}

/**
 * 재시작 판단(ServiceRestartPolicy)과 FGS 시작 실행을 담당한다.
 * PackageReplacedReceiver(주 경로)와 ServiceRestartWorker(보조 경로)가 공유한다.
 */
internal class ServiceRestartExecutor(private val context: Context) {

    fun execute(
        policy: ServiceRestartPolicy = AndroidServiceRestartPolicy(context)
    ): RestartExecutionResult {
        return when (policy.evaluate()) {
            RestartDecision.SKIP_NO_LANDMARK -> {
                debugLog(TAG, "랜드마크 없음 → FGS 재시작 불필요")
                RestartExecutionResult.COMPLETED
            }
            RestartDecision.SKIP_ALREADY_RUNNING -> {
                debugLog(TAG, "서비스 이미 실행 중 → 재시작 불필요")
                RestartExecutionResult.COMPLETED
            }
            RestartDecision.SKIP_NO_PERMISSION -> {
                // 재시도해도 권한 상태는 바뀌지 않으므로 완료로 처리 (의도된 조용한 비활성화)
                warnLog(TAG, "ACCESS_BACKGROUND_LOCATION 미허용 → FGS 시작 불가")
                RestartExecutionResult.COMPLETED
            }
            RestartDecision.START -> startService()
        }
    }

    private fun startService(): RestartExecutionResult {
        return try {
            val intent = Intent(context, BeaconDetectionService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            debugLog(TAG, "FGS 재시작 요청 성공")
            RestartExecutionResult.COMPLETED
        } catch (e: IllegalStateException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                e is ForegroundServiceStartNotAllowedException
            ) {
                // targetSdk 31+ 백그라운드 시작 불허 — 프로세스 상태가 바뀌기 전엔 재시도 무의미
                warnLog(TAG, "백그라운드 FGS 시작 불허(면제 없음): ${e.message}")
                RestartExecutionResult.PERMANENT_FAILURE
            } else {
                warnLog(TAG, "FGS 시작 일시 실패: ${e.message}")
                RestartExecutionResult.RETRYABLE_FAILURE
            }
        } catch (e: SecurityException) {
            // startForegroundService의 SecurityException은 "서비스 접근 불가/미발견" — 설정 오류 클래스.
            // (API 34+ 타입 권한 검사 SecurityException은 서비스 내부 startForeground에서 발생하며
            //  BeaconDetectionService 쪽 try/catch가 처리 — 이 catch에는 도달하지 않음)
            warnLog(TAG, "FGS 시작 SecurityException: ${e.message}")
            RestartExecutionResult.PERMANENT_FAILURE
        } catch (e: Exception) {
            warnLog(TAG, "FGS 재시작 실패: ${e.javaClass.simpleName}: ${e.message}")
            RestartExecutionResult.RETRYABLE_FAILURE
        }
    }

    companion object {
        private val TAG = "ServiceRestartExecutor ${BuildConfig.SIGNATURE}"
    }
}
