package com.ghostpasssdk.gopasssdk.data.engine.monitor

import android.content.Context
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 스캔 리프레시 후 ScanCallback 수신 여부를 모니터링하여 silent failure를 감지한다.
 *
 * - restart 후 [HEALTH_CHECK_TIMEOUT_MS] 내 콜백 미수신 → silent failure 판정
 * - 선형 백오프(+[BACKOFF_STEP_MS])로 stop→start 간 delay를 늘려가며 즉시 재시도
 * - 최대 delay: [MAX_RESTART_DELAY_MS]
 * - debug 빌드에서만 SharedPreferences에 CSV 이력 기록
 */
internal class ScanRefreshHealthCheck(private val context: Context) {

    companion object {
        private val TAG = "ScanRefreshHealthCheck ${BuildConfig.SIGNATURE}"
        const val HEALTH_CHECK_TIMEOUT_MS = 7_000L
        const val INITIAL_RESTART_DELAY_MS = 300L
        const val BACKOFF_STEP_MS = 300L
        const val MAX_RESTART_DELAY_MS = 8_000L
        private const val PREFS_NAME = "ble-scan-restart-history"
        private const val KEY_HISTORY = "history_csv"
        private const val MAX_HISTORY_ENTRIES = 200
    }

    /** 현재 리프레시에 사용된 restart delay */
    var currentRestartDelayMs: Long = INITIAL_RESTART_DELAY_MS
        private set

    /** 리프레시 후 콜백 수신 여부 추적 */
    @Volatile
    var callbackReceivedAfterRefresh = false
        private set

    private var refreshTimestampMs: Long = 0

    /** 리프레시 시작 시 호출 — health check 타이머의 기준 시각 설정 */
    fun onRefreshStarted() {
        callbackReceivedAfterRefresh = false
        refreshTimestampMs = System.currentTimeMillis()
    }

    /** ScanCallback.onScanResult 수신 시 호출 */
    fun onCallbackReceived() {
        callbackReceivedAfterRefresh = true
    }

    /**
     * health check 결과 판정.
     * - true: 콜백 정상 수신 → delay를 초기값으로 리셋
     * - false: silent failure → delay를 선형 증가
     */
    fun evaluate(): Boolean {
        val success = callbackReceivedAfterRefresh
        val elapsedMs = System.currentTimeMillis() - refreshTimestampMs

        if (success) {
            recordHistory(currentRestartDelayMs, true, elapsedMs)
            debugLog(TAG, "health check 통과: delay=${currentRestartDelayMs}ms, 콜백 수신까지 ${elapsedMs}ms")
            currentRestartDelayMs = INITIAL_RESTART_DELAY_MS
        } else {
            recordHistory(currentRestartDelayMs, false, elapsedMs)
            val nextDelay = (currentRestartDelayMs + BACKOFF_STEP_MS).coerceAtMost(MAX_RESTART_DELAY_MS)
            warnLog(TAG, "health check 실패 (silent failure): delay=${currentRestartDelayMs}ms → 다음 재시도 delay=${nextDelay}ms")
            currentRestartDelayMs = nextDelay
        }

        return success
    }

    fun reset() {
        currentRestartDelayMs = INITIAL_RESTART_DELAY_MS
        callbackReceivedAfterRefresh = false
        refreshTimestampMs = 0
    }

    // ── debug 전용 CSV 이력 기록 ──

    private fun recordHistory(delayMs: Long, success: Boolean, elapsedMs: Long) {
        if (!BuildConfig.DEBUG) return

        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val existing = prefs.getString(KEY_HISTORY, "") ?: ""
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val newEntry = "$timestamp,$delayMs,${if (success) "OK" else "FAIL"},$elapsedMs"

            val lines = existing.lines().filter { it.isNotBlank() }.toMutableList()
            lines.add(newEntry)

            // 최대 엔트리 수 제한
            while (lines.size > MAX_HISTORY_ENTRIES) {
                lines.removeFirst()
            }

            prefs.edit()
                .putString(KEY_HISTORY, lines.joinToString("\n"))
                .apply()

            debugLog(TAG, "이력 기록: $newEntry")
        } catch (e: Exception) {
            warnLog(TAG, "이력 기록 실패: ${e.message}")
        }
    }
}
