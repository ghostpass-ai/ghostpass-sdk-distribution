package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.data.repository.mapper.ApiEndpoint
import com.ghostpasssdk.gopasssdk.data.repository.mapper.getOrThrow
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.RuntimeFlowErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionParams
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.errorlog.RuntimeFlowErrorReporter

internal class FetchAndDecryptSessionUseCase(
    private val sessionRepository: SessionRepository,
    private val decryptSessionUseCase: DecryptSessionUseCase,
    private val landmarkRepository: LandmarkRepository,
    private val errorReporter: RuntimeFlowErrorReporter
) {
    suspend fun execute(major: Int, minor: Int, rssi: Int): DecryptedSession {
        if (!landmarkRepository.hasLandmark()) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.BIOMETRIC_DATA_MISSING,
                message = "생체 데이터 없음 — 세션 생성 불가"
            )
            throw GoPassException.from(
                error = ErrorCode.INTERNAL_ERROR,
                internalCode = InternalErrorCode.HANDSFREE_BIO_DATA_NOT_FOUND
            )
        }

        val params = SessionParams(major = major, minor = minor, rssi = rssi)
        val encrypted = sessionRepository.sessions(params).getOrThrow(ApiEndpoint.SESSION)

        if (encrypted.sessionId.isBlank() || encrypted.rtdbPath.isBlank() ||
            encrypted.encryptedDk.isBlank() || encrypted.firebaseToken.isBlank()
        ) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.SESSION_RESPONSE_INVALID,
                message = "세션 응답 필수 필드 누락: sessionId=${encrypted.sessionId.isNotBlank()}, rtdbPath=${encrypted.rtdbPath.isNotBlank()}, encryptedDk=${encrypted.encryptedDk.isNotBlank()}, firebaseToken=${encrypted.firebaseToken.isNotBlank()}",
                sessionId = encrypted.sessionId.takeIf { it.isNotBlank() }
            )
            throw GoPassException.from(
                error = ErrorCode.INTERNAL_ERROR,
                internalCode = InternalErrorCode.SESSION_RESPONSE_INVALID
            )
        }

        if (encrypted.status != SESSION_STATUS_ACTIVE) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.SESSION_RESPONSE_INVALID,
                message = "세션 상태 비정상: status=${encrypted.status}",
                sessionId = encrypted.sessionId
            )
            throw GoPassException.from(
                error = ErrorCode.INTERNAL_ERROR,
                internalCode = InternalErrorCode.SESSION_RESPONSE_INVALID
            )
        }

        if (System.currentTimeMillis() > encrypted.expiresAtMillis) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.SESSION_EXPIRED,
                message = "세션 이미 만료: expiresAtMillis=${encrypted.expiresAtMillis}",
                sessionId = encrypted.sessionId
            )
            throw GoPassException.from(
                error = ErrorCode.INTERNAL_ERROR,
                internalCode = InternalErrorCode.HANDSFREE_SESSION_EXPIRED
            )
        }

        return decryptSessionUseCase.execute(encrypted)
    }

    companion object {
        private const val SESSION_STATUS_ACTIVE = "ACTIVE"
    }
}