package com.ghostpasssdk.gopasssdk.data.dto.errorlog

import kotlinx.serialization.Serializable

@Serializable
internal data class RuntimeFlowLogRequest(
    val sessionId: String? = null,
    val errorCode: String,
    val errorMessage: String,
    val sdkVersion: String,
    val platform: String,
    val osVersion: String,
    val clientTimestamp: Long
)
