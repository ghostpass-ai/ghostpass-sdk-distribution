package com.ghostpasssdk.gopasssdk.data.engine.monitor

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanResult
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.warnLog

/**
 * OS PendingIntent BLE 스캔의 수신자.
 *
 * OS BT 칩이 매칭 비콘을 감지하면 이 리시버가 깨고,
 * 수신된 ScanResult를 BeaconDetectionService(FGS)의 공통 처리 경로로 위임한다.
 * 서비스가 살아 있어도 화면 꺼짐/hold 상태에서는 ScanCallback이 지연될 수 있으므로
 * PendingIntent 스캔 결과를 버리지 않는다.
 *
 * Android 12+ 백그라운드 FGS 시작 조건:
 * ACCESS_BACKGROUND_LOCATION이 런타임에 grant("항상 허용")되어 있어야
 * foregroundServiceType="location" 서비스를 백그라운드에서 시작할 수 있다.
 */
internal class BeaconWakeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_BEACON_WAKE) return

        // 보험 스캔이 취소된 상태에서의 잔여 배달 차단 (OS BLE 배치 지연·Samsung BLE 스택 대응)
        if (!isInsuranceScanActive(context)) {
            debugLog(TAG, "보험 스캔 비활성 상태 — 잔여 wake-up 무시, 정리 재시도")
            safeCancelInsuranceScan(context)
            return
        }

        if (!shouldAllowInsuranceWakeUp(context)) {
            debugLog(TAG, "보험 스캔 wake-up skip: exemption 조건 미충족")
            safeCancelInsuranceScan(context)
            return
        }

        val errorCode = getPendingIntentScanErrorCode(intent)
        val results: List<ScanResult>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra(
                BluetoothLeScanner.EXTRA_LIST_SCAN_RESULT,
                ScanResult::class.java
            )
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableArrayListExtra(BluetoothLeScanner.EXTRA_LIST_SCAN_RESULT)
        }

        if (errorCode != null) {
            warnLog(TAG, "OS 위임 BLE 스캔 errorCode 수신: errorCode=$errorCode, results=${results?.size ?: 0}")
        }

        if (results.isNullOrEmpty()) {
            handleEmptyPendingScanResult(context, errorCode)
            return
        }

        if (!canStartWakeForegroundService(context)) {
            safeCancelInsuranceScan(context)
            return
        }

        debugLog(
            TAG,
            "OS 비콘 감지 wake-up → FGS 전달 (alive=${BeaconDetectionService.isServiceAlive}, 결과 ${results.size}건)"
        )

        val serviceIntent = Intent(context, BeaconDetectionService::class.java).apply {
            action = BeaconDetectionService.ACTION_PROCESS_PENDING_SCAN_RESULTS
            putParcelableArrayListExtra(
                BeaconDetectionService.EXTRA_PENDING_SCAN_RESULTS,
                ArrayList(results)
            )
            if (errorCode != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                putExtra(BluetoothLeScanner.EXTRA_ERROR_CODE, errorCode)
            }
        }
        startBeaconDetectionService(context, serviceIntent)
    }

    private fun handleEmptyPendingScanResult(context: Context, errorCode: Int?) {
        when (errorCode) {
            null -> debugLog(TAG, "OS 위임 BLE 스캔 결과 없음 → 무시")
            ScanCallback.SCAN_FAILED_ALREADY_STARTED -> {
                markInsuranceScanActive(context)
                debugLog(TAG, "OS 위임 BLE 스캔 이미 실행 중 (ALREADY_STARTED) → active 상태 유지")
            }
            else -> recoverInsuranceScanAfterScanError(context, errorCode)
        }
    }

    private fun recoverInsuranceScanAfterScanError(context: Context, errorCode: Int) {
        warnLog(TAG, "OS 위임 BLE 스캔 결과 없이 errorCode 수신 → 보험 스캔 복구 시도")
        safeCancelInsuranceScan(context)

        if (!canStartWakeForegroundService(context)) return

        val serviceIntent = Intent(context, BeaconDetectionService::class.java).apply {
            action = BeaconDetectionService.ACTION_RECOVER_INSURANCE_SCAN
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                putExtra(BluetoothLeScanner.EXTRA_ERROR_CODE, errorCode)
            }
        }
        startBeaconDetectionService(context, serviceIntent)
    }

    private fun canStartWakeForegroundService(context: Context): Boolean {
        // Android 12+: ACCESS_BACKGROUND_LOCATION이 grant 안 되면 FGS 시작 불가
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true

        val hasBgLocation = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_BACKGROUND_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasBgLocation) {
            warnLog(
                TAG,
                "ACCESS_BACKGROUND_LOCATION 미허용 — FGS 시작 불가. " +
                        "마더앱에서 위치 권한을 '항상 허용'으로 설정해야 앱 종료 후에도 비콘 감지가 가능합니다."
            )
        }
        return hasBgLocation
    }

    private fun startBeaconDetectionService(context: Context, serviceIntent: Intent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {
            // ForegroundServiceStartNotAllowedException 등 — 크래시 방지
            warnLog(TAG, "FGS 시작 실패 (백그라운드 제한): ${e.message}")
            safeCancelInsuranceScan(context)
        }
    }

    private fun getPendingIntentScanErrorCode(intent: Intent): Int? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null
        if (!intent.hasExtra(BluetoothLeScanner.EXTRA_ERROR_CODE)) return null

        return intent.getIntExtra(BluetoothLeScanner.EXTRA_ERROR_CODE, -1)
            .takeIf { it != -1 }
    }

    // BeaconDetectionService.shouldEnableInsuranceScan()과 의도적으로 동일 조건을 이중 체크.
    // 등록(서비스 프로세스)과 wake-up(kill 후 새 프로세스) 사이에 exemption 해제 가능.
    private fun shouldAllowInsuranceWakeUp(context: Context): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.isIgnoringBatteryOptimizations(context.packageName)
    }

    private fun safeCancelInsuranceScan(context: Context) {
        BeaconDetectionService.invalidateInsuranceScanRegistration()
        try {
            cancelInsuranceScan(context)
        } catch (e: Throwable) {
            warnLog(TAG, "cancelInsuranceScan 예외: ${e.javaClass.name}: ${e.message}")
        }
    }

    companion object {
        private val TAG = "BeaconWakeReceiver ${BuildConfig.SIGNATURE}"
        const val ACTION_BEACON_WAKE = "com.ghostpasssdk.action.BEACON_WAKE"
        const val WAKE_SCAN_REQUEST_CODE = 0xBEAC
        private const val PREFS_NAME = "gopass_beacon_wake"
        private const val KEY_SCAN_ACTIVE = "insurance_scan_active"

        internal fun enableComponent(context: Context) {
            runCatching {
                val component = ComponentName(context, BeaconWakeReceiver::class.java)
                context.packageManager.setComponentEnabledSetting(
                    component,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )
            }.onFailure { e ->
                warnLog(TAG, "보험 스캔 receiver 활성화 실패: ${e.message}")
            }
        }

        internal fun disableComponent(context: Context) {
            runCatching {
                val component = ComponentName(context, BeaconWakeReceiver::class.java)
                context.packageManager.setComponentEnabledSetting(
                    component,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }.onFailure { e ->
                warnLog(TAG, "보험 스캔 receiver 비활성화 실패: ${e.message}")
            }
        }

        /** 보험 스캔 등록 성공 시 호출 — onReceive에서 잔여 배달을 허용하도록 플래그 설정 */
        internal fun markInsuranceScanActive(context: Context) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SCAN_ACTIVE, true)
                .commit()
        }

        private fun isInsuranceScanActive(context: Context): Boolean {
            return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_SCAN_ACTIVE, false)
        }

        /**
         * 보험 스캔을 완전히 취소한다. 4중 방어:
         *
         * 0) SharedPreferences 플래그 즉시 해제 (commit) — 이후 onReceive에서 early-return.
         *    OS BLE 배치 지연이나 Samsung BLE 스택의 PendingIntent.cancel() 미준수에도 대응.
         * 1) PendingIntent를 컴포넌트 비활성화 **전에** 생성 (disabled 상태에서의 resolve 문제 회피)
         * 2) stopScan(pi) — OS BLE 하드웨어 스캔 해제 시도
         * 3) pi.cancel() — stopScan이 실패(BT OFF·SecurityException 등)해도 토큰 자체를 무효화
         * 4) 컴포넌트 비활성화 — 최후 방어선
         *
         * BroadcastReceiver·Service 양쪽에서 호출 가능.
         */
        @SuppressLint("MissingPermission")
        internal fun cancelInsuranceScan(context: Context) {
            // ── 0. 플래그 즉시 해제 — commit으로 디스크 반영 (프로세스 재시작에도 안전) ──
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SCAN_ACTIVE, false)
                .commit()

            // ── 1. PendingIntent를 컴포넌트 비활성화 전에 확보 ──
            val intent = Intent(context, BeaconWakeReceiver::class.java).apply {
                action = ACTION_BEACON_WAKE
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
            val pi = PendingIntent.getBroadcast(
                context, WAKE_SCAN_REQUEST_CODE, intent, flags
            )

            // ── 2. OS BLE 스캔 해제 시도 (BT OFF면 scanner == null → skip) ──
            runCatching {
                val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
                bm?.adapter?.bluetoothLeScanner?.stopScan(pi)
            }.onFailure { e ->
                warnLog(TAG, "보험 스캔 stopScan 실패 (BT OFF 등): ${e.message}")
            }

            // ── 3. PendingIntent 토큰 무효화 — stopScan 실패 시에도 OS 배달 차단 ──
            pi.cancel()

            // ── 4. 컴포넌트 비활성화 ──
            disableComponent(context)

            debugLog(TAG, "보험 스캔 취소 완료")
        }
    }
}
