package com.ghostpasssdk.gopasssdk.data.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.infra.SignedRequestPreflightChecker
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.core.network.utils.safeApiCall
import com.ghostpasssdk.gopasssdk.core.network.utils.safeApiCallNoData
import com.ghostpasssdk.gopasssdk.data.api.SessionApi
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionRequest
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionResultRequest
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionResultPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionParams
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository

internal class SessionRepositoryImpl(
    private val sessionApi: SessionApi,
    private val signedRequestPreflightChecker: SignedRequestPreflightChecker
) : SessionRepository {
    override suspend fun sessions(
        params: SessionParams
    ): ApiResult<EncryptedSession> {
        signedRequestPreflightChecker.ensureSessionReady()
        val requestDto = SessionRequest(
            beaconMajor = params.major,
            beaconMinor = params.minor,
            beaconRssi = params.rssi
        )
        return safeApiCall({ sessionApi.requestSession(requestDto) }) { it.toDomain() }
    }

    override suspend fun deleteSession(sessionId: String): ApiResult<Unit> {
        signedRequestPreflightChecker.ensureSessionReady()
        return safeApiCallNoData { sessionApi.deleteSession(sessionId) }
    }

    override suspend fun submitResult(
        sessionId: String,
        success: Boolean,
        similarityScore: Float
    ): ApiResult<SessionResultPayload> {
        signedRequestPreflightChecker.ensureSessionReady()
        return safeApiCall(
            call = {
                sessionApi.submitSessionResult(
                    sessionId = sessionId,
                    body = SessionResultRequest(
                        success = success,
                        similarityScore = similarityScore
                    )
                )
            },
            mapper = { it.toDomain() }
        )
    }
}
