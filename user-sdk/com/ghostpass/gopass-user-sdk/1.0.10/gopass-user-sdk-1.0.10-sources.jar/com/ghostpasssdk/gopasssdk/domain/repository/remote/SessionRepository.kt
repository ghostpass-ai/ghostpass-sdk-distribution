package com.ghostpasssdk.gopasssdk.domain.repository.remote

import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.EncryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionResultPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.SessionParams

internal interface SessionRepository {
    suspend fun sessions(params: SessionParams): ApiResult<EncryptedSession>
    suspend fun deleteSession(sessionId: String): ApiResult<Unit>
    suspend fun submitResult(sessionId: String, success: Boolean, similarityScore: Float): ApiResult<SessionResultPayload>
}
