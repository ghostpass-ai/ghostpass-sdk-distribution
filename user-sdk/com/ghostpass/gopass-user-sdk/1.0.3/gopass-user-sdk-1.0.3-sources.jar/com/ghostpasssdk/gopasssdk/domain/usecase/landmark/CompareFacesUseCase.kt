package com.ghostpasssdk.gopasssdk.domain.usecase.landmark

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceCompareEngine
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.useAndWipe
import com.ghostpasssdk.gopasssdk.utils.wipe

internal class CompareFacesUseCase(
    private val landmarkRepository: LandmarkRepository,
    private val faceCompareEngine: FaceCompareEngine
) {
    companion object {
        private val TAG = "CompareFacesUseCase ${BuildConfig.SIGNATURE}"
        private const val VALID_COMPUTE_DISTANCE_VALUE = 0.3f
    }

    suspend fun execute(targetVector: FloatArray): Boolean {
        val sourceVector: FloatArray = landmarkRepository.loadLandmark()

        return sourceVector.useAndWipe { source ->
            val distance = faceCompareEngine.compare(
                sourceVector = source,
                targetVector = targetVector
            )
            debugLog(TAG, "거리 계산 결과 : $distance")

            distance < VALID_COMPUTE_DISTANCE_VALUE
        }.also {
            debugLog(TAG, "🛡️ [보안] 로컬 생체 벡터 데이터(Source) 메모리 즉시 소각 완료")
        }
    }
}
