package com.ghostpasssdk.gopasssdk.domain.usecase.landmark

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceCompareEngine
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.RuntimeFlowErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.landmark.CompareResult
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.errorlog.RuntimeFlowErrorReporter
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.infoLog
import com.ghostpasssdk.gopasssdk.utils.useAndWipe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class CompareFacesUseCase(
    private val landmarkRepository: LandmarkRepository,
    private val faceCompareEngine: FaceCompareEngine,
    private val errorReporter: RuntimeFlowErrorReporter
) {
    companion object {
        private val TAG = "CompareFacesUseCase ${BuildConfig.SIGNATURE}"
        private const val VALID_COMPUTE_DISTANCE_VALUE = 0.3f
    }

    suspend fun execute(targetVector: FloatArray, sessionId: String? = null): CompareResult {
        if (targetVector.isEmpty()) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.RECEIVED_VECTOR_EMPTY,
                message = "수신 벡터 비어 있음",
                sessionId = sessionId
            )
            return CompareResult(isSuccess = false, similarityScore = 1.0f)
        }

        val loadStartNanos = System.nanoTime()
        val sourceVector: FloatArray = try {
            landmarkRepository.loadLandmark()
        } catch (e: Exception) {
            errorLog(TAG, "저장 생체 데이터 로드 실패: ${e.message}")
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.STORED_BIOMETRIC_LOAD_FAILED,
                message = "저장 생체 데이터 로드 실패: ${e.message}",
                sessionId = sessionId
            )
            return CompareResult(isSuccess = false, similarityScore = 1.0f)
        }
        val loadElapsed = (System.nanoTime() - loadStartNanos) / 1_000_000
        debugLog(TAG, "[FACE_AUTH][LANDMARK] 랜드마크 로드/복호화 완료 (${loadElapsed}ms)")

        if (sourceVector.isEmpty()) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.STORED_BIOMETRIC_PARSE_EMPTY,
                message = "저장 생체 데이터 파싱 결과 비어 있음",
                sessionId = sessionId
            )
            return CompareResult(isSuccess = false, similarityScore = 1.0f)
        }

        if (sourceVector.size != targetVector.size) {
            errorReporter.report(
                errorCode = RuntimeFlowErrorCode.VECTOR_LENGTH_MISMATCH,
                message = "벡터 길이 불일치: source=${sourceVector.size}, target=${targetVector.size}",
                sessionId = sessionId
            )
        }

        return sourceVector.useAndWipe { source ->
            val compareStartNanos = System.nanoTime()
            val distance = withContext(Dispatchers.Default) {
                faceCompareEngine.compare(
                    sourceVector = source,
                    targetVector = targetVector
                )
            }
            val compareElapsed = (System.nanoTime() - compareStartNanos) / 1_000_000
            infoLog(TAG, "[FACE_AUTH][COMPARE] 벡터 비교 완료 (${compareElapsed}ms, distance=$distance)")

            CompareResult(
                isSuccess = distance < VALID_COMPUTE_DISTANCE_VALUE,
                similarityScore = distance
            )
        }.also {
            debugLog(TAG, "🛡️ [보안] 로컬 생체 벡터 데이터(Source) 메모리 즉시 소각 완료")
        }
    }
}
