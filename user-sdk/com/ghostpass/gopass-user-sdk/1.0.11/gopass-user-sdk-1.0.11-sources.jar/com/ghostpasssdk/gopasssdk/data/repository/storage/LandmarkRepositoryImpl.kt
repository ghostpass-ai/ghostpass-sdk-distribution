package com.ghostpasssdk.gopasssdk.data.repository.storage

import android.content.Context
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.security.infra.LocalDataEncryptor
import com.ghostpasssdk.gopasssdk.domain.model.external.HasBioDataResult
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.utils.formatRegisteredAt
import com.ghostpasssdk.gopasssdk.utils.errorLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

internal class LandmarkRepositoryImpl(
    private val context: Context,
    private val localDataEncryptor: LocalDataEncryptor,
    private val identityRepository: IdentityRepository
) : LandmarkRepository {

    companion object {
        private val TAG = "LandmarkRepository ${BuildConfig.SIGNATURE}"
        private const val FILE_NAME = "biometric_feature.enc"
    }

    private val file get() = File(context.filesDir, FILE_NAME)

    override suspend fun saveLandmark(landmark: FloatArray) = withContext(Dispatchers.IO) {
        val plainText = landmark.joinToString(",")

        val encrypted = try {
            localDataEncryptor.encryptStrongBox(plainText)
        } catch (e: Exception) {
            errorLog(TAG, "랜드마크 암호화 실패: $e")
            throw GoPassException.from(
                error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                internalCode = InternalErrorCode.BIO_DATA_ENCRYPT_FAILED
            )
        }

        try {
            file.writeText(encrypted)

            // writeText doesn't return a boolean, so we verify existence and size
            if (!file.exists() || file.length() == 0L) {
                errorLog(TAG, "랜드마크 파일 쓰기 실패 (파일이 없거나 비어있음)")
                throw GoPassException.from(
                    error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                    internalCode = InternalErrorCode.BIO_DATA_SAVE_FAILED
                )
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "랜드마크 저장 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = ErrorCode.REGISTER_BIO_DATA_FAILED,
                internalCode = InternalErrorCode.BIO_DATA_SAVE_FAILED
            )
        }
    }

    override suspend fun deleteLandmark(): Boolean = withContext(Dispatchers.IO) {
        try {
            if (file.exists()) {
                val isDeleted = file.delete()
                if (!isDeleted) {
                    errorLog(TAG, "랜드마크 파일 삭제 실패 (delete=false)")
                    throw GoPassException.from(
                        error = ErrorCode.REMOVE_BIO_DATA_FAILED
                    )
                }
                return@withContext true
            } else {
                return@withContext true
            }
        } catch (e: GoPassException) {
            throw e
        } catch (e: Exception) {
            errorLog(TAG, "랜드마크 삭제 중 시스템 예외 발생: $e")
            throw GoPassException.from(
                error = ErrorCode.REMOVE_BIO_DATA_FAILED
            )
        }
    }

    override fun hasLandmark(): Boolean = file.exists()

    override fun getHasBioDataResult(): HasBioDataResult {
        val hasBioData = hasLandmark()
        return HasBioDataResult(
            hasBioData = hasBioData,
            registeredAt = if (hasBioData) {
                identityRepository.getRegisteredAt()?.let(::formatRegisteredAt)
            } else {
                null
            }
        )
    }

    override suspend fun loadLandmark(): FloatArray = withContext(Dispatchers.IO) {
        val encrypted = file.readText()
        val decryptedPlainText = localDataEncryptor.decryptStrongBox(encrypted)
        decryptedPlainText.split(",").map { it.toFloat() }.toFloatArray()
    }
}
