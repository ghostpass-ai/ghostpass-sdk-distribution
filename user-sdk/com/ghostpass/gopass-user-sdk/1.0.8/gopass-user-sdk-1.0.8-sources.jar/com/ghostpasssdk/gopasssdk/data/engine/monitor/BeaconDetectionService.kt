package com.ghostpasssdk.gopasssdk.data.engine.monitor

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.ghostpasssdk.gopasssdk.R
import com.ghostpasssdk.gopasssdk.core.device.observer.DeviceStateObserver
import com.ghostpasssdk.gopasssdk.domain.usecase.device.CheckAllConditionsUseCase
import com.ghostpasssdk.gopasssdk.internal.di.SdkContainer
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.infoLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

internal class BeaconDetectionService : Service() {

    companion object {
        private val TAG = "BeaconDetectionService ${BuildConfig.SIGNATURE}"
        const val ACTION_STOP_FOREGROUND = "com.ghostpasssdk.action.STOP_FOREGROUND"
        const val ACTION_PROCESS_PENDING_SCAN_RESULTS =
            "com.ghostpasssdk.action.PROCESS_PENDING_SCAN_RESULTS"
        const val EXTRA_PENDING_SCAN_RESULTS = "com.ghostpasssdk.extra.PENDING_SCAN_RESULTS"
        private const val SERVICE_CHANNEL_ID = "beacon_channel_v2"
        private const val SERVICE_NOTIFICATION_ID = 2
        private const val RSSI_THRESHOLD_MIN = -85
        private const val RSSI_THRESHOLD_MAX = 0
        // per-beacon 침묵 타이머: 개별 비콘(major_minor)이 이 시간 동안 미수신 시 해당 세션 삭제
        private const val BEACON_SILENCE_TIMEOUT_MS = 20_000L
        private const val INSURANCE_SCAN_REPORT_DELAY_MS = 10_000L
        private const val BEACON_HIT_DEDUP_WINDOW_NANOS = 300_000_000L
        /**
         * Samsung BLE scan throttling 대응: 장시간 연속 스캔 시 OS가 duty cycle을
         * 점진적으로 줄이므로, 주기적으로 scan을 stop/start하여 throttling 카운터를 리셋한다.
         */
        private const val SCAN_REFRESH_INTERVAL_MS = 5 * 60 * 1000L // 5분
        private const val SCAN_WAKE_LOCK_TIMEOUT_MS = 30_000L
        private const val SCAN_WAKE_LOCK_RENEW_MS = 20_000L
        private const val APPLE_COMPANY_ID = 0x004C
        private const val META_NOTIFICATION_ICON = "com.ghostpasssdk.notification_icon"
        private const val META_NOTIFICATION_TITLE = "com.ghostpasssdk.notification_title"
        private const val META_NOTIFICATION_TEXT = "com.ghostpasssdk.notification_text"
        private const val META_NOTIFICATION_TITLE_WAIT = "com.ghostpasssdk.notification_title_wait"
        private const val META_NOTIFICATION_TITLE_PAUSED = "com.ghostpasssdk.notification_title_paused"

        private val scanning = AtomicBoolean(false)

        /** BeaconWakeReceiver가 서비스 생존 여부를 판단하는 플래그 */
        @Volatile
        var isServiceAlive = false
            private set

        private val insuranceScanRegistered = AtomicBoolean(false)
    }

    private lateinit var checkAllConditionsUseCase: CheckAllConditionsUseCase
    private lateinit var notificationManager: NotificationManager
    private var wakeLock: PowerManager.WakeLock? = null
    private var wakeLockRenewJob: Job? = null
    private var scanRefreshJob: Job? = null
    private var healthCheckJob: Job? = null
    private lateinit var scanRefreshHealthCheck: ScanRefreshHealthCheck
    private var isScreenStateReceiverRegistered = false

    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private var targetUuid: UUID? = null
    private val lastAcceptedHitTimestamps = mutableMapOf<String, Long>()
    private val rssiFilters = mutableMapOf<String, RssiKalmanFilter>()

    /**
    isBeaconVisible / perBeaconSilenceJobs은 모든 접근 경로가 Main 스레드로 통일되어 있어
    별도 동기화 없이 단일 스레드 보장으로 스레드 안전성을 확보한다.
    - processScanResult: mainScope.launch → Main
    - stopBeaconScanning: onStartCommand/onDestroy/deviceStateObserver 전부 Main
    - handleScanFailed: Binder 스레드이나, 해당 필드 접근은 mainScope.launch 내부에서만 수행
     **/
    private var isBeaconVisible = false
    private val perBeaconSilenceJobs = mutableMapOf<String, Job>()

    private lateinit var container: SdkContainer
    private lateinit var deviceStateObserver: DeviceStateObserver

    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val powerManager by lazy { getSystemService(POWER_SERVICE) as PowerManager }

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF,
                Intent.ACTION_SCREEN_ON,
                Intent.ACTION_USER_PRESENT -> mainScope.launch {
                    syncScanWakeLock()
                }
            }
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            mainScope.launch { processScanResult(result, ScanResultSource.CALLBACK) }
        }

        override fun onScanFailed(errorCode: Int) {
            handleScanFailed(errorCode)
        }
    }

    /**
    @Synchronized: Binder 스레드에서 호출되므로 scanning / bluetoothLeScanner 보호 필요.
    isBeaconVisible / perBeaconSilenceJobs 접근은 mainScope.launch 내부에서만 수행하여 Main 스레드 통일.
     **/
    @Synchronized
    private fun handleScanFailed(errorCode: Int) {
        // SCAN_FAILED_ALREADY_STARTED(1): 스캔이 이미 실행 중 — 정상 상태이므로 무시
        // onScanFailed는 main looper로 비동기 전달되므로, stale callback이 멈춘 상태를 되살리면 안 된다.
        if (errorCode == ScanCallback.SCAN_FAILED_ALREADY_STARTED) {
            debugLog(TAG, "BLE 스캔 이미 실행 중 (ALREADY_STARTED) → 무시")
            return
        }

        errorLog(TAG, "BLE 스캔 실패: errorCode=$errorCode")
        scanning.set(false)
        targetUuid = null
        bluetoothLeScanner = null
        stopScanWakeLock()
        BeaconServiceEvents.clearScanStartEvents()
        BeaconServiceEvents.notifyScanStartFailed("BLE 스캔 실패: errorCode=$errorCode")
        BeaconServiceEvents.notifyScanStopped()
        mainScope.launch {
            val wasInRegion = isBeaconVisible
            perBeaconSilenceJobs.values.forEach { it.cancel() }
            perBeaconSilenceJobs.clear()
            isBeaconVisible = false
            lastAcceptedHitTimestamps.clear()
            rssiFilters.clear()
            if (wasInRegion) {
                BeaconServiceEvents.notifyBeaconLost()
            }
        }
    }

    private fun processScanResult(result: ScanResult, source: ScanResultSource) {
        if (!scanning.get()) return

        val scanRecord = result.scanRecord ?: return
        val manufacturerData = scanRecord.getManufacturerSpecificData(APPLE_COMPANY_ID) ?: return
        val iBeacon = parseIBeacon(manufacturerData) ?: return

        // 스캐너 생존 확인 — 임의 iBeacon 콜백이면 스캐너가 동작 중인 것.
        // UUID 필터 전에 마킹하여, 타깃 비콘 부재 시에도 스캐너 상태를 정확히 판정한다.
        if (source == ScanResultSource.CALLBACK) {
            scanRefreshHealthCheck.onCallbackReceived()
        }

        val target = targetUuid ?: return
        if (iBeacon.uuid != target) return

        // per-beacon 침묵 타이머 관리
        val beaconKey = "${iBeacon.major}_${iBeacon.minor}"
        val isFirstBeacon = perBeaconSilenceJobs.isEmpty()
        perBeaconSilenceJobs[beaconKey]?.cancel()

        if (isFirstBeacon) {
            isBeaconVisible = true
            debugLog(TAG, "beaconAppeared: UUID=${iBeacon.uuid}")
            BeaconServiceEvents.notifyBeaconAppeared()
        }

        perBeaconSilenceJobs[beaconKey] = mainScope.launch {
            delay(BEACON_SILENCE_TIMEOUT_MS)
            perBeaconSilenceJobs.remove(beaconKey)
            lastAcceptedHitTimestamps.remove(beaconKey)
            rssiFilters.remove(beaconKey)
            warnLog(TAG, "beaconSilent: $beaconKey (${BEACON_SILENCE_TIMEOUT_MS}ms 무신호)")
            BeaconServiceEvents.notifyBeaconSilent(iBeacon.major, iBeacon.minor)

            if (perBeaconSilenceJobs.isEmpty()) {
                isBeaconVisible = false
                warnLog(TAG, "🤫 beaconLost: 모든 비콘 침묵")
                BeaconServiceEvents.notifyBeaconLost()
            }
        }

        val rawRssi = result.rssi
        val smoothedRssi = rssiFilters.getOrPut(beaconKey) { RssiKalmanFilter() }
            .update(rawRssi)

        if (smoothedRssi in RSSI_THRESHOLD_MIN..RSSI_THRESHOLD_MAX) {
            if (isDuplicateBeaconHit(iBeacon, result.timestampNanos)) {
                debugLog(
                    TAG,
                    "중복 비콘 hit 무시: source=$source, Major=${iBeacon.major}, Minor=${iBeacon.minor}, smoothed=$smoothedRssi"
                )
                return
            }

            debugLog(
                TAG,
                "⚡️유효 RSSI 진입: source=$source, Major=${iBeacon.major}, Minor=${iBeacon.minor}, smoothed=$smoothedRssi (raw=$rawRssi, threshold=$RSSI_THRESHOLD_MIN)"
            )
            BeaconServiceEvents.notifyBeaconDetected(iBeacon.major, iBeacon.minor, smoothedRssi)
        } else {
            infoLog(
                TAG,
                "RSSI 범위 밖: source=$source, Major=${iBeacon.major}, Minor=${iBeacon.minor}, smoothed=$smoothedRssi (raw=$rawRssi, threshold=$RSSI_THRESHOLD_MIN..$RSSI_THRESHOLD_MAX)"
            )
            BeaconServiceEvents.notifyBeaconOutOfRange(iBeacon.major, iBeacon.minor, smoothedRssi)
        }
    }

    private fun isDuplicateBeaconHit(iBeacon: IBeaconData, timestampNanos: Long): Boolean {
        val beaconKey = "${iBeacon.major}_${iBeacon.minor}"
        val lastAccepted = lastAcceptedHitTimestamps[beaconKey]
        if (lastAccepted != null && timestampNanos <= lastAccepted + BEACON_HIT_DEDUP_WINDOW_NANOS) {
            return true
        }

        lastAcceptedHitTimestamps[beaconKey] = timestampNanos
        return false
    }

    private data class IBeaconData(
        val uuid: UUID,
        val major: Int,
        val minor: Int,
        val txPower: Int
    )

    private enum class ScanResultSource {
        CALLBACK,
        OS_DELEGATED
    }

    private fun parseIBeacon(manufacturerData: ByteArray): IBeaconData? {
        // iBeacon manufacturer specific data (Apple company ID 이후):
        // Byte 0: 비콘 타입 (0x02)
        // Byte 1: 데이터 길이 (0x15 = 21)
        // Bytes 2-17: UUID (16 bytes)
        // Bytes 18-19: Major (2 bytes, big-endian)
        // Bytes 20-21: Minor (2 bytes, big-endian)
        // Byte 22: TX Power (1 byte, signed)
        if (manufacturerData.size < 23) return null
        if (manufacturerData[0] != 0x02.toByte() || manufacturerData[1] != 0x15.toByte()) return null

        val uuidBuffer = ByteBuffer.wrap(manufacturerData, 2, 16)
        val uuid = UUID(uuidBuffer.long, uuidBuffer.long)

        val major = ((manufacturerData[18].toInt() and 0xFF) shl 8) or
                (manufacturerData[19].toInt() and 0xFF)
        val minor = ((manufacturerData[20].toInt() and 0xFF) shl 8) or
                (manufacturerData[21].toInt() and 0xFF)
        val txPower = manufacturerData[22].toInt()

        return IBeaconData(uuid, major, minor, txPower)
    }

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                SERVICE_CHANNEL_ID,
                "Beacon Scanning",
                NotificationManager.IMPORTANCE_MIN
            )
            notificationManager.createNotificationChannel(ch)
        }
    }

    private fun getAppMetaData(): android.os.Bundle? {
        return packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA).metaData
    }

    private fun getNotificationIcon(): Int {
        val icon = getAppMetaData()?.getInt(META_NOTIFICATION_ICON, 0) ?: 0
        return if (icon != 0) icon else applicationInfo.icon
    }

    private fun getMetaString(name: String): String? {
        val metaData = getAppMetaData() ?: return null
        val resourceId = metaData.getInt(name, 0)
        if (resourceId != 0) {
            return runCatching { getString(resourceId) }.getOrNull()?.takeIf { it.isNotBlank() }
        }

        return metaData.getString(name)?.takeIf { it.isNotBlank() }
    }

    private fun getNotificationTitle(): String {
        return getMetaString(META_NOTIFICATION_TITLE)
            ?: getString(R.string.notif_1)
    }

    private fun getNotificationText(): String {
        return getMetaString(META_NOTIFICATION_TEXT)
            ?: getString(R.string.notif_2)
    }

    private fun getNotificationTitleWait(): String {
        return getMetaString(META_NOTIFICATION_TITLE_WAIT)
            ?: getMetaString(META_NOTIFICATION_TITLE_PAUSED)
            ?: getString(R.string.notification_title_paused)
    }

    private fun buildServiceNotification(
        title: String = getNotificationTitle(),
        text: String = getNotificationText()
    ): Notification {
        return NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
            .setSmallIcon(getNotificationIcon())
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setAutoCancel(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_DEFERRED)
            .build().apply {
                flags = flags or Notification.FLAG_NO_CLEAR or Notification.FLAG_ONGOING_EVENT
            }
    }

    override fun onCreate() {
        super.onCreate()
        isServiceAlive = true
        scanning.set(false)
        scanRefreshHealthCheck = ScanRefreshHealthCheck(this)
        debugLog(TAG, "onCreate: 호출")

        // ── 1단계: startForeground 최우선 호출 (5초 타임아웃 크래시 방지) ──
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannelIfNeeded()
        val initial = buildServiceNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val types = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                startForeground(SERVICE_NOTIFICATION_ID, initial, types)
            } else {
                startForeground(SERVICE_NOTIFICATION_ID, initial)
            }
        } catch (e: Exception) {
            errorLog(TAG, "startForeground 실패 — 조용히 종료: ${e.message}")
            runCatching { BeaconWakeReceiver.cancelInsuranceScan(applicationContext) }
                .onFailure { warnLog(TAG, "보험 스캔 취소 실패: ${it.message}") }
            stopSelf()
            return
        }

        // ── 2단계: SDK 컨테이너 초기화 (보험 스캔 wake-up 시 실패할 수 있음) ──
        try {
            container = SdkContainer.getOrCreate(applicationContext)
            checkAllConditionsUseCase = container.checkAllConditionsUseCase
            container.ensureProximityLifecycle()
        } catch (e: Exception) {
            errorLog(TAG, "SDK 초기화 실패 (보험 스캔 wake-up 추정) — 서비스 종료: ${e.message}")
            runCatching { BeaconWakeReceiver.cancelInsuranceScan(applicationContext) }
                .onFailure { warnLog(TAG, "보험 스캔 취소 실패: ${it.message}") }
            removeForegroundNotification()
            stopSelf()
            return
        }

        registerScreenStateReceiver()

        // ── 3단계: 상태 감지 옵저버 시작 ──
        // 모든 콜백을 Main dispatcher로 통일 (NET_CHANGED는 ConnectivityThread에서 올 수 있음)
        deviceStateObserver = DeviceStateObserver(this) { reason ->
            mainScope.launch {
                if (reason == "BT_ON") delay(1000)
                updateScanningState(reason)
            }
        }
        deviceStateObserver.startObserving()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_FOREGROUND) {
            warnLog(TAG, "onStartCommand STOP requested")
            stopForegroundAndService()
            return START_STICKY
        }

        // SDK 초기화 실패로 container가 미초기화 상태일 수 있음 (보험 스캔 wake-up 후 stopSelf 대기 중)
        if (!::container.isInitialized) return START_STICKY

        if (intent?.action == ACTION_PROCESS_PENDING_SCAN_RESULTS) {
            updateScanningState(reason = "pendingIntentScan")
            processPendingIntentScanResults(intent)
            return START_STICKY
        }

        updateScanningState(reason = "onStartCommand")
        return START_STICKY
    }

    private fun processPendingIntentScanResults(intent: Intent) {
        val results = getPendingScanResults(intent)
        if (results.isEmpty()) {
            val errorCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                intent.hasExtra(BluetoothLeScanner.EXTRA_ERROR_CODE)
            ) {
                intent.getIntExtra(BluetoothLeScanner.EXTRA_ERROR_CODE, -1)
            } else {
                null
            }
            warnLog(TAG, "OS 위임 스캔 결과 없음 (errorCode=$errorCode)")
            return
        }

        debugLog(TAG, "OS 위임 스캔 결과 처리: ${results.size}건")
        results.forEach { processScanResult(it, ScanResultSource.OS_DELEGATED) }
    }

    private fun getPendingScanResults(intent: Intent): List<ScanResult> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra(
                EXTRA_PENDING_SCAN_RESULTS,
                ScanResult::class.java
            )
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableArrayListExtra(EXTRA_PENDING_SCAN_RESULTS)
        } ?: emptyList()
    }

    private fun updateScanningState(reason: String) {
        val result = checkAllConditionsUseCase()
        if (result.ok) {
            startBeaconScanning()
            notificationManager.notify(SERVICE_NOTIFICATION_ID, buildServiceNotification())
        } else {
            stopBeaconScanning("조건 미충족: $reason")
            val title = getNotificationTitleWait()
            val text = when (result.missing) {
                CheckAllConditionsUseCase.Missing.Bluetooth -> getString(R.string.notification_bluetooth)
                CheckAllConditionsUseCase.Missing.Gps -> getString(R.string.notification_gps)
                CheckAllConditionsUseCase.Missing.Network -> getString(R.string.notification_network)
                else -> getString(R.string.notification_else)
            }
            notificationManager.notify(
                SERVICE_NOTIFICATION_ID,
                buildServiceNotification(title, text)
            )
            BeaconServiceEvents.notifyMonitorReady()
        }
    }

    /**
    @Synchronized는 scanning / bluetoothLeScanner를 Binder 스레드(handleScanFailed)와의
    동시 접근으로부터 보호하기 위한 것이다. isBeaconVisible / perBeaconSilenceJobs은 Main 스레드 전용.
     **/
    @SuppressLint("MissingPermission")
    @Synchronized
    private fun startBeaconScanning() {
        if (scanning.get()) {
            syncInsuranceScanRegistration()
            BeaconServiceEvents.notifyScanStarted()
            return
        }

        val uuidStr = container.identityRepository.getBeaconUuid()
        if (uuidStr.isNullOrBlank()) {
            warnLog(TAG, "저장된 비콘 UUID가 없어 스캔을 시작할 수 없습니다.")
            mainScope.launch { BeaconServiceEvents.notifyScanStartFailed("UUID 누락으로 인한 서비스 종료") }
            stopForegroundAndService()
            return
        }

        try {
            val target = UUID.fromString(uuidStr)
            targetUuid = target

            if (bluetoothLeScanner == null) {
                val bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
                bluetoothLeScanner = bluetoothManager.adapter?.bluetoothLeScanner
            }

            val scanner = bluetoothLeScanner
            if (scanner == null) {
                errorLog(TAG, "BluetoothLeScanner를 가져올 수 없습니다.")
                mainScope.launch {
                    BeaconServiceEvents.notifyScanStartFailed("BLE 스캐너 초기화 실패")
                }
                return
            }

            // 하드웨어 필터는 iBeacon prefix(2바이트)만 매칭. UUID 특정은 소프트웨어에서 처리.
            // Samsung BLE 컨트롤러에서 긴 manufacturer data 패턴(18바이트+)은
            // 하드웨어 매칭 실패율이 높아 scan result가 누락되는 알려진 이슈가 있다.
            val scanFilter = ScanFilter.Builder()
                .setManufacturerData(
                    APPLE_COMPANY_ID,
                    byteArrayOf(0x02, 0x15),
                    byteArrayOf(0xFF.toByte(), 0xFF.toByte())
                )
                .build()

            /** BALANCED: ~2초 스캔 / ~3초 대기 주기. 종일 상시 실행되는 포그라운드 서비스이므로 배터리 고려.
            키오스크 비콘이 ADVERTISE_MODE_LOW_LATENCY(~100ms 주기)로 브로드캐스트하므로
            단일 스캔 윈도우(~2초) 내에서 TARGET_HIT_COUNT(3회)를 충족한다.
            worst case 레이턴시: 스캔 윈도우 대기 ~5초.
             */
            val scanSettings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_BALANCED)
                .setReportDelay(0)
                .build()

            scanner.startScan(listOf(scanFilter), scanSettings, scanCallback)
            scanning.set(true)
            syncScanWakeLock()
            scheduleScanRefresh()
            BeaconServiceEvents.notifyScanStarted()

            syncInsuranceScanRegistration(scanner, target)

        } catch (e: Exception) {
            errorLog(TAG, "startBeaconScanning 실패: ${e.message}")
            mainScope.launch {
                BeaconServiceEvents.notifyScanStartFailed("BLE 스캔 시작 실패: ${e.message}")
            }
        }
    }

    /**
     * Samsung BLE scan throttling 대응.
     * 장시간 연속 스캔 시 OS가 scan duty cycle을 점진적으로 줄이므로,
     * 주기적으로 scan을 stop→start하여 throttling 카운터를 리셋한다.
     * Region 상태와 hit 카운트는 유지된다.
     *
     * restart 후 [ScanRefreshHealthCheck.HEALTH_CHECK_TIMEOUT_MS] 내 콜백 미수신 시
     * silent failure로 판정하고, 선형 백오프로 stop→start 간 delay를 늘려가며 즉시 재시도한다.
     */
    @SuppressLint("MissingPermission")
    private fun scheduleScanRefresh() {
        scanRefreshJob?.cancel()
        scanRefreshJob = mainScope.launch {
            delay(SCAN_REFRESH_INTERVAL_MS)
            if (!scanning.get()) return@launch

            try {
                performScanRefresh()
            } catch (e: Exception) {
                errorLog(TAG, "스캔 리프레시 예외 발생 — 리프레시 체인 유지: ${e.message}")
                scheduleScanRefresh()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun performScanRefresh() {
        val scanner = bluetoothLeScanner ?: return
        val restartDelay = scanRefreshHealthCheck.currentRestartDelayMs

        debugLog(TAG, "스캔 리프레시: stop → ${restartDelay}ms 대기 → start")
        runCatching { scanner.stopScan(scanCallback) }
        scanning.set(false)

        delay(restartDelay)
        currentCoroutineContext().ensureActive()

        targetUuid ?: return
        val scanFilter = ScanFilter.Builder()
            .setManufacturerData(
                APPLE_COMPANY_ID,
                byteArrayOf(0x02, 0x15),
                byteArrayOf(0xFF.toByte(), 0xFF.toByte())
            )
            .build()
        val scanSettings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_BALANCED)
            .setReportDelay(0)
            .build()

        scanRefreshHealthCheck.onRefreshStarted()
        scanner.startScan(listOf(scanFilter), scanSettings, scanCallback)
        scanning.set(true)
        debugLog(TAG, "스캔 리프레시 완료 (delay=${restartDelay}ms)")

        scheduleHealthCheck()
    }

    private fun scheduleHealthCheck() {
        healthCheckJob?.cancel()
        healthCheckJob = mainScope.launch {
            delay(ScanRefreshHealthCheck.HEALTH_CHECK_TIMEOUT_MS)
            if (!scanning.get()) return@launch

            try {
                // 주변에 iBeacon이 전무한 환경에서는 콜백 자체가 없으므로 health check 무의미.
                // 최근에 비콘을 본 적 있을 때만 판정하여 false-positive 무한 재시도를 방지한다.
                if (!isBeaconVisible) {
                    debugLog(TAG, "health check skip: 비콘 미감지 상태 → 다음 리프레시 예약")
                    scanRefreshHealthCheck.reset()
                    scheduleScanRefresh()
                    return@launch
                }

                val passed = scanRefreshHealthCheck.evaluate()
                if (passed) {
                    scheduleScanRefresh()
                } else {
                    warnLog(TAG, "silent failure 감지 → 즉시 재시도 (다음 delay=${scanRefreshHealthCheck.currentRestartDelayMs}ms)")
                    performScanRefresh()
                }
            } catch (e: Exception) {
                errorLog(TAG, "health check 예외 발생 — 리프레시 체인 유지: ${e.message}")
                scheduleScanRefresh()
            }
        }
    }

    // ── 보험 스캔: 프로세스 종료 후에도 OS BT 칩이 비콘 감지 시 BeaconWakeReceiver를 깨운다 ──

    // BeaconWakeReceiver.shouldAllowInsuranceWakeUp()와 의도적으로 동일 조건을 이중 체크.
    // 등록(서비스 프로세스)과 wake-up(kill 후 새 프로세스) 사이에 exemption 해제 가능.
    private fun shouldEnableInsuranceScan(): Boolean {
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            warnLog(TAG, "보험 스캔 미등록: battery optimization exemption 없음")
            return false
        }

        return true
    }

    private fun syncInsuranceScanRegistration() {
        val scanner = bluetoothLeScanner ?: return
        val uuid = targetUuid ?: return
        syncInsuranceScanRegistration(scanner, uuid)
    }

    private fun syncInsuranceScanRegistration(scanner: BluetoothLeScanner, uuid: UUID) {
        if (shouldEnableInsuranceScan()) {
            // OS 위임 스캔: 화면 꺼짐/프로세스 kill 후에도 BT 칩 매칭 결과를 받을 수 있게 유지한다.
            registerInsuranceScan(scanner, uuid)
        } else {
            unregisterInsuranceScan()
        }
    }

    /**
     * OS BT 하드웨어에 PendingIntent 기반 BLE 스캔을 한 번만 등록한다.
     * ScanFilter에 UUID를 포함시켜 우리 비콘만 매칭되도록 한다.
     * PendingIntent는 BeaconWakeReceiver(BroadcastReceiver)를 타겟하며,
     * 리시버는 서비스 생존 여부와 무관하게 OS 위임 스캔 결과를 FGS로 전달한다.
     */
    @SuppressLint("MissingPermission")
    private fun registerInsuranceScan(scanner: BluetoothLeScanner, uuid: UUID) {
        // startScan(PendingIntent) 오버로드는 API 26+
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            debugLog(TAG, "보험 스캔 미지원: API ${Build.VERSION.SDK_INT} < 26")
            return
        }

        if (!insuranceScanRegistered.compareAndSet(false, true)) {
            debugLog(TAG, "보험 스캔 이미 등록됨 → skip")
            return
        }

        try {
            BeaconWakeReceiver.enableComponent(applicationContext)

            val filter = createIBeaconUuidFilter(uuid)

            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER)
                .setReportDelay(INSURANCE_SCAN_REPORT_DELAY_MS)
                .build()

            val intent = Intent(applicationContext, BeaconWakeReceiver::class.java).apply {
                action = BeaconWakeReceiver.ACTION_BEACON_WAKE
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
            val pi = PendingIntent.getBroadcast(
                applicationContext, BeaconWakeReceiver.WAKE_SCAN_REQUEST_CODE, intent, flags
            )

            scanner.startScan(listOf(filter), settings, pi)
            BeaconWakeReceiver.markInsuranceScanActive(applicationContext)
            debugLog(TAG, "보험 스캔 등록 성공 (OS 위임, LOW_POWER, reportDelay=${INSURANCE_SCAN_REPORT_DELAY_MS}ms)")
        } catch (e: SecurityException) {
            insuranceScanRegistered.set(false)
            BeaconWakeReceiver.disableComponent(applicationContext)
            warnLog(TAG, "보험 스캔 등록 SecurityException: ${e.message}")
        } catch (e: Exception) {
            insuranceScanRegistered.set(false)
            BeaconWakeReceiver.disableComponent(applicationContext)
            warnLog(TAG, "보험 스캔 등록 실패: ${e.message}")
        }
    }

    private fun createIBeaconUuidFilter(uuid: UUID): ScanFilter {
        val uuidBytes = ByteBuffer.allocate(16).apply {
            putLong(uuid.mostSignificantBits)
            putLong(uuid.leastSignificantBits)
        }.array()

        val pattern = ByteArray(2 + 16) // iBeacon prefix(2) + UUID(16)
        val mask = ByteArray(2 + 16)
        pattern[0] = 0x02
        pattern[1] = 0x15
        mask[0] = 0xFF.toByte()
        mask[1] = 0xFF.toByte()
        System.arraycopy(uuidBytes, 0, pattern, 2, 16)
        for (i in 2 until pattern.size) mask[i] = 0xFF.toByte()

        return ScanFilter.Builder()
            .setManufacturerData(APPLE_COMPANY_ID, pattern, mask)
            .build()
    }

    private fun unregisterInsuranceScan() {
        try {
            BeaconWakeReceiver.cancelInsuranceScan(applicationContext)
        } finally {
            insuranceScanRegistered.set(false)
        }
    }

    // @Synchronized: startBeaconScanning과 동일한 이유. 상단 필드 주석 참조.
    @SuppressLint("MissingPermission")
    @Synchronized
    private fun stopBeaconScanning(reason: String) {
        if (!scanning.get()) return

        scanRefreshJob?.cancel()
        scanRefreshJob = null
        healthCheckJob?.cancel()
        healthCheckJob = null
        scanRefreshHealthCheck.reset()
        runCatching { bluetoothLeScanner?.stopScan(scanCallback) }
            .onFailure { e -> errorLog(TAG, "stopScan 에러 ($reason): ${e.message}") }
        // 보험 스캔(PendingIntent)은 해제하지 않음 — 프로세스 kill 후 wake-up 유지

        val wasInRegion = isBeaconVisible
        bluetoothLeScanner = null
        targetUuid = null
        lastAcceptedHitTimestamps.clear()
        rssiFilters.clear()
        perBeaconSilenceJobs.values.forEach { it.cancel() }
        perBeaconSilenceJobs.clear()
        isBeaconVisible = false
        scanning.set(false)
        stopScanWakeLock()

        if (wasInRegion) {
            BeaconServiceEvents.notifyBeaconLost()
        }
        BeaconServiceEvents.notifyScanStopped()
    }

    private fun removeForegroundNotification() {
        try {
            notificationManager.cancel(SERVICE_NOTIFICATION_ID)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (e: Exception) {
            warnLog(TAG, "stop foreground error: ${e.message}")
        }
    }

    /** SDK에서 명시적으로 서비스를 종료할 때만 호출. 보험 스캔도 해제한다. */
    private fun stopForegroundAndService() {
        unregisterInsuranceScan()
        removeForegroundNotification()
        stopSelf()
    }

    /**
     * 앱이 최근 앱 목록에서 스와이프 종료될 때 호출된다.
     * 보험 스캔(PendingIntent → BeaconWakeReceiver)이 OS에 등록되어 있으므로
     * 프로세스 kill 후에도 비콘 감지 시 리시버가 FGS를 기동한다.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        warnLog(TAG, "onTaskRemoved: 앱 스와이프 종료 — 보험 스캔이 OS에 유지됨")
    }

    override fun onDestroy() {
        isServiceAlive = false
        stopBeaconScanning("onDestroy")
        stopScanWakeLock()
        if (::deviceStateObserver.isInitialized) deviceStateObserver.stopObserving()
        unregisterScreenStateReceiver()
        removeForegroundNotification()
        // 보험 스캔은 해제하지 않음 — 프로세스 kill 후에도 OS가 비콘 감지 시 리시버로 FGS 부활
        BeaconServiceEvents.notifyServiceDestroyed()
        mainScope.cancel()
        super.onDestroy()
    }

    private fun registerScreenStateReceiver() {
        if (isScreenStateReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenStateReceiver, filter)
        isScreenStateReceiverRegistered = true
    }

    private fun unregisterScreenStateReceiver() {
        if (!isScreenStateReceiverRegistered) return
        runCatching { unregisterReceiver(screenStateReceiver) }
            .onFailure { e -> warnLog(TAG, "screen receiver 해제 실패: ${e.message}") }
        isScreenStateReceiverRegistered = false
    }

    private fun shouldHoldScanWakeLock(): Boolean {
        return scanning.get() && !powerManager.isInteractive
    }

    private fun syncScanWakeLock() {
        if (shouldHoldScanWakeLock()) {
            startScanWakeLock()
        } else {
            stopScanWakeLock()
        }
    }

    private fun startScanWakeLock() {
        refreshScanWakeLock()
        if (wakeLockRenewJob?.isActive == true) return

        wakeLockRenewJob = mainScope.launch {
            while (true) {
                delay(SCAN_WAKE_LOCK_RENEW_MS)
                if (!shouldHoldScanWakeLock()) {
                    stopScanWakeLock()
                    break
                }
                refreshScanWakeLock()
            }
        }
    }

    private fun refreshScanWakeLock() {
        val lock = wakeLock ?: powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "ghostpass:beacon-scan"
        ).apply {
            setReferenceCounted(false)
        }.also { wakeLock = it }

        // setReferenceCounted(false) WakeLock은 acquire(timeout) 재호출 시
        // AOSP acquireLocked()에서 기존 release 콜백을 removeCallbacks하고
        // 새 timeout을 postDelayed하므로, release 없이 타임아웃이 갱신된다.
        lock.acquire(SCAN_WAKE_LOCK_TIMEOUT_MS)
        debugLog(TAG, "Scan WakeLock refreshed (interactive=${powerManager.isInteractive})")
    }

    private fun stopScanWakeLock() {
        wakeLockRenewJob?.cancel()
        wakeLockRenewJob = null

        wakeLock?.let {
            if (it.isHeld) {
                it.release()
                debugLog(TAG, "Scan WakeLock released")
            }
        }
        wakeLock = null
    }

    override fun onBind(intent: Intent): IBinder? = null
}
