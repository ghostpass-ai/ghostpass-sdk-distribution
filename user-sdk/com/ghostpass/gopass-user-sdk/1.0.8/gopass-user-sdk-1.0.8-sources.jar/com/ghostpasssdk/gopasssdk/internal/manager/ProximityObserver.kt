package com.ghostpasssdk.gopasssdk.internal.manager

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconServiceEvents
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.CompareFacesUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.FetchAndDecryptSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.ProcessSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.UpdateSessionResultUseCase
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.infoLog
import com.ghostpasssdk.gopasssdk.utils.useAndWipe
import com.ghostpasssdk.gopasssdk.utils.verboseLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import javax.security.auth.Destroyable

internal class ProximityObserver(
    private val fetchAndDecryptSessionUseCase: FetchAndDecryptSessionUseCase,
    private val processSessionUseCase: ProcessSessionUseCase,
    private val compareFacesUseCase: CompareFacesUseCase,
    private val updateSessionResultUseCase: UpdateSessionResultUseCase,
    private val sessionRepository: SessionRepository
) {
    companion object {
        private val TAG = "ProximityObserver ${BuildConfig.SIGNATURE}"
        private const val TARGET_HIT_COUNT = 3 // 목표 감지 횟수
        private const val PAYLOAD_GRACE_MILLIS = 10_000L
        private val COOLDOWN_MILLIS = if (BuildConfig.DEBUG) 10 * 1000L else 60 * 1000L
    }

    private val lifecycleScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val isLifecycleInitialized = AtomicBoolean(false)
    private val isListening = AtomicBoolean(false)

    fun initializeLifecycle() {
        if (!isLifecycleInitialized.compareAndSet(false, true)) {
            debugLog(TAG, "Lifecycle collector already initialized")
            return
        }

        lifecycleScope.launch {
            launch {
                BeaconServiceEvents.beaconAppeared.collect {
                    debugLog(TAG, "📡 비콘 감지 시작 -> 옵저버 Listening 시작")
                    startListening()
                }
            }

            launch {
                BeaconServiceEvents.beaconLost.collect {
                    debugLog(TAG, "⏸️ 비콘 미감지 -> 옵저버 Listening 일시 정지")
                    stopListening()
                }
            }

            launch {
                BeaconServiceEvents.scanStopped.collect {
                    debugLog(TAG, "⏸️ 비콘 스캔 중단 감지 -> 옵저버 Listening 일시 정지")
                    stopListening()
                }
            }
            launch {
                BeaconServiceEvents.serviceDestroyed.collect {
                    debugLog(TAG, "🛑 서비스 완전 종료 감지 -> 진행 중 세션 정리 및 Listening 중단")
                    handleServiceDestroyed()
                }
            }

            launch {
                BeaconServiceEvents.beaconOutOfRange.collect { event ->
                    val beaconKey = "${event.major}_${event.minor}"
                    handleBeaconOutOfRange(beaconKey, event.rssi)
                }
            }

            launch {
                BeaconServiceEvents.beaconSilent.collect { event ->
                    val beaconKey = "${event.major}_${event.minor}"
                    handleBeaconSilent(beaconKey)
                }
            }
        }
    }

    private val observerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // 비콘 신호 수집만 전담할 코루틴 Job
    private var collectorJob: Job? = null

    // 비콘 기기별 감지 누적 횟수
    private val hitCounts = ConcurrentHashMap<String, Int>()

    // 비콘 기기별 "세션 획득 ~ RTDB 인증 대기" 전체 과정을 담은 Job
    private val activeSessionJobs = ConcurrentHashMap<String, Job>()

    // 비콘 기기별 활성 세션 ID (세션 삭제 API 호출용)
    private val activeSessionIds = ConcurrentHashMap<String, String>()
    private val cooldownMap = ConcurrentHashMap<String, Long>()

    // ── 세션 정리 공통 헬퍼 ──

    /**
     * 지정한 beaconKey의 세션 관련 로컬 상태를 일괄 정리한다.
     * Job이 존재하면 cancel하고, 관련 맵에서 제거한다.
     * cooldownMap은 제거하지 않는다 — 인증 성공 후 중복 통과 방지를 위해 보존.
     * @return 제거된 sessionId (서버 삭제 필요 시 사용), 없으면 null
     */
    private fun clearBeaconSession(beaconKey: String): String? {
        activeSessionJobs.remove(beaconKey)?.cancel()
        val sessionId = activeSessionIds.remove(beaconKey)
        hitCounts.remove(beaconKey)
        return sessionId
    }

    /**
     * 서버에 세션 삭제 API를 비동기로 호출한다.
     */
    private fun deleteSessionAsync(sessionId: String, tag: String) {
        observerScope.launch {
            runCatching { sessionRepository.deleteSession(sessionId) }
                .onSuccess { debugLog(TAG, "🗑️ 세션 삭제 성공: $sessionId ($tag)") }
                .onFailure { errorLog(TAG, "세션 삭제 실패: $sessionId ($tag) — ${it.message}") }
        }
    }

    fun startListening() {
        if (!isListening.compareAndSet(false, true)) return

        collectorJob = observerScope.launch {
            BeaconServiceEvents.beaconDetected.collect { event ->
                val beaconKey = "${event.major}_${event.minor}"

                val lastFinishedTime = cooldownMap[beaconKey]
                if (lastFinishedTime != null) {
                    if (System.currentTimeMillis() - lastFinishedTime < COOLDOWN_MILLIS) {
                        return@collect
                    } else {
                        cooldownMap.remove(beaconKey)
                    }
                }

                if (activeSessionJobs.containsKey(beaconKey)) return@collect

                val currentCount = hitCounts.merge(beaconKey, 1) { oldVal, _ -> oldVal + 1 } ?: 1
                verboseLog(TAG, "비콘 감지 누적: Key=$beaconKey, 카운트=$currentCount/$TARGET_HIT_COUNT")

                if (currentCount >= TARGET_HIT_COUNT) {
                    hitCounts.remove(beaconKey)
                    handleSessionLifecycle(beaconKey, event.major, event.minor, event.rssi)
                }
            }
        }
    }

    /**
     * FCM으로 전달받은 세션을 비콘 감지 없이 직접 세션 라이프사이클에 주입한다.
     * 복호화는 caller(InfrastructureManager)에서 완료된 상태로 전달받는다.
     * RTDB 관찰 → 얼굴 비교 → 결과 전송 흐름은 비콘 경로와 동일.
     */
    fun delegateSession(decrypted: DecryptedSession) {
        val sessionKey = "fcm_${decrypted.sessionId}"

        val existingJob = activeSessionJobs.putIfAbsent(sessionKey, Job())
        if (existingJob != null) {
            debugLog(TAG, "이미 진행 중인 세션: $sessionKey — 중복 세션 키 파기")
            decrypted.destroySecurely()
            return
        }

        val job = observerScope.launch {
            try {
                debugLog(TAG, "📩 FCM 세션 관찰 시작 (${decrypted.sessionId})")
                activeSessionIds[sessionKey] = decrypted.sessionId
                runSessionObservation(sessionKey, decrypted)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                val isNodeGone = e is GoPassException && e.internalCode == InternalErrorCode.SESSION_NODE_GONE.code
                errorLog(TAG, "FCM 세션 처리 중 에러: ${e.message}")
                if (!isNodeGone) {
                    activeSessionIds[sessionKey]?.let { deleteSessionAsync(it, sessionKey) }
                } else {
                    debugLog(TAG, "💔 세션 노드 소멸 → 로컬 정리만 수행 ($sessionKey)")
                }
            } finally {
                activeSessionJobs.remove(sessionKey)
                activeSessionIds.remove(sessionKey)
                resetBeaconStateForRedetection(decrypted)
                debugLog(TAG, "🧹 FCM 세션 자원 정리 완료 ($sessionKey)")
            }
        }

        activeSessionJobs[sessionKey] = job

        // scope 취소 등으로 코루틴이 즉시 취소된 경우 body 미실행 → destroySecurely 수동 호출
        if (job.isCancelled) {
            decrypted.destroySecurely()
            activeSessionJobs.remove(sessionKey)
            activeSessionIds.remove(sessionKey)
        }
    }

    private fun handleSessionLifecycle(beaconKey: String, major: Int, minor: Int, rssi: Int) {
        lateinit var sessionJob: Job
        sessionJob = observerScope.launch(start = CoroutineStart.LAZY) {
            try {
                verboseLog(TAG, "🎯 3회 감지 완료! 세션 API 호출 시작 ($beaconKey)")
                val sessionResponse = fetchAndDecryptSessionUseCase.execute(major, minor, rssi)

                activeSessionIds[beaconKey] = sessionResponse.sessionId
                debugLog(TAG, "✅ 세션 획득 및 복호화 완료! RTDB 인증 대기 시작 (expiresAt 기준)")
                runSessionObservation(beaconKey, sessionResponse)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                val isNodeGone = e is GoPassException && e.internalCode == InternalErrorCode.SESSION_NODE_GONE.code
                errorLog(TAG, "세션 통신 또는 RTDB 처리 중 에러: ${e.message}")
                if (!isNodeGone) {
                    activeSessionIds[beaconKey]?.let { deleteSessionAsync(it, beaconKey) }
                } else {
                    debugLog(TAG, "💔 세션 노드 소멸 → 로컬 정리만 수행 ($beaconKey)")
                }
            } finally {
                // conditional remove: 다른 경로에서 이미 정리했거나 새 세션이 시작된 경우 안전망
                activeSessionJobs.remove(beaconKey, sessionJob)
                activeSessionIds.remove(beaconKey)
                hitCounts.remove(beaconKey)
                debugLog(TAG, "🧹 세션 자원 로컬 정리 완료. 다시 비콘 신호 수신 대기 ($beaconKey)")
            }
        }

        val existingJob = activeSessionJobs.putIfAbsent(beaconKey, sessionJob)
        if (existingJob != null) {
            sessionJob.cancel()
            return
        }

        sessionJob.start()
    }

    /**
     * FCM 세션 처리 완료 후 해당 비콘 키의 로컬 상태를 초기화하여
     * 비콘 3회 감지 → 세션 생성 사이클이 다시 시작되도록 한다.
     */
    private fun resetBeaconStateForRedetection(session: DecryptedSession) {
        if (session.beaconMajor.isEmpty() || session.beaconMinor.isEmpty()) return
        val beaconKey = "${session.beaconMajor}_${session.beaconMinor}"
        clearBeaconSession(beaconKey)
        cooldownMap.remove(beaconKey)
        debugLog(TAG, "🔄 비콘 상태 초기화 완료 ($beaconKey) → 재감지 대기")
    }

    /**
     * RSSI가 유효 범위를 이탈한 비콘의 활성 세션을 즉시 삭제한다.
     */
    private fun handleBeaconOutOfRange(beaconKey: String, rssi: Int) {
        val sessionId = clearBeaconSession(beaconKey) ?: return
        debugLog(TAG, "📡 RSSI 범위 이탈 감지: $beaconKey (RSSI=$rssi) → 세션 [$sessionId] 삭제 요청")
        deleteSessionAsync(sessionId, beaconKey)
    }

    /**
     * 특정 비콘의 신호가 BEACON_SILENCE_TIMEOUT_MS 동안 수신되지 않았을 때 호출된다.
     * 해당 비콘에 연결된 활성 세션을 삭제하고, 로컬 상태를 정리한다.
     */
    private fun handleBeaconSilent(beaconKey: String) {
        val sessionId = clearBeaconSession(beaconKey)
        if (sessionId != null) {
            debugLog(TAG, "📡 비콘 침묵 감지: $beaconKey → 세션 [$sessionId] 삭제 요청")
            deleteSessionAsync(sessionId, beaconKey)
        }
    }

    /**
     * 비콘/FCM 양쪽에서 공유하는 세션 관찰 공통 로직.
     * DecryptedSession을 받아 RTDB 인증 → SSE 관찰 → 얼굴 비교 → 결과 전송을 수행한다.
     */
    private suspend fun runSessionObservation(
        sessionKey: String,
        session: DecryptedSession
    ) {
        try {
            var deadlineMillis = session.expiresAtMillis
            val remainingMillis = deadlineMillis - System.currentTimeMillis()
            if (remainingMillis <= 0) {
                debugLog(TAG, "[AUTH_PROGRESS] 세션 이미 만료됨 ($sessionKey)")
                return
            }
            debugLog(TAG, "[AUTH_PROGRESS] 세션 관찰 시작. 남은 시간=${remainingMillis}ms ($sessionKey)")

            val (facePayloadFlow, idToken) = processSessionUseCase.execute(session)

            val timedOut = withTimeoutOrNull(remainingMillis + PAYLOAD_GRACE_MILLIS) {
                facePayloadFlow.first { facePayload ->
                    val beforeGraceRemaining = deadlineMillis - System.currentTimeMillis()
                    debugLog(
                        TAG,
                        "[AUTH_PROGRESS] payload 수신. 벡터 크기=${facePayload.vector.size}, ts=${facePayload.timestamp}, 유예 전 남은 시간=${beforeGraceRemaining}ms"
                    )

                    deadlineMillis += PAYLOAD_GRACE_MILLIS
                    debugLog(TAG, "[AUTH_PROGRESS] +${PAYLOAD_GRACE_MILLIS}ms 유예 부여")

                    val compareResult = facePayload.vector.useAndWipe { vector ->
                        compareFacesUseCase.execute(vector)
                    }.also {
                        debugLog(TAG, "🛡️ [보안] 메모리 내 수신된 생체 벡터 데이터 영구 소각 완료")
                    }

                    val isRtdbSuccess = updateSessionResultUseCase.execute(
                        session = session,
                        idToken = idToken,
                        isSuccess = compareResult
                    )
                    debugLog(TAG, "[AUTH_PROGRESS] 인증=$compareResult, RTDB 전송=$isRtdbSuccess")

                    deadlineMillis -= PAYLOAD_GRACE_MILLIS
                    val remaining = deadlineMillis - System.currentTimeMillis()
                    debugLog(
                        TAG,
                        "[AUTH_PROGRESS] -${PAYLOAD_GRACE_MILLIS}ms 유예 회수. 남은 시간=${remaining}ms"
                    )

                    // /result 서버 보고: 독립 스코프에서 수행하여 세션 취소/타임아웃에 영향받지 않음
                    updateSessionResultUseCase.submitSessionResultBackground(
                        session.sessionId, compareResult
                    )

                    if (compareResult && isRtdbSuccess) {
                        cooldownMap[sessionKey] = System.currentTimeMillis()
                        debugLog(TAG, "[AUTH_PROGRESS] 최종 성공. 세션 종료 ($sessionKey)")
                        true
                    } else if (remaining <= 0) {
                        debugLog(TAG, "[AUTH_PROGRESS] 만료. 세션 자연 종료 ($sessionKey)")
                        true
                    } else {
                        debugLog(
                            TAG,
                            "[AUTH_PROGRESS] 인증 실패 OR 서버 전송 실패. ${remaining}ms 남음, 다음 payload 대기"
                        )
                        false
                    }
                }
                true
            } == null

            if (timedOut) {
                warnLog(TAG, "[AUTH_PROGRESS] payload 미수신 타임아웃. 세션 자연 종료 ($sessionKey)")
            }
        } finally {
            updateSessionResultUseCase.clearSessionState(session.sessionId)
            session.destroySecurely()
        }
    }

    suspend fun purgeAllSessions() {
        stopListening()
        val count = deleteActiveServerSessions()
        clearLocalSessionState()
        infoLog(TAG, "[REMOVE_BIO] 세션 퍼지 완료 (${count}건 정리)")
    }

    private suspend fun deleteActiveServerSessions(): Int {
        val sessionIds = activeSessionIds.values.toList()
        infoLog(TAG, "[REMOVE_BIO] 서버 세션 삭제 시작 (${sessionIds.size}건)")

        sessionIds.forEach { sessionId ->
            runCatching { sessionRepository.deleteSession(sessionId) }
                .onSuccess { infoLog(TAG, "[REMOVE_BIO] 서버 세션 삭제 성공 [$sessionId]") }
                .onFailure { errorLog(TAG, "[REMOVE_BIO] 서버 세션 삭제 실패 [$sessionId]: ${it.message}") }
            updateSessionResultUseCase.clearSessionState(sessionId)
        }

        return sessionIds.size
    }

    private fun clearLocalSessionState() {
        observerScope.coroutineContext.cancelChildren()
        activeSessionJobs.clear()
        activeSessionIds.clear()
        cooldownMap.clear()
        hitCounts.clear()
    }

    fun stopListening() {
        if (!isListening.compareAndSet(true, false)) return

        collectorJob?.cancel()
        collectorJob = null

        hitCounts.clear()

        debugLog(TAG, "옵저버 완전 종료")
    }

    private fun handleServiceDestroyed() {
        stopListening()
        clearLocalSessionState()
        debugLog(TAG, "🧹 서비스 종료에 따른 세션/쿨다운 자원 정리 완료")
    }

    fun destroy() {
        stopListening()
        lifecycleScope.cancel()
        observerScope.cancel()
        clearLocalSessionState()
        updateSessionResultUseCase.destroy()
        debugLog(TAG, "🛑 옵저버 자원 완전 파기 완료")
    }

    fun destroySessionSecurely(session: DecryptedSession) {
        session.destroySecurely()
    }

    private fun DecryptedSession.destroySecurely() {
        runCatching {
            val destroyableKey = dkUser as? Destroyable
            if (destroyableKey?.isDestroyed == false) {
                destroyableKey.destroy()
                debugLog(TAG, "세션 [$sessionId] dkUser 메모리 안전 파기 완료")
            }
        }.onFailure { e ->
            errorLog(TAG, "세션 [$sessionId] dkUser 파기 실패: ${e.message}")
        }
    }
}
