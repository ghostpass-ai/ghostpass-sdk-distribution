package com.ghostpasssdk.gopasssdk.internal.di

import android.bluetooth.BluetoothManager
import android.content.Context
import android.location.LocationManager
import android.net.ConnectivityManager
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.device.domain.DeviceStatusProvider
import com.ghostpasssdk.gopasssdk.core.device.infra.AndroidDeviceStatusProvider
import com.ghostpasssdk.gopasssdk.core.network.infra.ApiClient
import com.ghostpasssdk.gopasssdk.core.network.infra.SignedRequestPreflightChecker
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.domain.KeyManager
import com.ghostpasssdk.gopasssdk.core.security.infra.AndroidKeyManager
import com.ghostpasssdk.gopasssdk.core.security.infra.JcaCryptoEngine
import com.ghostpasssdk.gopasssdk.core.security.infra.LocalDataEncryptor
import com.ghostpasssdk.gopasssdk.core.security.infra.RequestSigner
import com.ghostpasssdk.gopasssdk.data.repository.integrity.PlayIntegrityTokenProvider
import com.ghostpasssdk.gopasssdk.domain.repository.integrity.IntegrityTokenProvider
import com.ghostpasssdk.gopasssdk.data.api.AuthApi
import com.ghostpasssdk.gopasssdk.data.api.FirebaseApi
import com.ghostpasssdk.gopasssdk.data.api.SessionApi
import com.ghostpasssdk.gopasssdk.data.api.TokenApi
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraCompareAdapter
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraDetectionAdapter
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraExtractAdapter
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraLivenessAdapter
import com.ghostpasssdk.gopasssdk.data.engine.face.AlcheraSdkManager
import com.ghostpasssdk.gopasssdk.data.engine.monitor.AndroidMonitoringServiceLauncher
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconMonitorAdapter
import com.ghostpasssdk.gopasssdk.data.repository.remote.AuthRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.remote.FirebaseRealtimeSessionRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.remote.SessionRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.remote.TokenRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.storage.IdentityRepositoryImpl
import com.ghostpasssdk.gopasssdk.data.repository.storage.LandmarkRepositoryImpl
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceCompareEngine
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceDetectionEngine
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceEngineManager
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceExtractEngine
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceLivenessEngine
import com.ghostpasssdk.gopasssdk.domain.engine.monitor.ProximityMonitorEngine
import com.ghostpasssdk.gopasssdk.domain.repository.remote.AuthRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.TokenRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.device.CheckAllConditionsUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.CompareFacesUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.landmark.FaceRegisterUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StartProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StopProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.DeviceIdUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.ProvisionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.DecryptSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.FetchAndDecryptSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.ProcessSessionUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.UpdateSessionResultUseCase
import com.ghostpasssdk.gopasssdk.internal.manager.InfrastructureManager
import com.ghostpasssdk.gopasssdk.internal.manager.LandmarkManager
import com.ghostpasssdk.gopasssdk.internal.manager.ProximityObserver
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import kotlin.getValue

internal class SdkContainer private constructor(context: Context) {
    internal val appContext = context.applicationContext
    internal val keyManager: KeyManager by lazy { AndroidKeyManager(appContext) }
    private val cryptoEngine: CryptoEngine by lazy { JcaCryptoEngine() }

    private val localDataEncryptor by lazy {
        LocalDataEncryptor(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    private val requestSigner by lazy {
        RequestSigner(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    private val signedRequestPreflightChecker by lazy {
        SignedRequestPreflightChecker(
            identityRepository = identityRepository,
            requestSigner = requestSigner
        )
    }

    internal val provisionUseCase by lazy {
        ProvisionUseCase(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    internal val deviceIdUseCase by lazy {
        DeviceIdUseCase(
            context = appContext,
            cryptoEngine = cryptoEngine,
            identityRepository = identityRepository
        )
    }

    val identityRepository: IdentityRepository by lazy {
        IdentityRepositoryImpl(
            context = appContext,
            localDataEncryptor = localDataEncryptor
        )
    }

    private val json: Json by lazy {
        Json {
            ignoreUnknownKeys = true
            isLenient = true
            explicitNulls = false
            encodeDefaults = true
        }
    }

    private val apiClient: ApiClient by lazy {
        ApiClient(
            json = json,
            requestSigner = requestSigner,
            identityRepository = identityRepository
        )
    }

    private val okHttpClientLazy = lazy {
        apiClient.getSecureClientBuilder().build()
    }
    private val okHttpClient: OkHttpClient by okHttpClientLazy

    private val retrofit: Retrofit by lazy {
        apiClient.buildRetrofit(BuildConfig.BASE_URL, okHttpClient)
    }

    internal val integrityTokenProvider: IntegrityTokenProvider by lazy {
        PlayIntegrityTokenProvider(appContext)
    }

    private val authApi: AuthApi by lazy {
        retrofit.create(AuthApi::class.java)
    }

    private val sessionApi: SessionApi by lazy {
        retrofit.create(SessionApi::class.java)
    }

    private val tokenApi: TokenApi by lazy {
        retrofit.create(TokenApi::class.java)
    }

    private val firebaseApi by lazy {
        retrofit.create(FirebaseApi::class.java)
    }

    internal val authRepository: AuthRepository by lazy {
        AuthRepositoryImpl(
            authApi = authApi,
            signedRequestPreflightChecker = signedRequestPreflightChecker
        )
    }

    internal val sessionRepository: SessionRepository by lazy {
        SessionRepositoryImpl(
            sessionApi = sessionApi,
            signedRequestPreflightChecker = signedRequestPreflightChecker
        )
    }

    private val tokenRepository: TokenRepository by lazy {
        TokenRepositoryImpl(
            tokenApi = tokenApi,
            signedRequestPreflightChecker = signedRequestPreflightChecker
        )
    }

    private val alcheraSdkManager by lazy { AlcheraSdkManager(appContext) }

    private val faceEngineManager: FaceEngineManager get() = alcheraSdkManager

    /**
     * cold start 시 FaceSDK 네이티브 로드(~5s)를 최대한 앞당기기 위한 사전 초기화 Job.
     * getOrCreate() 시점에 시작되어, delegateAuthSession Phase 2 진입 전까지 초기화 시간 확보.
     * 이미 초기화된 상태에서는 faceEngineManager.initialize()가 멱등이므로 즉시 완료.
     */
    internal var faceEngineWarmUpJob: Job? = null
        private set

    internal fun warmUpFaceEngine() {
        if (faceEngineWarmUpJob != null) return
        faceEngineWarmUpJob = CoroutineScope(Dispatchers.IO).launch {
            runCatching { faceEngineManager.initialize() }
        }
    }

    private val faceDetectionEngine: FaceDetectionEngine by lazy {
        AlcheraDetectionAdapter(alcheraSdkManager)
    }

    private val faceLivenessEngine: FaceLivenessEngine by lazy {
        AlcheraLivenessAdapter(alcheraSdkManager)
    }

    private val faceExtractEngine: FaceExtractEngine by lazy {
        AlcheraExtractAdapter(alcheraSdkManager)
    }

    private val faceCompareEngine: FaceCompareEngine by lazy {
        AlcheraCompareAdapter(alcheraSdkManager)
    }

    private val landmarkRepository: LandmarkRepository by lazy {
        LandmarkRepositoryImpl(
            context = appContext,
            localDataEncryptor = localDataEncryptor,
            identityRepository = identityRepository
        )
    }

    private val faceRegisterUseCase by lazy {
        FaceRegisterUseCase(
            detectionEngine = faceDetectionEngine,
            livenessEngine = faceLivenessEngine,
            extractEngine = faceExtractEngine
        )
    }

    private val monitoringServiceLauncher by lazy {
        AndroidMonitoringServiceLauncher(context = appContext)
    }

    private val monitorEngine: ProximityMonitorEngine by lazy {
        BeaconMonitorAdapter(serviceLauncher = monitoringServiceLauncher)
    }

    private val startMonitorUseCase by lazy {
        StartProximityMonitorUseCase(
            monitorEngine = monitorEngine,
            landmarkRepository = landmarkRepository,
            identityRepository = identityRepository,
            deviceStatusProvider = deviceStatusProvider
        )
    }

    private val stopMonitorUseCase by lazy {
        StopProximityMonitorUseCase(
            monitorEngine = monitorEngine
        )
    }

    private val decryptSessionUseCase by lazy {
        DecryptSessionUseCase(
            cryptoEngine = cryptoEngine,
            keyManager = keyManager
        )
    }

    private val fetchAndDecryptSessionUseCase by lazy {
        FetchAndDecryptSessionUseCase(
            sessionRepository = sessionRepository,
            decryptSessionUseCase = decryptSessionUseCase
        )
    }

    private val realtimeSessionRepository: RealtimeSessionRepository by lazy {
        FirebaseRealtimeSessionRepositoryImpl(
            firebaseApi = firebaseApi,
            okHttpClient = okHttpClient,
            cryptoEngine = cryptoEngine
        )
    }

    private val processSessionUseCase by lazy {
        ProcessSessionUseCase(
            realtimeSessionRepository = realtimeSessionRepository
        )
    }

    private val compareFacesUseCase by lazy {
        CompareFacesUseCase(
            landmarkRepository = landmarkRepository,
            faceCompareEngine = faceCompareEngine
        )
    }

    private val updateSessionResultUseCase by lazy {
        UpdateSessionResultUseCase(
            realtimeSessionRepository = realtimeSessionRepository,
            sessionRepository = sessionRepository,
            cryptoEngine = cryptoEngine,
            identityRepository = identityRepository
        )
    }

    private val proximityObserver by lazy {
        ProximityObserver(
            fetchAndDecryptSessionUseCase = fetchAndDecryptSessionUseCase,
            processSessionUseCase = processSessionUseCase,
            compareFacesUseCase = compareFacesUseCase,
            updateSessionResultUseCase = updateSessionResultUseCase,
            sessionRepository = sessionRepository
        )
    }

    val infrastructureManager by lazy {
        InfrastructureManager(
            context = appContext,
            identityRepository = identityRepository,
            deviceIdUseCase = deviceIdUseCase,
            provisionUseCase = provisionUseCase,
            authRepository = authRepository,
            integrityTokenProvider = integrityTokenProvider,
            faceEngineManager = faceEngineManager,
            startMonitorUseCase = startMonitorUseCase,
            stopMonitorUseCase = stopMonitorUseCase,
            proximityObserver = proximityObserver,
            landmarkRepository = landmarkRepository,
            tokenRepository = tokenRepository,
            decryptSessionUseCase = decryptSessionUseCase,
            faceEngineWarmUpJob = { faceEngineWarmUpJob }
        )
    }

    val landmarkManager by lazy {
        LandmarkManager(
            faceRegisterUseCase = faceRegisterUseCase,
            landmarkRepository = landmarkRepository,
            identityRepository = identityRepository,
            startProximityMonitorUseCase = startMonitorUseCase,
            stopProximityMonitorUseCase = stopMonitorUseCase,
            proximityObserver = proximityObserver
        )
    }

    private val deviceStatusProvider: DeviceStatusProvider by lazy {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        AndroidDeviceStatusProvider(
            context = appContext,
            bluetoothManager = bluetoothManager,
            connectivityManager = connectivityManager,
            locationManager = locationManager
        )
    }

    val checkAllConditionsUseCase: CheckAllConditionsUseCase by lazy {
        CheckAllConditionsUseCase(
            deviceStatusProvider = deviceStatusProvider
        )
    }

    /**
     * START_STICKY로 서비스가 재시작될 때 ProximityObserver의 EventBus 컬렉터를 복원한다.
     * 정상 경로(GoPassSDK.initialize)에서는 InfrastructureManager가 호출하므로
     * AtomicBoolean 가드에 의해 중복 초기화가 방지된다.
     */
    fun ensureProximityLifecycle() {
        proximityObserver.initializeLifecycle()
    }

    /**
     * 초기화된 OkHttp 클라이언트의 커넥션 풀과 디스패처를 정리합니다.
     * lazy 미초기화 상태에서는 불필요한 객체 생성을 방지합니다.
     */
    private fun release() {
        faceEngineWarmUpJob?.cancel()
        faceEngineWarmUpJob = null
        if (okHttpClientLazy.isInitialized()) {
            okHttpClient.connectionPool.evictAll()
            okHttpClient.dispatcher.executorService.shutdown()
        }
    }

    companion object {
        @Volatile
        private var instance: SdkContainer? = null

        internal fun getOrCreate(context: Context): SdkContainer {
            val applicationContext = context.applicationContext
            return instance ?: synchronized(this) {
                instance ?: SdkContainer(applicationContext).also {
                    instance = it
                    it.warmUpFaceEngine()
                }
            }
        }

        internal fun requireInstance(): SdkContainer {
            return instance ?: throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.CONTAINER_IS_NULL
            )
        }

        internal suspend fun destroyInstance() {
            withContext(Dispatchers.IO) {
                synchronized(this@Companion) {
                    instance?.release()
                    instance = null
                }
            }
        }
    }
}
