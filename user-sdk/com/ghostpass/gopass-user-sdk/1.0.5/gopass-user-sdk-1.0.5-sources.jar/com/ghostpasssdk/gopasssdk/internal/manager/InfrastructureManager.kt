package com.ghostpasssdk.gopasssdk.internal.manager

import android.content.Context
import android.os.Build
import com.ghostpasssdk.gopasssdk.data.repository.mapper.ApiEndpoint
import com.ghostpasssdk.gopasssdk.data.repository.mapper.getOrThrow
import com.ghostpasssdk.gopasssdk.domain.repository.integrity.IntegrityTokenProvider
import com.ghostpasssdk.gopasssdk.domain.repository.remote.AuthRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.DeviceIdUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.ProvisionRequestValidator
import com.ghostpasssdk.gopasssdk.domain.usecase.provision.ProvisionUseCase
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.domain.engine.face.FaceEngineManager
import com.ghostpasssdk.gopasssdk.domain.model.external.InitResult
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ConfirmParams
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.Provision
import com.ghostpasssdk.gopasssdk.domain.model.internal.provision.ProvisionParams
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.domain.repository.storage.LandmarkRepository
import com.ghostpasssdk.gopasssdk.data.engine.monitor.BeaconServiceEvents
import com.ghostpasssdk.gopasssdk.data.dto.session.SessionDto
import com.ghostpasssdk.gopasssdk.domain.repository.remote.TokenRepository
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StartProximityMonitorUseCase
import com.ghostpasssdk.gopasssdk.domain.usecase.session.DecryptSessionUseCase
import kotlinx.serialization.json.Json
import com.ghostpasssdk.gopasssdk.domain.usecase.monitor.StopProximityMonitorUseCase
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

internal class InfrastructureManager(
    private val context: Context,
    private val identityRepository: IdentityRepository,
    private val deviceIdUseCase: DeviceIdUseCase,
    private val provisionUseCase: ProvisionUseCase,
    private val authRepository: AuthRepository,
    private val integrityTokenProvider: IntegrityTokenProvider,
    private val faceEngineManager: FaceEngineManager,
    private val startMonitorUseCase: StartProximityMonitorUseCase,
    private val stopMonitorUseCase: StopProximityMonitorUseCase,
    private val proximityObserver: ProximityObserver,
    private val landmarkRepository: LandmarkRepository,
    private val tokenRepository: TokenRepository,
    private val decryptSessionUseCase: DecryptSessionUseCase,
    private val faceEngineWarmUpJob: () -> Job?
) {

    companion object {
        private val TAG = "InfrastructureManager ${BuildConfig.SIGNATURE}"
        private const val PLATFORM = "ANDROID"
    }

    private val initMutex = Mutex()
    private val provisionRequestValidator by lazy {
        ProvisionRequestValidator(
            expectedPlatform = PLATFORM,
            publicKeyValidator = provisionUseCase::isValidPublicKey
        )
    }

    @Volatile
    private var initDeferred: Deferred<InitResult>? = null
    private var lifecycleInitialized = false // guarded by initMutex
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun initialize(apiKey: String): InitResult {
        val deferred = initMutex.withLock {
            initDeferred?.let { return@withLock it }

            if (!lifecycleInitialized) {
                proximityObserver.initializeLifecycle()
                lifecycleInitialized = true
            }

            val newDeferred = scope.async {
                initializeCore(apiKey)
            }

            initDeferred = newDeferred
            newDeferred
        }

        return try {
            deferred.await()
        } catch (t: Throwable) {
            initMutex.withLock {
                if (initDeferred === deferred) {
                    initDeferred = null
                }
            }
            throw t
        }
    }

    private suspend fun initializeCore(apiKey: String): InitResult {
        if (apiKey.isBlank()) {
            throw GoPassException.from(
                error = ErrorCode.INVALID_PARAMETERS,
                internalCode = InternalErrorCode.API_KEY_EMPTY
            )
        }

        val savedApiKey = identityRepository.getApiKey()
        val isApiKeyChanged = (apiKey != savedApiKey)
        val isProvisionRequired = provisionUseCase.isRequire() || isApiKeyChanged
        val isBeaconUuidMissing = identityRepository.getBeaconUuid().isNullOrBlank()
        debugLog(TAG, "isProvisionRequired : ${isProvisionRequired && isBeaconUuidMissing}")

        if (isProvisionRequired && isBeaconUuidMissing) {
            identityRepository.saveApiKey(apiKey)
            deviceIdUseCase.getOrCreate()

            val result = provision(apiKey = apiKey)

            confirm(identityId = result.identityId, deviceId = result.deviceId)
        }

        config()
        // faceSdk 초기화
        faceEngineManager.initialize()

        // 랜드마크 존재 확인 후 비콘 서비스 시작
        startMonitorUseCase.execute()

        val deviceId = identityRepository.getDeviceId()
            ?: throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.DEVICE_ID_NOT_FOUND
            )

        val hasBioDataResult = landmarkRepository.getHasBioDataResult()

        return InitResult(
            deviceId = deviceId,
            hasBioData = hasBioDataResult.hasBioData,
            registeredAt = hasBioDataResult.registeredAt
        )
    }

    private suspend fun provision(apiKey: String) : Provision {
        val request = createProvisionRequest()

        // 4. provision
        val provision = authRepository.provision(request).getOrThrow(ApiEndpoint.PROVISION)

        // 5. 키 복호화 및 저장
        provisionUseCase.processKeyExchange(
            apiKey = apiKey,
            provision = provision
        )

        identityRepository.saveIdentityId(provision.identityId)
        identityRepository.saveDeviceId(provision.deviceId)

        return provision
    }

    private suspend fun createProvisionRequest(): ProvisionParams {
        // 1. ECDH 키 합의
        val pubKey = provisionUseCase.generatePublicKey()

        // 2. integrity 도출을 위한 nonce 획득
        val challenge = authRepository.challenge().getOrThrow(ApiEndpoint.CHALLENGE)

        // 3. integrity token 획득
        val token = integrityTokenProvider.fetchIntegrityToken(challenge.challenge)

        val appVersion =
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown"

        return ProvisionParams(
            challenge = challenge.challenge,
            attestation = token,
            platform = PLATFORM,
            platformId = deviceIdUseCase.getPlatformId(),
            installId = deviceIdUseCase.getInstallId(),
            osVersion = Build.VERSION.RELEASE,
            appVersion = appVersion,
            sdkVersion = BuildConfig.SDK_VERSION,
            clientPublicKey = pubKey
        ).also(provisionRequestValidator::validate)
    }

    private suspend fun confirm(identityId: String, deviceId: String) {
        val request = ConfirmParams(
            identityId = identityId,
            deviceId = deviceId
        )
        val confirm = authRepository.confirm(request).getOrThrow(ApiEndpoint.CONFIRM)
    }

    private suspend fun config() {
        val result = authRepository.config().getOrThrow(ApiEndpoint.CONFIG)

        if (isUpdateRequired(result.minSdkVersion)) {
            throw GoPassException.from(
                error = ErrorCode.UPDATE_SDK
            )
        }
        identityRepository.saveBeaconUuid(result.beaconUuid)
    }

    @Throws(GoPassException::class)
    suspend fun reset() {
        warnLog(TAG, "SDK reset 시작")

        var teardownException: Throwable? = null

        // 1. 포그라운드 서비스 중지 (코루틴 취소 전에 수행해야 정상 종료)
        runCatching { stopMonitorUseCase.execute() }
            .onFailure { e -> warnLog(TAG, "서비스 중지 중 예외 (계속 진행): ${e.message}") }

        // 2. initMutex 보호 하에 teardown 수행 (initialize와의 경합 방지)
        val oldJob = initMutex.withLock {
            runCatching { teardown() }
                .onFailure { e -> if (teardownException == null) teardownException = e }
                .getOrNull()
        }

        // 3. 코루틴 완료 대기 (최대 2초)
        if (oldJob != null) {
            val isCompleted = withTimeoutOrNull(2000L) {
                oldJob.join()
                true
            }

            if (isCompleted == null) {
                val errMsg =
                    "FATAL: 일부 코루틴이 정상적으로 종료되지 않았습니다. (Memory Leak 및 Zombie 코루틴 위험)"
                errorLog(TAG, errMsg)
                if (teardownException == null) {
                    teardownException = IllegalStateException(errMsg)
                }
            }
        }

        if (teardownException != null) {
            errorLog(TAG, "SDK 자원이 불완전하게 해제되었습니다. 원인: ${teardownException.message}")
            throw GoPassException.from(error = ErrorCode.RESET_FAILED)
        }

        warnLog(TAG, "SDK reset 완료 — initialize() 재호출 가능")
    }

    @Throws(GoPassException::class)
    suspend fun registerFcmToken(token: String) {
        if (token.isBlank()) {
            throw GoPassException.from(
                error = ErrorCode.INVALID_PARAMETERS,
                internalCode = InternalErrorCode.PUSH_TOKEN_EMPTY
            )
        }
        tokenRepository.updateToken(token).getOrThrow(ApiEndpoint.PUSH_TOKEN)
    }

    private val fcmSessionJson = Json { ignoreUnknownKeys = true }

    @Throws(GoPassException::class)
    suspend fun delegateAuthSession(session: String) {
        // ── Phase 1: 검증 + 복호화 (NonCancellable — 호출자 scope 취소에도 완료 보장) ──

        // IN-801: JSON 파싱
        val encrypted = try {
            fcmSessionJson.decodeFromString<SessionDto>(session).toDomain()
        } catch (e: Exception) {
            throw GoPassException.from(
                error = ErrorCode.DELEGATE_AUTH_SESSION_FAILED,
                internalCode = InternalErrorCode.HANDSFREE_PAYLOAD_DECODING_FAILED
            )
        }

        // IN-802: 필수 필드 검증
        if (encrypted.sessionId.isBlank() || encrypted.rtdbPath.isBlank() ||
            encrypted.encryptedDk.isBlank() || encrypted.firebaseToken.isBlank()
        ) {
            throw GoPassException.from(
                error = ErrorCode.DELEGATE_AUTH_SESSION_FAILED,
                internalCode = InternalErrorCode.HANDSFREE_PAYLOAD_INVALID
            )
        }

        // IN-803: 생체 데이터 존재 확인
        val hasBioData = try {
            landmarkRepository.getHasBioDataResult().hasBioData
        } catch (e: GoPassException) {
            throw GoPassException.from(
                error = ErrorCode.DELEGATE_AUTH_SESSION_FAILED,
                internalCode = InternalErrorCode.HANDSFREE_BIO_DATA_NOT_FOUND
            )
        }
        if (!hasBioData) {
            throw GoPassException.from(
                error = ErrorCode.DELEGATE_AUTH_SESSION_FAILED,
                internalCode = InternalErrorCode.HANDSFREE_BIO_DATA_NOT_FOUND
            )
        }

        // IN-806: 세션 만료 확인
        if (System.currentTimeMillis() > encrypted.expiresAtMillis) {
            throw GoPassException.from(
                error = ErrorCode.DELEGATE_AUTH_SESSION_FAILED,
                internalCode = InternalErrorCode.HANDSFREE_SESSION_EXPIRED
            )
        }

        // IN-804 / IN-805: transport key 로드 + DK 복호화 (~100ms)
        val decrypted = try {
            withContext(NonCancellable) { decryptSessionUseCase.execute(encrypted) }
        } catch (e: GoPassException) {
            val internalCode = if (e.internalCode == InternalErrorCode.SECRET_KEY_NOT_FOUND.code) {
                InternalErrorCode.HANDSFREE_TRANSPORT_KEY_LOAD_FAILED
            } else {
                InternalErrorCode.HANDSFREE_DK_DECRYPTION_FAILED
            }
            throw GoPassException.from(
                error = ErrorCode.DELEGATE_AUTH_SESSION_FAILED,
                internalCode = internalCode
            )
        } catch (e: Exception) {
            throw GoPassException.from(
                error = ErrorCode.DELEGATE_AUTH_SESSION_FAILED,
                internalCode = InternalErrorCode.HANDSFREE_DK_DECRYPTION_FAILED
            )
        }

        // ── Phase 2: SDK 내부 scope (서비스 lifecycle 독립) ──
        // face engine init(~5s) + RTDB 관찰을 SDK scope에서 수행하여
        // FirebaseMessagingService destroy에 의한 취소를 방지
        scope.launch {
            try {
                faceEngineWarmUpJob()?.join()
                faceEngineManager.initialize()
                proximityObserver.delegateSession(decrypted)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                proximityObserver.destroySessionSecurely(decrypted)
                errorLog(TAG, "세션 위임 Phase 2 실패: ${e.message}")
            }
        }
    }

    private fun teardown(): Job? {
        val oldJob = scope.coroutineContext[Job]
        scope.cancel()
        initDeferred = null
        lifecycleInitialized = false
        proximityObserver.destroy()
        BeaconServiceEvents.resetAllCaches()
        return oldJob
    }

    private fun isUpdateRequired(minSdkVersion: String): Boolean {
        val currentParts = BuildConfig.SDK_VERSION.split(".").mapNotNull { it.toIntOrNull() }
        val minParts = minSdkVersion.split(".").mapNotNull { it.toIntOrNull() }
        for (i in 0 until maxOf(currentParts.size, minParts.size)) {
            val current = currentParts.getOrElse(i) { 0 }
            val min = minParts.getOrElse(i) { 0 }
            if (current < min) return true
            if (current > min) return false
        }
        return false
    }
}
