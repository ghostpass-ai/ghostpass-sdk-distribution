package com.ghostpasssdk.gopasssdk.core.device.observer

import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.utils.debugLog
import com.ghostpasssdk.gopasssdk.utils.errorLog

internal class DeviceStateObserver(
    private val context: Context,
    private val onStateChanged: (reason: String) -> Unit
) {
    companion object {
        private val TAG = "DeviceStateObserver ${BuildConfig.SIGNATURE}"
    }

    private var isRegistered = false
    private var currentDefaultNetwork: Network? = null
    private var lastNetworkUsable: Boolean? = null

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                when (state) {
                    BluetoothAdapter.STATE_ON -> onStateChanged("BT_ON")
                    BluetoothAdapter.STATE_OFF -> onStateChanged("BT_OFF")
                }
            }
        }
    }

    private val gpsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == LocationManager.PROVIDERS_CHANGED_ACTION) {
                onStateChanged("GPS_CHANGED")
            }
        }
    }

    private val connectivityManager by lazy {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            if (network == currentDefaultNetwork) return

            currentDefaultNetwork = network
            lastNetworkUsable = isNetworkUsable(connectivityManager.getNetworkCapabilities(network))
            onStateChanged("NET_CHANGED")
        }

        override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities
        ) {
            if (network != currentDefaultNetwork) {
                currentDefaultNetwork = network
            }

            notifyIfDefaultNetworkChanged(isNetworkUsable(networkCapabilities))
        }

        override fun onLost(network: Network) {
            if (network != currentDefaultNetwork) return

            currentDefaultNetwork = null
            notifyIfDefaultNetworkChanged(false)
        }
    }

    private fun notifyIfDefaultNetworkChanged(usable: Boolean) {
        if (lastNetworkUsable == usable) return

        lastNetworkUsable = usable
        onStateChanged("NET_CHANGED")
    }

    private fun isNetworkUsable(caps: NetworkCapabilities?): Boolean {
        return caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun startObserving() {
        if (isRegistered) return
        debugLog(TAG, "상태 감지 리시버/콜백 등록")
        currentDefaultNetwork = connectivityManager.activeNetwork
        lastNetworkUsable = isNetworkUsable(
            currentDefaultNetwork?.let { connectivityManager.getNetworkCapabilities(it) }
        )

        // BT, GPS 등록
        context.registerReceiver(bluetoothReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
        context.registerReceiver(gpsReceiver, IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION))

        try {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
        } catch (e: Exception) {
            debugLog(TAG, "NetworkCallback 등록 실패: ${e.message}")
        }

        isRegistered = true
    }

    fun stopObserving() {
        if (!isRegistered) return
        debugLog(TAG, "상태 감지 리시버/콜백 해제")
        try {
            // BT, GPS 해제
            context.unregisterReceiver(bluetoothReceiver)
            context.unregisterReceiver(gpsReceiver)

            connectivityManager.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            errorLog(TAG, "상태 감지 리시버/콜백 해제 실패: ${e.message}")
        } finally {
            currentDefaultNetwork = null
            lastNetworkUsable = null
            isRegistered = false
        }
    }
}
