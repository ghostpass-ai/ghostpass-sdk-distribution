package com.ghostpasssdk.gopasssdk.data.engine.monitor

import kotlin.math.roundToInt

/**
 * BLE RSSI 신호 안정화를 위한 1D 칼만 필터.
 * 단발성 스파이크를 흡수하면서 실제 거리 변화(접근/이탈)는 추적한다.
 *
 * 히스토리를 쌓지 않고 직전 상태(x, p) 두 값만 유지한다.
 *
 * @param processNoise (q) 스캔 간 실제 RSSI 변화 허용치. 클수록 이동에 민감.
 * @param measurementNoise (r) BLE RSSI 측정 노이즈. 클수록 스파이크에 둔감.
 */
internal class RssiKalmanFilter(
    private val processNoise: Double = 2.0,
    private val measurementNoise: Double = 10.0
) {
    private var x: Double = Double.NaN  // 현재 추정값 (smoothed RSSI)
    private var p: Double = 1.0          // 추정 불확실성

    fun update(rawRssi: Int): Int {
        val z = rawRssi.toDouble()

        if (x.isNaN()) {
            x = z
            return x.roundToInt()
        }

        // Predict: 불확실성 증가
        p += processNoise

        // Update: 칼만 게인 계산 → 추정값 보정
        val k = p / (p + measurementNoise)
        x += k * (z - x)
        p *= (1 - k)

        return x.roundToInt()
    }

    fun reset() {
        x = Double.NaN
        p = 1.0
    }
}
