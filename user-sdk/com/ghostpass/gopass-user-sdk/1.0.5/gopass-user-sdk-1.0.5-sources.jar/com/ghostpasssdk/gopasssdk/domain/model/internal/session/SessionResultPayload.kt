package com.ghostpasssdk.gopasssdk.domain.model.internal.session

internal data class SessionResultPayload(
    val sessionId: String,
    val status: String,
    val terminatedAt: String?,
    val failCount: Int
)
