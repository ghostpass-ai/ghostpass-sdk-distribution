package com.ghostpasssdk.gopasssdk.data.dto.session

import kotlinx.serialization.Serializable

@Serializable
internal data class SessionResultRequest(
    val success: Boolean
)
