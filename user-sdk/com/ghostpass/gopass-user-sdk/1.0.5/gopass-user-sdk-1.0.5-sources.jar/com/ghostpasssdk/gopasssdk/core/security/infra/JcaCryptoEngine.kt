package com.ghostpasssdk.gopasssdk.core.security.infra

import android.util.Base64
import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.domain.model.external.error.ErrorCode
import com.ghostpasssdk.gopasssdk.domain.model.external.error.GoPassException
import com.ghostpasssdk.gopasssdk.domain.model.internal.error.InternalErrorCode
import com.ghostpasssdk.gopasssdk.utils.errorLog
import java.security.Key
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

internal class JcaCryptoEngine : CryptoEngine {

    companion object {
        private val TAG = "CryptoEngine ${BuildConfig.SIGNATURE}"
        // 알고리즘 스펙 상수화
        private const val AES_GCM = "AES/GCM/NoPadding"
        private const val HMAC_ALGORITHM = "HmacSHA256"
        private const val KEY_AGREEMENT_ALGORITHM = "ECDH"
        private const val KEY_FACTORY_ALGORITHM = "EC"
        private const val DIGEST_ALGORITHM = "SHA-256"

        // 길이 관련 상수화
        private const val GCM_IV_LENGTH = 12
        private const val GCM_TAG_LENGTH = 128
        private const val HKDF_HASH_LENGTH = 32
    }

    // Shared Key 도출
    override fun deriveSharedKey(key: PrivateKey, serverPublicKey: PublicKey): ByteArray {
        return try {
            val ka = KeyAgreement.getInstance(KEY_AGREEMENT_ALGORITHM)
            ka.init(key)
            ka.doPhase(serverPublicKey, true)
            ka.generateSecret()
        } catch (e: Exception) {
            errorLog(TAG, "sharedKey 도출 error : $e")
            throw GoPassException.from(
                error = ErrorCode.INITIALIZATION_FAILED,
                internalCode = InternalErrorCode.SHARED_KEY_DERIVATION_FAILED
            )
        }
    }

    override fun hkdf(ikm: ByteArray, salt: ByteArray, info: String): ByteArray {
        val mac = Mac.getInstance(HMAC_ALGORITHM)
        // 1. Extract (추출)
        mac.init(SecretKeySpec(if (salt.isEmpty()) ByteArray( HKDF_HASH_LENGTH) else salt, HMAC_ALGORITHM))
        val prk = mac.doFinal(ikm)

        // 2. Expand (확장)
        mac.init(SecretKeySpec(prk, HMAC_ALGORITHM))
        mac.update(info.toByteArray(Charsets.UTF_8))
        return mac.doFinal(byteArrayOf(1))
    }

    // 복호화 : kioskSecret, dk_user
    override fun decryptData(key: Key, encryptedBase64: String, aad: ByteArray): ByteArray {
        val fullData = Base64.decode(encryptedBase64, Base64.NO_WRAP)

        val iv = fullData.sliceArray(0 until GCM_IV_LENGTH)
        val cipherText = fullData.sliceArray(GCM_IV_LENGTH until fullData.size)

        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_LENGTH, iv))
        aad.takeIf { it.isNotEmpty() }?.let { cipher.updateAAD(it) }
        return cipher.doFinal(cipherText)
    }

    override fun encrypt(plainText: String, key: Key, aad: ByteArray): String {
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        aad.takeIf { it.isNotEmpty() }?.let { cipher.updateAAD(it) }

        val cipherTextWithTag = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val iv = cipher.iv

        val combinedPayload = ByteArray(iv.size + cipherTextWithTag.size)
        System.arraycopy(iv, 0, combinedPayload, 0, iv.size)
        System.arraycopy(cipherTextWithTag, 0, combinedPayload, iv.size, cipherTextWithTag.size)

        return Base64.encodeToString(combinedPayload, Base64.NO_WRAP)
    }

    override fun generateHmacSignature(key: SecretKey, stringToSign: String): String {
        val mac = Mac.getInstance(HMAC_ALGORITHM)
        mac.init(key)

        val signatureBytes = mac.doFinal(stringToSign.toByteArray(Charsets.UTF_8))

        return signatureBytes.joinToString("") { "%02x".format(it) }
    }

    override fun decodeECPublicKey(base64: String): PublicKey {
        val keyBytes = Base64.decode(base64, Base64.DEFAULT)
        val keySpec = X509EncodedKeySpec(keyBytes)
        return KeyFactory.getInstance(KEY_FACTORY_ALGORITHM).generatePublic(keySpec)
    }

    override fun hashSha256(input: String): String {
        val digest = MessageDigest.getInstance( DIGEST_ALGORITHM)
        return digest.digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}