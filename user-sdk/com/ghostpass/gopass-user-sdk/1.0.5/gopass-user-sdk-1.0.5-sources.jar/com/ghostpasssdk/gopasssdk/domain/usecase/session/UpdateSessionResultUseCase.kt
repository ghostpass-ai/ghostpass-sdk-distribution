package com.ghostpasssdk.gopasssdk.domain.usecase.session

import com.ghostpasssdk.gopasssdk.BuildConfig
import com.ghostpasssdk.gopasssdk.core.network.model.ApiResult
import com.ghostpasssdk.gopasssdk.core.security.domain.CryptoEngine
import com.ghostpasssdk.gopasssdk.domain.model.internal.firebase.UserToKioskPayload
import com.ghostpasssdk.gopasssdk.domain.model.internal.session.DecryptedSession
import com.ghostpasssdk.gopasssdk.domain.repository.remote.RealtimeSessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.remote.SessionRepository
import com.ghostpasssdk.gopasssdk.domain.repository.storage.IdentityRepository
import com.ghostpasssdk.gopasssdk.core.network.utils.retryApiCall
import com.ghostpasssdk.gopasssdk.utils.errorLog
import com.ghostpasssdk.gopasssdk.utils.warnLog
import kotlinx.serialization.json.Json.Default.encodeToString
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

internal class UpdateSessionResultUseCase(
    private val realtimeSessionRepository: RealtimeSessionRepository,
    private val sessionRepository: SessionRepository,
    private val cryptoEngine: CryptoEngine,
    private val identityRepository: IdentityRepository
) {
    companion object {
        private val TAG = "UpdateSessionUseCase ${BuildConfig.SIGNATURE}"
        private const val STATUS_SUCCESS = "SUCCESS"
        private const val STATUS_FAIL = "FAIL"
        private const val TYPE = "AUTH_RESULT"
    }

    private val sessionSequences = ConcurrentHashMap<String, AtomicInteger>()

    /**
     * RTDB user_to_kiosk에 인증 결과를 암호화하여 전송한다.
     * RTDB 기록 성공 = 인증 흐름 성공. /result 서버 보고는 포함하지 않는다.
     */
    suspend fun execute(session: DecryptedSession, idToken: String, isSuccess: Boolean): Boolean {
        return try {
            val finalStatus = if (isSuccess) STATUS_SUCCESS else STATUS_FAIL

            val deviceId = identityRepository.getDeviceId()

            if (deviceId.isNullOrBlank()) {
                errorLog(TAG, "deviceID 누락")
                return false
            }

            val payloadMap = mapOf(
                "type" to TYPE,
                "result" to finalStatus,
                "deviceId" to deviceId
            )

            val plaintext = encodeToString(payloadMap)

            val seq = nextSequence(session.sessionId)
            val aadString = "${session.sessionId}:$seq:u2k"
            val aadBytes = aadString.toByteArray(Charsets.UTF_8)

            val encryptedData = cryptoEngine.encrypt(
                plainText = plaintext,
                aad = aadBytes,
                key = session.dkUser
            )

            val updatePayload = UserToKioskPayload(
                payload = encryptedData,
                seq = seq
            )

            val result = realtimeSessionRepository.updateSession(
                path = session.rtdbPath,
                authToken = idToken,
                data = updatePayload
            )

            if (result.isSuccess) {
                warnLog(TAG, "😆 user_to_kiosk 업데이트 완료")
                true
            } else {
                errorLog(TAG, "❌ [서버 전송 실패] 에러: ${result.exceptionOrNull()?.message}")
                false
            }

        } catch (e: Exception) {
            errorLog(TAG, "🚨 암호화 또는 전송 중 치명적 에러: ${e.message}")
            false
        }
    }

    /**
     * 서버에 인증 결과를 보고한다. 지수 백오프로 최대 3회 재시도.
     * best-effort: 실패해도 인증 흐름에 영향을 주지 않는다.
     */
    suspend fun submitSessionResultWithRetry(sessionId: String, isSuccess: Boolean) {
        val result = retryApiCall { sessionRepository.submitResult(sessionId, isSuccess) }
        when (result) {
            is ApiResult.Success -> warnLog(
                TAG,
                "😆 result API 호출 완료: sessionId=$sessionId, status=${result.data.status}, failCount=${result.data.failCount}"
            )
            is ApiResult.Failure -> errorLog(TAG, "📋 result 보고 최종 실패: code=${result.code}, message=${result.message}")
            is ApiResult.NetworkError -> errorLog(TAG, "📋 result 보고 최종 네트워크 실패: ${result.error.message}")
        }
    }

    private suspend fun submitSessionResult(sessionId: String, isSuccess: Boolean): Boolean {
        return when (val result = sessionRepository.submitResult(sessionId, isSuccess)) {
            is ApiResult.Success -> {
                warnLog(
                    TAG,
                    "😆 result API 호출 완료: sessionId=$sessionId, status=${result.data.status}, failCount=${result.data.failCount}"
                )
                true
            }

            is ApiResult.Failure -> {
                errorLog(TAG, "❌ [result API 실패] code=${result.code}, message=${result.message}")
                false
            }

            is ApiResult.NetworkError -> {
                errorLog(TAG, "❌ [result API 네트워크 실패] ${result.error.message}")
                false
            }
        }
    }

    fun clearSessionState(sessionId: String) {
        sessionSequences.remove(sessionId)
    }

    private fun nextSequence(sessionId: String): Int {
        val counter = sessionSequences.computeIfAbsent(sessionId) { AtomicInteger(0) }
        return counter.incrementAndGet()
    }
}
